

# Create an empty list to store the modified data
PLV_Diffs <- PLV

# Loop through each subject in PLV
for (i in seq_along(PLV)) {
  
  # For each subject, loop through the frequency bands (delta, theta, etc.)
  for (band in names(PLV[[i]]$LEFT)) {
    
    # Remove the second row and second column from the LEFT band
    PLV_Diffs[[i]]$LEFT[[band]] <- PLV[[i]]$LEFT[[band]][-2, -2]
    
    # Remove the second row and second column from the RIGHT band
    PLV_Diffs[[i]]$RIGHT[[band]] <- PLV[[i]]$RIGHT[[band]][-2, -2]
  }
}

# PLV_Diffs now contains the data with the second row and column removed



## 

# Create an empty list to store the averaged data
PLV_Diffs2 <- PLV_Diffs

# Loop through each subject in PLV_Diffs
for (i in seq_along(PLV_Diffs)) {
  
  # For each subject, loop through the frequency bands (delta, theta, etc.)
  for (band in names(PLV_Diffs[[i]]$LEFT)) {
    
    # Average the corresponding values in LEFT and RIGHT
    avg_matrix <- (PLV_Diffs[[i]]$LEFT[[band]] + PLV_Diffs[[i]]$RIGHT[[band]]) / 2
    
    # Store the averaged matrix in the new list
    PLV_Diffs2[[i]][[band]] <- avg_matrix
  }
  
  # Remove the LEFT and RIGHT lists as they are now averaged
  PLV_Diffs2[[i]]$LEFT <- NULL
  PLV_Diffs2[[i]]$RIGHT <- NULL
}

# PLV_Diffs2 now contains the averaged matrices


## 

# Create an empty list to store the differences
PLV_Diffs3 <- PLV_Diffs2

# Loop through each subject in PLV_Diffs2
for (i in seq_along(PLV_Diffs2)) {
  
  # For each subject, loop through the frequency bands (delta, theta, etc.)
  for (band in names(PLV_Diffs2[[i]])) {
    
    # Extract the relevant rows and columns (columns 3, 4, 5)
    first_row <- PLV_Diffs2[[i]][[band]][1, 3:5]
    second_row <- PLV_Diffs2[[i]][[band]][2, 3:5]
    
    # Calculate the difference (first row minus second row)
    diff_row <- first_row - second_row
    
    # Create a new matrix with the difference row and rename the row as "Difference"
    diff_matrix <- matrix(diff_row, nrow = 1)
    colnames(diff_matrix) <- colnames(PLV_Diffs2[[i]][[band]])[3:5]
    rownames(diff_matrix) <- "Difference"
    
    # Replace the original matrix in PLV_Diffs3 with the difference matrix
    PLV_Diffs3[[i]][[band]] <- diff_matrix
  }
}

# PLV_Diffs3 now contains the difference matrices with the new row named "Difference"

# Create an empty data frame to store the results
Effect_Sizes_Both <- data.frame(ID = character(),
                                Band = character(),
                                Motor_Region = character(),
                                Difference = numeric(),
                                stringsAsFactors = FALSE)

# Loop through each subject in PLV_Diffs3
for (i in seq_along(PLV_Diffs3)) {
  
  # Get the subject name
  subject_name <- names(PLV_Diffs3)[i]
  
  # For each subject, loop through the frequency bands (delta, theta, etc.)
  for (band in names(PLV_Diffs3[[i]])) {
    
    # Extract the difference row from the matrix
    diff_row <- PLV_Diffs3[[i]][[band]]["Difference", ]
    
    # Convert the difference row into a data frame format
    diff_df <- data.frame(ID = subject_name,
                          Band = band,
                          Motor_Region = names(diff_row),
                          Difference = as.numeric(diff_row),
                          stringsAsFactors = FALSE)
    
    # Append the data to the Effect_Sizes_Both data frame
    Effect_Sizes_Both <- rbind(Effect_Sizes_Both, diff_df)
  }
}

# Sort the resulting data frame by ID, Band, and Motor_Region
Effect_Sizes_Both <- Effect_Sizes_Both[order(Effect_Sizes_Both$ID, Effect_Sizes_Both$Band, Effect_Sizes_Both$Motor_Region), ]

Effect_Sizes_Both$Band <- tools::toTitleCase(Effect_Sizes_Both$Band)

# View the final data frame
Effect_Sizes_Both



# List all variables in the workspace
all_vars <- ls()

# Specify the variables you want to keep
keep_vars <- c("Effect_Sizes_Both", "PLV_Diffs")

# Remove all variables except the ones you want to keep
rm(list = setdiff(all_vars, keep_vars))
rm(all_vars, keep_vars)




