
%% Locate the sources

sKernels = bst_process('CallProcess', 'process_select_files_results', [], [], ...
    'subjectname',   '', ...
    'condition',     '', ...
    'tag',           'MN', ...
    'includebad',    0, ...
    'includeintra',  0, ...
    'includecommon', 0);

%% Extract the filenames

sKernels_Filenames = cell(1, length(sKernels)); % Initialize the cell array with the correct size
for i = 1:length(sKernels)
    sKernels_Filenames{i} = sKernels(i).FileName; % Use curly braces to assign values to cell array elements
end

clear i;
clc;

%% Locate the PTEs 

LEFT_Real_PTEs = bst_process('CallProcess', 'process_select_files_timefreq', [], [], ...
    'subjectname',   '', ...
    'condition',     '', ...
    'tag',           'LEFT_Real_PTEs', ...
    'includebad',    0, ...
    'includeintra',  0, ...
    'includecommon', 0);

RIGHT_Real_PTEs = bst_process('CallProcess', 'process_select_files_timefreq', [], [], ...
    'subjectname',   '', ...
    'condition',     '', ...
    'tag',           'RIGHT_Real_PTEs', ...
    'includebad',    0, ...
    'includeintra',  0, ...
    'includecommon', 0);

LEFT_Flipped_PTEs = bst_process('CallProcess', 'process_select_files_timefreq', [], [], ...
    'subjectname',   '', ...
    'condition',     '', ...
    'tag',           'LEFT_Flipped_PTEs', ...
    'includebad',    0, ...
    'includeintra',  0, ...
    'includecommon', 0);

RIGHT_Flipped_PTEs = bst_process('CallProcess', 'process_select_files_timefreq', [], [], ...
    'subjectname',   '', ...
    'condition',     '', ...
    'tag',           'RIGHT_Flipped_PTEs', ...
    'includebad',    0, ...
    'includeintra',  0, ...
    'includecommon', 0);

clc;

%% Extract the FileNames

LEFT_Real_PTEs_Filenames = cell(1, length(LEFT_Real_PTEs)); % Initialize the cell array with the correct size
for i = 1:length(LEFT_Real_PTEs)
    LEFT_Real_PTEs_Filenames{i} = LEFT_Real_PTEs(i).FileName; % Use curly braces to assign values to cell array elements
end

RIGHT_Real_PTEs_Filenames = cell(1, length(RIGHT_Real_PTEs)); % Initialize the cell array with the correct size
for i = 1:length(RIGHT_Real_PTEs)
    RIGHT_Real_PTEs_Filenames{i} = RIGHT_Real_PTEs(i).FileName; % Use curly braces to assign values to cell array elements
end

LEFT_Flipped_PTEs_Filenames = cell(1, length(LEFT_Flipped_PTEs)); % Initialize the cell array with the correct size
for i = 1:length(LEFT_Flipped_PTEs)
    LEFT_Flipped_PTEs_Filenames{i} = LEFT_Flipped_PTEs(i).FileName; % Use curly braces to assign values to cell array elements
end

RIGHT_Flipped_PTEs_Filenames = cell(1, length(RIGHT_Flipped_PTEs)); % Initialize the cell array with the correct size
for i = 1:length(RIGHT_Flipped_PTEs)
    RIGHT_Flipped_PTEs_Filenames{i} = RIGHT_Flipped_PTEs(i).FileName; % Use curly braces to assign values to cell array elements
end

clear i;
clc;

%% Extract the SubjectNames

SubjectNames = cell(1, 90); % Initialize the cell array with the correct size
for i = 1:90
    SubjectNames{i} = sFiles(i).SubjectName; % Use curly braces to assign values to cell array elements
end

for i = 1:length(SubjectNames)
    SubjectNames{i} = strrep(SubjectNames{i}, '-', '');
end

clear i;
clc;

%% Export to file iteratively

for i = 1:length(LEFT_Real_PTEs_Filenames)
    RawFiles = {['/home/oscar/Desktop/PTE_Matrices/LEFT/Real/',SubjectNames{i},'.mat']};
    bst_process('CallProcess', 'process_export_file', LEFT_Real_PTEs_Filenames{i}, [], 'exporttimefreq', {RawFiles{1}, 'BST'});
end
clear ans i sFiles RawFiles

for i = 1:length(RIGHT_Real_PTEs_Filenames)
    RawFiles = {['/home/oscar/Desktop/PTE_Matrices/RIGHT/Real/',SubjectNames{i},'.mat']};
    bst_process('CallProcess', 'process_export_file', RIGHT_Real_PTEs_Filenames{i}, [], 'exporttimefreq', {RawFiles{1}, 'BST'});
end
clear ans i sFiles RawFiles

for i = 1:length(LEFT_Flipped_PTEs_Filenames)
    RawFiles = {['/home/oscar/Desktop/PTE_Matrices/LEFT/Flipped/',SubjectNames{i},'.mat']};
    bst_process('CallProcess', 'process_export_file', LEFT_Flipped_PTEs_Filenames{i}, [], 'exporttimefreq', {RawFiles{1}, 'BST'});
end
clear ans i sFiles RawFiles

for i = 1:length(RIGHT_Flipped_PTEs_Filenames)
    RawFiles = {['/home/oscar/Desktop/PTE_Matrices/RIGHT/Flipped/',SubjectNames{i},'.mat']};
    bst_process('CallProcess', 'process_export_file', RIGHT_Flipped_PTEs_Filenames{i}, [], 'exporttimefreq', {RawFiles{1}, 'BST'});
end
clear ans i sFiles RawFiles
