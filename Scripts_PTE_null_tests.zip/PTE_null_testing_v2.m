%% VERSION 2: Shuffling the phases and permuting

%% First we need to store the "hemisphere_band" matrices as variables

% don't forget to change LEFT Beta beta

sFiles = bst_process('CallProcess', 'process_select_files_matrix', [], [], ...
    'subjectname',   '', ...
    'condition',     '', ...
    'tag',           'LEFT_Beta', ... % Change the name to whatever you need
    'includebad',    0, ...
    'includeintra',  0, ...
    'includecommon', 0);

sFiles_Filenames = cell(1, length(sFiles)); % Initialize the cell array with the correct size
for i = 1:length(sFiles)
    sFiles_Filenames{i} = sFiles(i).FileName; % Use curly braces to assign values to cell array elements
end

clear i;
clc;

%% Now we export all matrices to our local machine to be retrieved later

SubjectNames = cell(1, 90); % Initialize the cell array with the correct size
for i = 1:90
    SubjectNames{i} = sFiles(i).SubjectName; % Use curly braces to assign values to cell array elements
end

for i = 1:length(SubjectNames)
    SubjectNames{i} = strrep(SubjectNames{i}, '-', '');
end

for i = 1:length(sFiles_Filenames)
    RawFiles = {['/home/oscar/Desktop/PTE_Matrices/LEFT/beta/',SubjectNames{i},'.mat']};
    bst_process('CallProcess', 'process_export_file', sFiles_Filenames{i}, [], 'exportmatrix', {RawFiles{1}, 'BST'});
end
clc
clear ans i sFiles RawFiles

%% After we have exported we can now call the matrices and extract the vectors we need

% Don't forget to change: LEFT beta

% Define the directory containing the .mat files
directory = '/home/oscar/Desktop/PTE_Matrices/LEFT/beta/';

% Get a list of all .mat files in the directory
matFiles = dir(fullfile(directory, '*.mat'));

% Initialize cell arrays to hold the extracted values
numFiles = length(matFiles);
LEFT_beta_M1 = cell(1, numFiles);
LEFT_beta_dPMC = cell(1, numFiles);
LEFT_beta_vPMC = cell(1, numFiles);
LEFT_beta_A1 = cell(1, numFiles);

% Iterate through each .mat file
for i = 1:numFiles
    % Load the ith .mat file
    matFile = fullfile(directory, matFiles(i).name);
    LEFT = load(matFile);
    
        % Compute the required variables
    LEFT_M1 = LEFT.Value(1,:)';
    LEFT_dPMC = LEFT.Value(2,:)';
    LEFT_vPMC = LEFT.Value(3,:)';
    LEFT_A1 = LEFT.Value(4,:)';
    
    % Store the variables in the corresponding cell arrays
    LEFT_beta_M1{i} = LEFT_M1;
    LEFT_beta_dPMC{i} = LEFT_dPMC;
    LEFT_beta_vPMC{i} = LEFT_vPMC;
    LEFT_beta_A1{i} = LEFT_A1;
end

% Display a message indicating completion
disp('Processing complete.');
clear data directory i vectorLength LEFT_A1 LEFT_dPMC LEFT_M1 LEFT_vPMC LEFT numFiles matFile matFiles LEFT

%% Loop to recompute Real PTEs 

beta_LEFT_A1_M1_Real_PTEs = zeros(90,1);
beta_LEFT_M1_A1_Real_PTEs = zeros(90,1);
% beta_LEFT_A1_dPMC_Real_PTEs = zeros(90,1);
% beta_LEFT_dPMC_A1_Real_PTEs = zeros(90,1);
% beta_LEFT_A1_vPMC_Real_PTEs = zeros(90,1);
% beta_LEFT_vPMC_A1_Real_PTEs = zeros(90,1);

parpool('local', 10); % we will get faster results if we parallelize operations
parfor i = 1:90
        rtA1 = LEFT_beta_A1{i};
        [~, PTE_LEFT_A1_M1_REAL]    = PhaseTE_MF([rtA1, LEFT_beta_M1{i}]);
%         [~, PTE_LEFT_A1_dPMC_REAL]  = PhaseTE_MF([rtA1, LEFT_beta_dPMC{i}]);
%         [~, PTE_LEFT_A1_vPMC_REAL]  = PhaseTE_MF([rtA1, LEFT_beta_vPMC{i}]);
        
        % Store the PTE values in the ith and xth place of the arrays
        beta_LEFT_A1_M1_Real_PTEs(i)   = PTE_LEFT_A1_M1_REAL(1,2);
        beta_LEFT_M1_A1_Real_PTEs(i)   = PTE_LEFT_A1_M1_REAL(2,1);
%         beta_LEFT_A1_dPMC_Real_PTEs(i) = PTE_LEFT_A1_dPMC_REAL(1,2);
%         beta_LEFT_dPMC_A1_Real_PTEs(i) = PTE_LEFT_A1_dPMC_REAL(2,1);
%         beta_LEFT_A1_vPMC_Real_PTEs(i) = PTE_LEFT_A1_vPMC_REAL(1,2);
%         beta_LEFT_vPMC_A1_Real_PTEs(i) = PTE_LEFT_A1_vPMC_REAL(2,1);
        fprintf('Completed subject #%d\n', i);
end
delete(gcp); % turn off parallel pool to save resources

clear i ans rtA1 PTE_LEFT_A1_M1_REAL PTE_LEFT_A1_dPMC_REAL;

% We now compute and display the group-averaged means in order to compare them to the original PTE values

mean(beta_LEFT_A1_M1_Real_PTEs(:,1))
mean(beta_LEFT_M1_A1_Real_PTEs(:,1))
% mean(beta_LEFT_A1_dPMC_Real_PTEs(:,1))
% mean(beta_LEFT_dPMC_A1_Real_PTEs(:,1))
% mean(beta_LEFT_A1_vPMC_Real_PTEs(:,1))
% mean(beta_LEFT_vPMC_A1_Real_PTEs(:,1))

clear ans;

%%  Phase-shuffle permutation loop

clc;

% Initialize arrays to hold the phase-shuffled PTE values

perm = 1000; % how many permutations we will use; 1000 is the standard nowadays
beta_LEFT_A1_M1_Shuffled_PTEs = zeros(90,perm);
beta_LEFT_M1_A1_Shuffled_PTEs = zeros(90,perm);
% beta_LEFT_A1_dPMC_Shuffled_PTEs = zeros(90,perm);
% beta_LEFT_dPMC_A1_Shuffled_PTEs = zeros(90,perm);
% beta_LEFT_A1_vPMC_Shuffled_PTEs = zeros(90,perm);
% beta_LEFT_vPMC_A1_Shuffled_PTEs = zeros(90,perm);

parpool('local', 10); % we will get faster results if we parallelize operations
for x = 1:perm % outer loop controls the permutation
    parfor i = 1:90 % inner loop controls the subject
        LTHA1_PhSh = PhaseShuffle(LEFT_beta_A1{i}); % we can put it outside because we are only shuffling A1
        [~, PTE_LEFT_A1_M1_SHUFFLED]    = PhaseTE_MF([LTHA1_PhSh, LEFT_beta_M1{i}]);
%         [~, PTE_LEFT_A1_dPMC_SHUFFLED]  = PhaseTE_MF([LTHA1_PhSh, LEFT_beta_dPMC{i}]);
%         [~, PTE_LEFT_A1_vPMC_SHUFFLED]  = PhaseTE_MF([LTHA1_PhSh, LEFT_beta_vPMC{i}]);
        
        % We store the PTE values in the ith and xth place of the arrays
        beta_LEFT_A1_M1_Shuffled_PTEs(i,x) = PTE_LEFT_A1_M1_SHUFFLED(1,2);
        beta_LEFT_M1_A1_Shuffled_PTEs(i,x) = PTE_LEFT_A1_M1_SHUFFLED(2,1);
%         beta_LEFT_A1_dPMC_Shuffled_PTEs(i,x) = PTE_LEFT_A1_dPMC_SHUFFLED(1,2);
%         beta_LEFT_dPMC_A1_Shuffled_PTEs(i,x) = PTE_LEFT_A1_dPMC_SHUFFLED(2,1);
%         beta_LEFT_A1_vPMC_Shuffled_PTEs(i,x) = PTE_LEFT_A1_vPMC_SHUFFLED(1,2);
%         beta_LEFT_vPMC_A1_Shuffled_PTEs(i,x) = PTE_LEFT_A1_vPMC_SHUFFLED(2,1);

        %fprintf('Completed subject #%d\n', i); 
    end
    fprintf('Completed permutation #%d\n', x); % This we leave uncommented to keep track of the output  
end
delete(gcp); % turn off parallel pool since we're done
clear ans perm x 

%% Move onto Plot_PTE_null.m (unless you're computing THETA left and GAMMA2 left&right)

%% Continue only for THETA left and GAMMA2 left&right

% We compute the A1 to avg motor region direction (unperturbed PTEs)

beta_LEFT_A1_AVG_Real_PTEs = [beta_LEFT_A1_dPMC_Real_PTEs, beta_LEFT_A1_M1_Real_PTEs, beta_LEFT_A1_vPMC_Real_PTEs];
beta_LEFT_A1_AVG_Real_PTEs = mean(beta_LEFT_A1_AVG_Real_PTEs, 2);

% We compute the avg motor region to A1 direction (unperturbed PTEs)

beta_LEFT_AVG_A1_Real_PTEs = [beta_LEFT_dPMC_A1_Real_PTEs, beta_LEFT_M1_A1_Real_PTEs, beta_LEFT_vPMC_A1_Real_PTEs];
beta_LEFT_AVG_A1_Real_PTEs = mean(beta_LEFT_AVG_A1_Real_PTEs, 2);

% We compute the A1 to avg motor region direction (shuffled PTEs)

beta_LEFT_A1_AVG_combined = cat(3, beta_LEFT_A1_dPMC_Shuffled_PTEs, beta_LEFT_A1_M1_Shuffled_PTEs, beta_LEFT_A1_vPMC_Shuffled_PTEs);
beta_LEFT_A1_AVG_Shuffled_PTEs = mean(beta_LEFT_A1_AVG_combined, 3);
clear beta_LEFT_A1_AVG_combined

% We compute the avg motor region to A1 direction (shuffled PTEs)

beta_LEFT_AVG_A1_combined = cat(3, beta_LEFT_dPMC_A1_Shuffled_PTEs, beta_LEFT_M1_A1_Shuffled_PTEs, beta_LEFT_vPMC_A1_Shuffled_PTEs);
beta_LEFT_AVG_A1_Shuffled_PTEs = mean(beta_LEFT_AVG_A1_combined, 3);
clear beta_LEFT_AVG_A1_combined

%% Move onto Plot_PTE_null.m 