%% After we have exported we can now call the matrices and extract the vectors we need

% Don't forget to change: LEFT theta

% Define the directory containing the .mat files
directory = '/home/oscar/Desktop/PTE_Matrices/LEFT/theta/';

% Get a list of all .mat files in the directory
matFiles = dir(fullfile(directory, '*.mat'));

% Initialize cell arrays to hold the extracted values
numFiles = length(matFiles);
LEFT_theta_M1 = cell(1, numFiles);
LEFT_theta_dPMC = cell(1, numFiles);
LEFT_theta_vPMC = cell(1, numFiles);
LEFT_theta_A1 = cell(1, numFiles);

% Iterate through each .mat file
for i = 1:numFiles
    % Load the ith .mat file
    matFile = fullfile(directory, matFiles(i).name);
    LEFT = load(matFile);
    
        % Compute the required variables
    LEFT_M1 = LEFT.Value(1,:)';
    LEFT_dPMC = LEFT.Value(2,:)';
    LEFT_vPMC = LEFT.Value(3,:)';
    LEFT_A1 = LEFT.Value(4,:)';
    
    % Store the variables in the corresponding cell arrays
    LEFT_theta_M1{i} = LEFT_M1;
    LEFT_theta_dPMC{i} = LEFT_dPMC;
    LEFT_theta_vPMC{i} = LEFT_vPMC;
    LEFT_theta_A1{i} = LEFT_A1;
end

% Display a message indicating completion
disp('Processing complete.');
clear data directory i vectorLength LEFT_A1 LEFT_dPMC LEFT_M1 LEFT_vPMC LEFT numFiles matFile matFiles LEFT

%% Real data loop

LEFT_theta_AVG = [LEFT_theta_M1, LEFT_theta_dPMC, LEFT_theta_vPMC];
LEFT_theta_AVG = mean(LEFT_theta_AVG, 2);

theta_LEFT_A1_AVG_Real_PTEs = zeros(90,1);
theta_LEFT_AVG_A1_Real_PTEs = zeros(90,1);

parpool('local', 10);
parfor i = 1:90
        rtA1 = LEFT_theta_A1{i};
        [~, PTE_LEFT_A1_M1_REAL]    = PhaseTE_MF([rtA1, LEFT_theta_AVG{i}]);
        
        % Store the PTE values in the ith and xth place of the arrays
        theta_LEFT_A1_AVG_Real_PTEs(i)   = PTE_LEFT_A1_AVG_REAL(1,2);
        theta_LEFT_AVG_A1_Real_PTEs(i)   = PTE_LEFT_A1_AVG_REAL(2,1);
        fprintf('Completed subject #%d\n', i);
end
delete(gcp);

clear i ans rtA1 PTE_LEFT_A1_AVG_REAL;

mean(theta_LEFT_A1_AVG_Real_PTEs(:,1))
mean(theta_LEFT_AVG_A1_Real_PTEs(:,1))

clear ans;

%%  Permutation loop

% Initialize arrays to hold the PTE values

perm = 1000;
theta_LEFT_A1_AVG_Shuffled_PTEs = zeros(90,perm);
theta_LEFT_AVG_A1_Shuffled_PTEs = zeros(90,perm);

% parpool('local', 10);
for x = 1:perm
    parfor i = 1:90
        LTHA1_PhSh = PhaseShuffle(LEFT_theta_A1{i}); % only shuffling A1
        [~, PTE_LEFT_A1_AVG_SHUFFLED]    = PhaseTE_MF([LTHA1_PhSh, LEFT_theta_AVG{i}]);
        % Store the PTE values in the ith and xth place of the arrays
        theta_LEFT_A1_AVG_Shuffled_PTEs(i,x) = PTE_LEFT_A1_AVG_SHUFFLED(1,2);
        theta_LEFT_AVG_A1_Shuffled_PTEs(i,x) = PTE_LEFT_A1_AVG_SHUFFLED(2,1);
        fprintf('Completed subject #%d\n', i);
    end
    fprintf('Completed permutation #%d\n', x);   
end
delete(gcp);
clear ans perm x 