%% Plot PTE null distribution  

% Don't forget to change: Beta beta LEFT M1_A1 M1-A1 

figure;
histogram(mean(beta_LEFT_M1_A1_Shuffled_PTEs), 'NumBins', 100); % "mean" because we're collapsing across subjects
title('Beta LEFT M1-A1 direction: Phase-shuffled PTEs');
xlabel('PTE values');
ylabel('Number of observed instances');

percentile_95 = prctile(mean(beta_LEFT_M1_A1_Shuffled_PTEs), 95);
hold on;
plot([percentile_95, percentile_95], ylim, 'r--', 'LineWidth', 2);
hold off;
line_your_value = mean(beta_LEFT_M1_A1_Real_PTEs);  % here we add the line corresponding to the original PTE value
hold on;
plot([line_your_value, line_your_value], ylim, 'g--', 'LineWidth', 2);
real_pte_rank = sum(mean(beta_LEFT_M1_A1_Shuffled_PTEs) <= line_your_value) / numel(mean(beta_LEFT_M1_A1_Shuffled_PTEs)) * 100;

text_x = 0.9985 * line_your_value;  % use following values if text is too far from line: 1.005 0.995 0.815
text_y = 0.8 * max(ylim); 
text(text_x, text_y, ['Percentile of original PTE: ', sprintf('%.2f', real_pte_rank)], ...
    'HorizontalAlignment', 'LEFT', 'VerticalAlignment', 'bottom', 'Color', 'green');

legend('Phase-shuffled PTE values', '95th percentile', 'Original PTE value');

if line_your_value > percentile_95 % if the original PTE is higher than 95% of the shuffled PTEs
    disp('Woo-hoo! The original PTE value is above the 95th percentile!'); % this is what we're hoping for
else
    disp('Sadly, the original PTE value is not above the 95th percentile.'); % hopefully we won't get this
end

set(gcf, 'PaperPosition', [0 0 19 8]);  % Width and height in inches (1900x800 pixels at 100 dpi)
% saveas(gcf, '/home/oscar/Desktop/18chan/Tf_matrices/s001/Moveograms/Cluster1_LEFT.png');
clear x text_x text_y line_your_value percentile_95 real_pte_rank