clear % run master_script

path = {'/home/oscar/TEST'};
% empty_date = {'';'20120726';'20120727';'20130315';'20130318';'20130527'};

for s = 1:7
    Master_script(path,s)
end
