%% %%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 1: Import the datasets
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

SubjectNames = cell([1 13]);

SubjectNames(1) = {'S1AMPE-04'};
SubjectNames(2) = {'S1AMPE-06'}; 
SubjectNames(3) = {'S1AMPE-07'}; 
SubjectNames(4) = {'S1AMPE-08'}; 
SubjectNames(5) = {'S1AMPE-09'};
SubjectNames(6) = {'S1AMPE-15'}; 
SubjectNames(7) = {'S1AMPE-16'}; 
SubjectNames(8) = {'S1AMPE-17'}; 
SubjectNames(9) = {'S1AMPE-18'}; 
SubjectNames(10) = {'S1AMPE-23'}; 
SubjectNames(11) = {'S1AMPE-24'}; 
SubjectNames(12) = {'S1AMPE-25'}; 
SubjectNames(13) = {'S1AMPE-29'};

FileNames = cell([1 13]);

FileNames(1) = {'S1AMPE0004'};
FileNames(2) = {'S1AMPE0006'}; 
FileNames(3) = {'S1AMPE0007'}; 
FileNames(4) = {'S1AMPE0008'}; 
FileNames(5) = {'S1AMPE0009'};
FileNames(6) = {'S1AMPE0015'}; 
FileNames(7) = {'S1AMPE0016'}; 
FileNames(8) = {'S1AMPE0017'}; 
FileNames(9) = {'S1AMPE0018'}; 
FileNames(10) = {'S1AMPE0023'}; 
FileNames(11) = {'S1AMPE0024'}; 
FileNames(12) = {'S1AMPE0025'}; 
FileNames(13) = {'S1AMPE0029'};

%% Import individual subjects and their meg and empty room data

% 1.1 First we pre-allocate a cell array called 'SubjectNames'

RawEEGFiles = cell([1 13]);

for s = 1:13
    RawEEGFiles{s} = {[...
        '/home/oscar/DATA/S1AMPE/DATA/',SubjectNames{s},'/',FileNames{s},'.eeg']};
end
clear s;

% Finally, we will call on the import_data_raw function iteratively

for s = 1:13
bst_process('CallProcess', 'process_import_data_raw', [], [], ...
    'subjectname',    SubjectNames{s}, ...
    'datafile',       {RawEEGFiles{s}, 'EEG-BRAINAMP'}, ...
    'channelreplace', 0, ...
    'channelalign',   0, ...
    'evtmode',        'value');
end
clear s;
