
                                 %% %% %% MASTER SCRIPT: OMEGA %% %% %% 
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 0: Add brainstorm paths and load the GUI 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                                        
addpath ('/home/alix/matlabtoolbox/brainstorm3');
addpath ('/home/alix/matlabtoolbox/brainstorm_db');
% addpath ('/home/alix/matlabtoolbox/spm12'); 
brainstorm;
clc

%% %%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 1: Import the datasets
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Switch to 'STEP1_ImportDatasets.m and run the whole thing

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% STEP 2: Reconstruct the surfaces 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Switch to 'recon_all.m' script and run step 1.7 and then go to STEP 3

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 3.1: Report initial corregistration
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% We start by creating a variable with All subjects 
   sFilesAll = bst_process('CallProcess', 'process_select_files_data', [], [], ...
       'subjectname', 'All');
     
% We then create a variable with subjects with the tag: 'task-rest' 
% These are basically all subjects and files EXCLUDING sub-emptyroom's
   sFilesRest = bst_process('CallProcess', 'process_select_tag', sFilesAll, [], ...
       'tag',    'task-baselineresting', ...
       'search', 1, ...  % Search the file names
       'select', 1);  % Select only the files with the tag
   
% Now we will take snapshots of the sensors/MRI registration and save them in one image
bst_report('Start', sFilesRest);
bst_process('CallProcess', 'process_snapshot', sFilesRest, [], ...
      'target',         1, ...  % Sensors/MRI registration
      'modality',       1, ...  % MEG (All)
      'orient',         1);  % left
ReportFile = bst_report('Save', sFilesRest);
bst_report('Open', ReportFile);
% bst_report('Export', ReportFile, ExportDir);

                    %% %% %% MAKE SURE TO DELETE ANY DE-SKINNED SUBJECTS BEFORE PROCEEDING!!! %% %% %%
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 3.2: Remove headpoints and refine the registration
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Next, we will remove the extra head points from the 'FilesRest' subjects
bst_process('CallProcess', 'process_headpoints_remove', sFilesRest, [], ...
    'zlimit', 0);

% And then we will use the 'Refine headpoints' function:
bst_process('CallProcess', 'process_headpoints_refine', sFilesRest, []);

% Let's have a look at the result by taking snapshots once again:
bst_report('Start', sFilesRest);
bst_process('CallProcess', 'process_snapshot', sFilesRest, [], ...
      'target',         1, ...  % Sensors/MRI registration
      'modality',       1, ...  % MEG (All)
      'orient',         1);  % left
ReportFile = bst_report('Save', sFilesRest);
bst_report('Open', ReportFile);
% bst_report('Export', ReportFile, ExportDir);

% NOTE: the report/s can be accessed via the following directory:
% /home/alix/.brainstorm/reports OR /home/oscar/.brainstorm/reports

% addpath ('/home/alix/.brainstorm/reports');
% addpath ('/home/oscar/.brainstorm/reports');

               %% %% %% MAKE SURE TO COMPARE THE TWO REGISTRATION REPORTS BEFORE PROCEEDING!!! %% %% %% 
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 4: Convert to continuous & PSD 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% First we use the process: Convert to continuous (CTF)
sFilesCTF = bst_process('CallProcess', 'process_ctf_convert', sFilesAll, [], ...
    'rectype', 2);  % Continuous

% Then we compute the Power spectrum density (Welch)
bst_process('CallProcess', 'process_psd', sFilesCTF, [], ... 
    'timewindow',  [], ...
    'win_length',  4, ...
    'win_overlap', 50, ...
    'units',       'physical', ...  % Physical: U2/Hz
    'sensortypes', 'MEG', ...
    'win_std',     0, ...
    'edit',        struct(...
         'Comment',         'Power', ...
         'TimeBands',       [], ...
         'Freqs',           [], ...
         'ClusterFuncTime', 'none', ...
         'Measure',         'power', ...
         'Output',          'all', ...
         'SaveKernel',      0));
     
                        %% %% %% MAKE SURE TO INSPECT THE PSD PLOTS BEFORE PROCEEDING!!! %% %% %%      
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 5: Notch and bandpass filter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% First we notch filter at 60Hz + harmonics: 120Hz 180Hz 240Hz 300Hz
sFilesNotch = bst_process('CallProcess', 'process_notch', sFilesCTF, [], ...
    'sensortypes', 'MEG', ...
    'freqlist',    [60, 120, 180, 240, 300], ...
    'cutoffW',     2, ... % double check
    'useold',      0, ...
    'read_all',    0);

% Then we band-pass filter from 0.3Hz-80Hz and create variable sFilesBand
sFilesBand = bst_process('CallProcess', 'process_bandpass', sFilesNotch, [], ...
    'sensortypes', 'MEG', ...
    'highpass',    0.3, ...
    'lowpass',     200, ...
    'tranband',    0, ...
    'attenuation', 'strict', ...  % 60dB
    'ver',         '2019', ...  % 2019
    'mirror',      0, ...
    'read_all',    0);

% We will compute the PSD again so that we can compare the two
bst_process('CallProcess', 'process_psd', sFilesBand, [], ...
    'timewindow',  [], ...
    'win_length',  4, ...
    'win_overlap', 50, ...
    'units',       'physical', ...  % Physical: U2/Hz
    'sensortypes', 'MEG', ...       % We can ignore the 'EEG' channels now
    'win_std',     0, ...
    'edit',        struct(...
         'Comment',         'Power', ...
         'TimeBands',       [], ...
         'Freqs',           [], ...
         'ClusterFuncTime', 'none', ...
         'Measure',         'power', ...
         'Output',          'all', ...
         'SaveKernel',      0));
     
%  % Uncomment this if you want to delete the Raw and Notched folders:

%  bst_process('CallProcess', 'process_delete', [sFilesCTF, sFilesNotch], [], ...
%   'target', 2);     

%  bst_process('CallProcess', 'process_delete', (sFilesCTF), [], ...
%   'target', 2);
   
%% Uncomment this if you need to run PSD again only for sFilesBand
% 
% % Then we compute the Power spectrum density (Welch)
% bst_process('CallProcess', 'process_psd', sFilesBand, [], ... 
%     'timewindow',  [], ...
%     'win_length',  4, ...
%     'win_overlap', 50, ...
%     'units',       'physical', ...  % Physical: U2/Hz
%     'sensortypes', 'MEG', ...
%     'win_std',     0, ...
%     'edit',        struct(...
%          'Comment',         'Power', ...
%          'TimeBands',       [], ...
%          'Freqs',           [], ...
%          'ClusterFuncTime', 'none', ...
%          'Measure',         'power', ...
%          'Output',          'all', ...
%          'SaveKernel',      0));

                            %% %% %% MAKE SURE TO COMPARE THE TWO PSD PLOTS FOR EACH SUBJECT BEFORE PROCEEDING!!! %% %% %%  
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 6: Detecth heartbeats, blinks and saccades 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% We select file names corresponding to non-emptyroom subjects within sFilesBand 
sFilesSSP = bst_process('CallProcess', 'process_select_tag', sFilesBand, [], ...
       'tag',    'task-baselineresting', ...
       'search', 1, ...  % Search the file names
       'select', 1);  % Select only the files with the tag

% We are ready to use the process 'Detect heartbeats' on these subjects
bst_process('CallProcess', 'process_evt_detect_ecg', sFilesSSP, [], ...
    'channelname', 'ECG', ...
    'timewindow',  [], ...
    'eventname',   'cardiac');

% And we can also use the process 'Detect eye blinks' on these subjects 
bst_process('CallProcess', 'process_evt_detect_eog', sFilesSSP, [], ...
    'channelname', 'VEOG', ...
    'timewindow',  [], ...
    'eventname',   'blink');

% Uncomment this if you want to also run a custom saccade detection
% Process: Detect: saccades
bst_process('CallProcess', 'process_evt_detect', sFilesSaccades, [], ...
    'eventname',    'saccades', ...
    'channelname',  'HEOG', ...
    'timewindow',   [], ...
    'bandpass',     [1.5, 7], ...
    'threshold',    2, ...
    'blanking',     0.8, ...
    'isnoisecheck', 0, ...
    'isclassify',   0);

                                     %% %% %% MAKE SURE TO REVIEW ALL EVENTS FOR EACH SUBJECT BEFORE PROCEEDING!!! %% %% %%  
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 7: Remove simultaneous and SSP corrections for heartbeats, blinks  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% We're ready to remove simultaneous cardiac and blink events from the data
bst_process('CallProcess', 'process_evt_remove_simult', sFilesSSP, [], ...
    'remove', 'cardiac', ...
    'target', 'blink', ...
    'dt',     0.25, ...
    'rename', 0);

% Now we can compute the SSP projection for the ECG artifact (cardiac)
bst_process('CallProcess', 'process_ssp_ecg', sFilesSSP, [], ...
    'eventname',   'cardiac', ...
    'sensortypes', 'MEG', ...
    'usessp',      0, ...
    'select',      1);

% As well as the SSP projection for the VEOG artifact (blink)
bst_process('CallProcess', 'process_ssp_eog', sFilesSSP, [], ...
    'eventname',   'blink', ...
    'sensortypes', 'MEG', ...
    'usessp',      1, ...
    'select',      1); 

%% Once you have reviewed the topography and timecourse of each projector, you can continue:

% Finally, we will calculate the SSP projector for the HEOG artifact (saccades)
% REMEMBER: this is preferable to doing bad segments (1-7Hz)
 
bst_process('CallProcess', 'process_ssp', sFilesSaccades, [], ...
    'timewindow',  [], ...
    'eventname',   'saccades', ...
    'eventtime',   [-0.2, 0.2], ...
    'bandpass',    [1.5 7], ...
    'sensortypes', 'MEG', ...
    'usessp',      1, ...
    'saveerp',     0, ...
    'method',      1, ...  % PCA: One component per sensor
    'select',      1);

% Verify this component and remove it 

% We will also create a report containing snapshots of all the SSP projectors
bst_report('Start', sFilesRest);
bst_process('CallProcess', 'process_snapshot', sFilesSSP, [], ...
      'target',         2, ...  % SSP projectors
      'modality',       1);     % MEG (All)
ReportFile = bst_report('Save', sFilesSSP);
bst_report('Open', ReportFile);
% bst_report('Export', ReportFile, ExportDir);

% NOTE: the report/s can be accessed via the following directory:
% % /home/alix/.brainstorm/reports


%% %%%%%%%%%%%%%%%%%%%%%%
% STEP 7.2: PSD post-SSPs
%%%%%%%%%%%%%%%%%%%%%%%%%

% We will compute the Power spectrum density (Welch) again:
bst_process('CallProcess', 'process_psd', sFilesBand, [], ...
    'timewindow',  [], ...
    'win_length',  4, ...
    'win_overlap', 50, ...
    'units',       'physical', ...  % Physical: U2/Hz
    'sensortypes', 'MEG', ...       % We can ignore the 'EEG' channels now
    'win_std',     0, ...
    'edit',        struct(...
         'Comment',         'Power', ...
         'TimeBands',       [], ...
         'Freqs',           [], ...
         'ClusterFuncTime', 'none', ...
         'Measure',         'power', ...
         'Output',          'all', ...
         'SaveKernel',      0));
 
                          %% %% %% MAKE SURE TO VERIFY SSP REPORT AND FIRST PROJECTORS BEFORE TICKING THEM!!! %% %% %% 
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 8: Create the noise matrix from empty room recordings
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% These are basically all subjects and files EXCLUDING sub-emptyroom's
sFilesNoiseRest = bst_process('CallProcess', 'process_select_tag', sFilesAll, [], ...
       'tag',    'sub-emptyroom', ...
       'search', 1, ...  % Search the file names
       'select', 1);  % Select only the files with the tag

% We need to select the files with tag: sub-emptyroom
sFilesNoiseBand = bst_process('CallProcess', 'process_select_tag', sFilesNoiseRest, [], ...
       'tag',    'meg_notch_band', ...
       'search', 1, ...  % Search the file names
       'select', 1);  % Select only the files with the tag

% Now we're ready to process the Covariance matrices
bst_process('CallProcess', 'process_noisecov', sFilesNoiseBand, [], ...
    'baseline',       [], ...
    'datatimewindow', [], ... % Remember: this camp needs to be empty if the above camp is empty
    'sensortypes',    'MEG', ...
    'target',         1, ...  % Noise covariance     (covariance over baseline time window)
    'dcoffset',       1, ...  % Block by block, to avoid effects of slow shifts in data
    'identity',       0, ...
    'copycond',       0, ... 
    'copysubj',       0, ...  % Mark zero! This copies covariance (i) to ALL conditions in ALL subjects
    'copymatch',      1, ...
    'replacefile',    1);  % 1 = replace redundant files
%% STEP 8.b COMPUTING DATA COVARIANCE (NECESSARY FOR BEAMFORMER KERNELS) 

% which files should we select here? Answer: sFilesBand 
sFilesDataCov = bst_process('CallProcess', 'process_select_tag', sFilesBand, [], ...
       'tag',    'task-baselineresting', ...
       'search', 1, ...  % Search the file names
       'select', 1);  % Select only the files with the tag
   
bst_process('CallProcess', 'process_noisecov', sFilesDataCov, [], ...
    'baseline',       [], ...
    'datatimewindow', [], ... % might change the number
    'sensortypes',    'MEG', ...
    'target',         2, ...  % Data covariance      (covariance over data time window)
    'dcoffset',       1, ...  % Block by block, to avoid effects of slow shifts in data
    'identity',       0, ...
    'copycond',       0, ... % Mark 0 because you only want data covariance in the meg_notch_bandpass data?
    'copysubj',       0, ... % Mark zero! This copies covariance (i) to ALL conditions in ALL subjects
    'copymatch',      0, ... % Mark 0 because you don't want to match data to emptyroom date
    'replacefile',    1);  % Replace redundant files

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 9: Compute the head model & sources
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% We can now compute the head model
sFilesHeadModel1=bst_process('CallProcess', 'process_headmodel', sFilesBand, [], ...
    'Comment',     '', ...
    'sourcespace', 1, ...  % Cortex surface
    'meg',         3, ...  % Overlapping spheres
    'eeg',         1, ...  % 
    'ecog',        1, ...  % 
    'seeg',        1, ...  % 
    'channelfile', '');

% And now we can translate the signals into source space and onto the head model  

sFilesKernel1 = bst_process('CallProcess', 'process_inverse_2018', sFilesTest, [], ...
    'output',  2, ...  % Kernel only: one per file
    'inverse', struct(...
         'Comment',        'MN: MEG', ... 
         'InverseMethod',  'minnorm', ... 
         'InverseMeasure', 'amplitude', ...
         'SourceOrient',   {{'fixed'}}, ...
         'Loose',          0.2, ...
         'UseDepth',       1, ...
         'WeightExp',      0.5, ...
         'WeightLimit',    10, ...
         'NoiseMethod',    'reg', ...
         'NoiseReg',       0.1, ...
         'SnrMethod',      'fixed', ...
         'SnrRms',         1e-06, ...
         'SnrFixed',       3, ...
         'ComputeKernel',  1, ...
         'DataTypes',      {{'MEG'}}));
    
% dSPM modeling
sFilesKernel2 = bst_process('CallProcess', 'process_inverse_2018', sFilesBand, [], ...
    'output',  2, ...  % Kernel only: one per file
    'inverse', struct(...
         'Comment',        'dSPM-unscaled: MEG', ...
         'InverseMethod',  'minnorm', ...
         'InverseMeasure', 'dspm2018', ...
         'SourceOrient',   {{'fixed'}}, ...
         'Loose',          0.2, ...
         'UseDepth',       1, ...
         'WeightExp',      0.5, ...
         'WeightLimit',    10, ...
         'NoiseMethod',    'reg', ...
         'NoiseReg',       0.1, ...
         'SnrMethod',      'fixed', ...
         'SnrRms',         1e-06, ...
         'SnrFixed',       3, ...
         'ComputeKernel',  1, ...
         'DataTypes',      {{'MEG'}})); 
     
% Beamformer modeling 
sFilesKernel3 = bst_process('CallProcess', 'process_inverse_2018', sFilesBand, [], ...
    'output',  2, ...  % Kernel only: one per file
    'inverse', struct(...
         'Comment',        'PNAI: MEG', ...
         'InverseMethod',  'lcmv', ...
         'InverseMeasure', 'nai', ...
         'SourceOrient',   {{'fixed'}}, ...
         'Loose',          0.2, ...
         'UseDepth',       1, ...
         'WeightExp',      0.5, ...
         'WeightLimit',    10, ...
         'NoiseMethod',    'reg', ...
         'NoiseReg',       0.1, ...
         'SnrMethod',      'rms', ...
         'SnrRms',         0, ...
         'SnrFixed',       3, ...
         'ComputeKernel',  1, ...
         'DataTypes',      {{'MEG'}}));
     
sFilesKernel4 = bst_process('CallProcess', 'process_inverse_2018', sFilesBand, [], ...
    'output',  2, ...  % Kernel only: one per file
    'inverse', struct(...
         'Comment',        'PNAI: MEG', ...
         'InverseMethod',  'lcmv', ...
         'InverseMeasure', 'nai', ...
         'SourceOrient',   {{'fixed'}}, ...
         'Loose',          0.2, ...
         'UseDepth',       1, ...
         'WeightExp',      0.5, ...
         'WeightLimit',    10, ...
         'NoiseMethod',    'median', ...
         'NoiseReg',       0.1, ...
         'SnrMethod',      'rms', ...
         'SnrRms',         1e-06, ...
         'SnrFixed',       3, ...
         'ComputeKernel',  1, ...
         'DataTypes',      {{'MEG'}}));   
    

%% STEP 9B CHECKING PSD QUALITY FOR INVERSE MODELS

%% For sFilekernel 1

% Create locator script for PSD files -- PENDING

sFilesKernel1_PSD = bst_process('CallProcess', 'process_psd', sFilesKernel1, [], ...
    'timewindow',  [], ...
    'win_length',  4, ...
    'win_overlap', 50, ...
    'units',       'physical', ...  % Physical: U2/Hz
    'clusters',    {}, ...
    'scoutfunc',   1, ...  % Mean
    'win_std',     0, ...
    'edit',        struct(...
         'Comment',         'Power,FreqBands', ...
         'TimeBands',       [], ...
         'Freqs',           {{'delta', '2, 4', 'mean'; 'theta', '5, 7', 'mean'; 'alpha', '8, 12', 'mean'; 'beta', '15, 29', 'mean'; 'gamma1', '30, 59', 'mean'; 'gamma2', '60, 90', 'mean'}}, ...
         'ClusterFuncTime', 'none', ...
         'Measure',         'power', ...
         'Output',          'all', ...
         'SaveKernel',      0));

% Process: Spectrum normalization
bst_process('CallProcess', 'process_tf_norm', sFilesKernel1_PSD, [], ...
    'normalize', 'relative2020', ...  % Relative power (divide by total power)
    'overwrite', 0);

% Save and display report
ReportFile = bst_report('Save', sFilesKernel1);
bst_report('Open', ReportFile);
% bst_report('Export', ReportFile, ExportDir); 

%% For sFilekernel 2

bst_process('CallProcess', 'process_psd', sFilesKernel2, [], ...
    'timewindow',  [], ...
    'win_length',  4, ...
    'win_overlap', 50, ...
    'units',       'physical', ...  % Physical: U2/Hz
    'clusters',    {}, ...
    'scoutfunc',   1, ...  % Mean
    'win_std',     0, ...
    'edit',        struct(...
         'Comment',         'Power,FreqBands', ...
         'TimeBands',       [], ...
         'Freqs',           {{'delta', '2, 4', 'mean'; 'theta', '5, 7', 'mean'; 'alpha', '8, 12', 'mean'; 'beta', '15, 29', 'mean'; 'gamma1', '30, 59', 'mean'; 'gamma2', '60, 90', 'mean'}}, ...
         'ClusterFuncTime', 'none', ...
         'Measure',         'power', ...
         'Output',          'all', ...
         'SaveKernel',      0));

% Process: Spectrum normalization
bst_process('CallProcess', 'process_tf_norm', sFilesKernel2, [], ...
    'normalize', 'relative2020', ...  % Relative power (divide by total power)
    'overwrite', 0);

% Save and display report
ReportFile = bst_report('Save', sFilesPSDK2);
bst_report('Open', ReportFile);
% bst_report('Export', ReportFile, ExportDir); 

%% For sFilekernel 3

bst_process('CallProcess', 'process_psd', sFilesKernel4, [], ...
    'timewindow',  [], ...
    'win_length',  4, ...
    'win_overlap', 50, ...
    'units',       'physical', ...  % Physical: U2/Hz
    'clusters',    {}, ...
    'scoutfunc',   1, ...  % Mean
    'win_std',     0, ...
    'edit',        struct(...
         'Comment',         'Power,FreqBands', ...
         'TimeBands',       [], ...
         'Freqs',           {{'delta', '2, 4', 'mean'; 'theta', '5, 7', 'mean'; 'alpha', '8, 12', 'mean'; 'beta', '15, 29', 'mean'; 'gamma1', '30, 59', 'mean'; 'gamma2', '60, 90', 'mean'}}, ...
         'ClusterFuncTime', 'none', ...
         'Measure',         'power', ...
         'Output',          'all', ...
         'SaveKernel',      0));

% Process: Spectrum normalization
bst_process('CallProcess', 'process_tf_norm', sFilesKernel3, [], ...
    'normalize', 'relative2020', ...  % Relative power (divide by total power)
    'overwrite', 0);

% Save and display report
ReportFile = bst_report('Save', sFilesPSDK3);
bst_report('Open', ReportFile);
% bst_report('Export', ReportFile, ExportDir); 
   
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% STEP 10: Generate Hybrid Atlases 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Unfortunately this is a very tedious manual step.

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 11: Compute Imaginary Coherency  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% OSCAR'S REGIONS OF INTEREST 
% We compute the Imaginary Coherence (NxN) for the LEFT hemisphere ROIs
sFilesCoh_LEFT = bst_process('CallProcess', 'process_cohere1n', sFilesKernel, [], ... 
    'timewindow',   [0, 299.998], ... % aka shortest participant scan
    'scouts',       {'Hybrid Atlas LEFT', {'Left_A1', 'Left_STG', 'Left_V1', 'Left_M1', 'Left_vPMC', 'Left_dPMC'}}, ... 
    'scoutfunc',    1, ...  % Mean
    'scouttime',    1, ...  % Before, but consult with Sylvain
    'removeevoked', 0, ...
    'cohmeasure',   'icohere2019', ...  % Imaginary Coherence (2019)IC    = |imag(C)|
    'overlap',      50, ... % Default, but consult with Sylvain
    'maxfreqres',   2, ...
    'maxfreq',      80, ...
    'outputmode',   1);  % Save individual results (one file per input file)

% We need to set the right name for the results: "sub-000X_ImgCoh_LEFT"
for i=1:length(SubjectNames)
bst_process('CallProcess', 'process_set_comment', sFilesCoh_LEFT(i).FileName, [], ...
    'tag',           ['',num2str(SubjectNames{i}),'_ImgCoh_LEFT'], ...
    'isindex',       0);
end

% Now we compute the Imaginary Coherence (NxN) for the RIGHT hemisphere ROIs
sFilesCoh_RIGHT = bst_process('CallProcess', 'process_cohere1n', sFilesKernel, [], ... 
    'timewindow',   [0, 299.998], ... % aka shortest participant scan
    'scouts',       {'Hybrid Atlas RIGHT', {'Right_A1', 'Right_STG', 'Right_V1', 'Right_M1', 'Right_vPMC', 'Right_dPMC'}}, ... 
    'scoutfunc',    1, ...  % Mean
    'scouttime',    1, ...  % Before, but consult with Sylvain
    'removeevoked', 0, ...
    'cohmeasure',   'icohere2019', ...  % Imaginary Coherence (2019)IC    = |imag(C)|
    'overlap',      50, ... % Default, but consult with Sylvain
    'maxfreqres',   2, ...
    'maxfreq',      80, ...
    'outputmode',   1);  % Save individual results (one file per input file)

% We need to set the right name for the results: "sub-000X_ImgCoh_RIGHT"
for i=1:length(SubjectNames)
bst_process('CallProcess', 'process_set_comment', sFilesCoh_RIGHT(i).FileName, [], ...
    'tag',           ['',num2str(SubjectNames{i}),'_ImgCoh_RIGHT'], ...
    'isindex',       0);
end

clear i;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 12: Compute Phase-locking value (ISPC)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% We compute the PLV (NxN) for the LEFT hemisphere ROIs 
sFilesPLV_LEFT = bst_process('CallProcess', 'process_plv1n', sFilesKernel1, [], ... 
    'timewindow',   [0, 299.998], ... % aka shortest participant scan
    'scouts',       {'Hybrid Atlas LEFT', {'Left_A1', 'Left_STG', 'Left_V1', 'Left_M1', 'Left_vPMC', 'Left_dPMC'}}, ... 
    'scoutfunc',  1, ...  % Mean
    'scouttime',  2, ...  % After
    'freqbands',  {'delta', '2, 4', 'mean'; 'theta', '5, 7', 'mean'; 'alpha', '8, 12', 'mean'; 'beta', '15, 29', 'mean'; 'gamma1', '30, 59', 'mean'; 'gamma2', '60, 80', 'mean'}, ...
    'keeptime',   0, ...
    'plvmeasure', 2, ...  % Magnitude
    'outputmode', 1);  % Save individual results (one file per input file)

% We need to set the right name for the results: "sub-000X_PLV_LEFT"
for i=1:length(SubjectNames)
bst_process('CallProcess', 'process_set_comment', sFilesPLV_LEFT(i).FileName, [], ...
    'tag',           ['',num2str(SubjectNames{i}),'_PLV_LEFT'], ...
    'isindex',       1); % add path to index
end

% We compute the PLV (NxN) for the RIGHT hemisphere ROIs
sFilesPLV_TEST = bst_process('CallProcess', 'process_plv1n', sFilesKernel1, [], ... 
    'timewindow',   [0, 299.998], ... % aka shortest participant scan
    'scouts',       {'Hybrid Atlas RIGHT', {'Right_A1', 'Right_STG', 'Right_V1', 'Right_M1', 'Right_vPMC', 'Right_dPMC'}}, ... 
    'scoutfunc',  1, ...  % Mean
    'scouttime',  2, ...  % After
    'freqbands',  {'delta', '2, 4', 'mean'; 'theta', '5, 7', 'mean'; 'alpha', '8, 12', 'mean'; 'beta', '15, 29', 'mean'; 'gamma1', '30, 59', 'mean'; 'gamma2', '60, 80', 'mean'}, ...
    'keeptime',   0, ...
    'plvmeasure', 2, ...  % Magnitude
    'outputmode', 1);  % Save individual results (one file per input file)

% We need to set the right name for the results: "sub-000X_PLV_RIGHT"
for i=1:length(SubjectNames)
bst_process('CallProcess', 'process_set_comment', sFilesPLV_TEST(i).FileName, [], ...
    'tag',           ['',num2str(SubjectNames{i}),'_PLV_RIGHT'], ...
    'isindex',       1); % add path to index
end

clear i;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 13: Compute group-averaged PLVs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% First we generate a variable called sFilesAVG_pathnames_LEFT

sFilesAVG_pathnames_LEFT  = cell ([1 90]);

for i = 1:90
    sFilesAVG_pathnames_LEFT{i} = sFilesPLV_LEFT(i).FileName;
end

% We can now compute the process 'Average: Everything'
sFilesPLV_AvgLEFT = bst_process('CallProcess', 'process_average', sFilesAVG_pathnames_LEFT, [], ...
    'avgtype',       1, ...  % Everything
    'avg_func',      1, ...  % Arithmetic average:  mean(x)
    'weighted',      0, ...
    'matchrows',     0, ...
    'iszerobad',     0);

% We repeat the procedure for the RIGHT hemisphere pathnames

sFilesAVG_pathnames_RIGHT  = cell ([1 90]);

for i = 1:90
    sFilesAVG_pathnames_RIGHT{i} = sFilesPLV_RIGHT(i).FileName;
end

% We compute the process 'Average: Everything' once again
sFilesPLV_AvgRIGHT = bst_process('CallProcess', 'process_average', sFilesAVG_pathnames_RIGHT, [], ...
    'avgtype',       1, ...  % Everything
    'avg_func',      1, ...  % Arithmetic average:  mean(x)
    'weighted',      0, ...
    'matchrows',     0, ...
    'iszerobad',     0);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 14: Export matrices from Matlab
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% We will first generate a variable called SubjectTags, which will be like
% SubjectNames but without the "-" character:

SubjectTags = cell ([1 90]);

for i = 1:length(SubjectTags)
    SubjectTags(i) = erase(SubjectNames(i), "-");
end

%% Use the next few lines until we fix subjects 69 and 145

SubjectTags2 = SubjectTags; % Recompute this if you need to reset SubjectTags2

%% CASE1: If you only want to exclude subject 0145 (Oscar)

SubjectTags2(67) = [];

%% CASE2: If you only want to exclude subject 0069 (Alix)

SubjectTags2(44) = [];

%% CASE3: If you want to exclude both 0069 and 0145 

SubjectTags2([44 67]) = [];

%% Continue here after choosing one of three CASES

% Now we will go to the parent directory and create a master output
% variable called PLV.mat (or icPLV.mat)

cd /home/oscar/TEST/SCRIPTS/PLVs
save PLV.mat sFilesPLV_LEFT sFilesPLV_RIGHT
load /home/oscar/TEST/SCRIPTS/PLVs/PLV.mat

% We need to create a variable containing the PLV results for each subject for the LEFT hemisphere:

BrainstormMatrix_PLV_LEFT = cell ([1 length(SubjectTags2)]);

for i = (1:length(SubjectTags2))
BrainstormMatrix_PLV_LEFT{i} = load(['/home/alix/matlabtoolbox/brainstorm_db/OMEGA_AO_1021_Step5_Notch+BandpassFilter+SecondPSD/data/',sFilesPLV_LEFT(i).FileName]);
end 

% And same thing for the RIGHT hemisphere:

BrainstormMatrix_PLV_RIGHT = cell ([1 length(SubjectTags2)]);

for i = (1:length(SubjectTags2))
BrainstormMatrix_PLV_RIGHT{i} = load(['/home/alix/matlabtoolbox/brainstorm_db/OMEGA_AO_1021_Step5_Notch+BandpassFilter+SecondPSD/data/',sFilesPLV_RIGHT(i).FileName]);
end 

% Using these two new variables, we will create another pair of variables containing the 90 matrices to be imported into R

RStudioMatrix_PLV_LEFT = cell ([1 length(SubjectTags2)]);

for i = (1:length(SubjectTags2))
RStudioMatrix_PLV_LEFT{i} = bst_memory('GetConnectMatrix',BrainstormMatrix_PLV_LEFT{i});
end

RStudioMatrix_PLV_RIGHT = cell ([1 89]);

for i = (1:length(SubjectTags2))
RStudioMatrix_PLV_RIGHT{i} = bst_memory('GetConnectMatrix',BrainstormMatrix_PLV_RIGHT{i});
end

% Last but not least, we need to create a pair of variables containing the full name of the output file, including the .mat at the end:

MatrixNames_LEFT = cell ([1 length(SubjectTags2)]);

for i = (1:length(SubjectTags2))
MatrixNames_LEFT{i} = (['RStudioMatrix_PLV_LEFT_',SubjectTags2{i},'.mat']);
end

MatrixNames_RIGHT = cell ([1 length(SubjectTags2)]);

for i = 1:length(SubjectTags2)
MatrixNames_RIGHT{i} = (['RStudioMatrix_PLV_RIGHT_',SubjectTags2{i},'.mat']);
end

% Everything is ready for us to export the matrices into the desired folder:

cd /home/oscar/TEST/SCRIPTS/PLVs/LEFT 

for i = (1:length(SubjectTags2))
    temp = RStudioMatrix_PLV_LEFT(i);
    save([MatrixNames_LEFT{i}], 'temp');
end

clear temp;
clear i;

% Same for the right hemisphere outputs:

cd /home/oscar/TEST/SCRIPTS/PLVs/RIGHT

for i = (1:length(SubjectTags2))
    temp2 = RStudioMatrix_PLV_RIGHT(i);
    save([MatrixNames_RIGHT{i}], 'temp2');
end

clear temp2;
clear i;

% PENDING: Inspect the result for each subject to make sure it matches the Brainstorm matrices

% figure; 
% imagesc(A(:,:,1,1));

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 15: Compute Phase Transfer Entropy 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% We compute the pTE (NxN) for the LEFT hemisphere ROIs
sFilesPTE_LEFT = bst_process('CallProcess', 'process_pte1n', sFilesKernel1, [], ...
    'timewindow', [], ...
    'scouts',     {'Hybrid Atlas LEFT', {'Left_A1', 'Left_STG', 'Left_V1', 'Left_M1', 'Left_vPMC', 'Left_dPMC'}}, ...
    'scoutfunc',  3, ...  % PCA
    'scouttime',  1, ...  % Before
    'freqbands',  {'delta', '2, 4', 'mean'; 'theta', '5, 7', 'mean'; 'alpha', '8, 12', 'mean'; 'beta', '15, 29', 'mean'; 'gamma1', '30, 59', 'mean'; 'gamma2', '60, 80', 'mean'}, ...
    'normalized', 0, ...
    'outputmode', 1);  % Save individual results (one file per input file)

% We need to set the right name for the results: "sub-000X_PLV_LEFT"
for i=1:length(SubjectNames)
bst_process('CallProcess', 'process_set_comment', sFilesPTE_LEFT(i).FileName, [], ...
    'tag',           ['',num2str(SubjectNames{i}),'_PTE_LEFT_REAL'], ...
    'isindex',       1); % add path to index
end

% We compute the pTE (NxN) for the RIGHT hemisphere ROIs
sFilesPTE_RIGHT = bst_process('CallProcess', 'process_pte1n', sFilesKernel1, [], ...
    'timewindow', [], ...
    'scouts',     {'Hybrid Atlas RIGHT', {'Right_A1', 'Right_STG', 'Right_V1', 'Right_M1', 'Right_vPMC', 'Right_dPMC'}}, ...
    'scoutfunc',  3, ...  % PCA
    'scouttime',  1, ...  % Before
    'freqbands',  {'delta', '2, 4', 'mean'; 'theta', '5, 7', 'mean'; 'alpha', '8, 12', 'mean'; 'beta', '15, 29', 'mean'; 'gamma1', '30, 59', 'mean'; 'gamma2', '60, 80', 'mean'}, ...
    'normalized', 0, ...
    'outputmode', 1);  % Save individual results (one file per input file)

% We need to set the right name for the results: "sub-000X_PTE_RIGHT"
for i=1:length(SubjectNames)
bst_process('CallProcess', 'process_set_comment', sFilesPTE_RIGHT(i).FileName, [], ...
    'tag',           ['',num2str(SubjectNames{i}),'_PTE_RIGHT'], ...
    'isindex',       1); % add path to index
end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 16: Compute group-averaged PTEs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% First we generate a variable called sFilesAVG_pathnames_LEFT

sFilesAVG_pathnames_LEFT  = cell ([1 90]);

for i = 1:90
    sFilesAVG_pathnames_LEFT{i} = sFilesPTE_LEFT(i).FileName;
end

% We can now compute the process 'Average: Everything'
sFilesPTE_AvgLEFT = bst_process('CallProcess', 'process_average', sFilesAVG_pathnames_LEFT, [], ...
    'avgtype',       1, ...  % Everything
    'avg_func',      1, ...  % Arithmetic average:  mean(x)
    'weighted',      0, ...
    'matchrows',     0, ...
    'iszerobad',     0);

bst_process('CallProcess', 'process_set_comment', sFilesPTE_AvgLEFT, [], ...
    'tag',           ('AVG_PTE_LEFT_REAL (90)'), ...
    'isindex',       1); % add path to index

% We repeat the procedure for the RIGHT hemisphere pathnames

sFilesAVG_pathnames_RIGHT  = cell ([1 90]);

for i = 1:90
    sFilesAVG_pathnames_RIGHT{i} = sFilesPTE_RIGHT(i).FileName;
end

% We compute the process 'Average: Everything' once again
sFilesPTE_AvgRIGHT = bst_process('CallProcess', 'process_average', sFilesAVG_pathnames_RIGHT, [], ...
    'avgtype',       1, ...  % Everything
    'avg_func',      1, ...  % Arithmetic average:  mean(x)
    'weighted',      0, ...
    'matchrows',     0, ...
    'iszerobad',     0);

bst_process('CallProcess', 'process_set_comment', sFilesPTE_AvgRIGHT, [], ...
    'tag',           ('AVG_PTE_RIGHT (90)'), ...
    'isindex',       1); % add path to index

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 17: Export PTE matrices from Matlab
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% We will first generate a variable called SubjectTags, which will be like
% SubjectNames but without the "-" character:

SubjectTags = cell ([1 90]);

for i = 1:length(SubjectTags)
    SubjectTags(i) = erase(SubjectNames(i), "-");
end

% We will create a clone called SubjectTags2 it in case we need to reset it

SubjectTags2 = SubjectTags; % Recompute this if you need to reset SubjectTags2

% Now we will go to the parent directory and create a master output
% variable called PTE.mat

cd /home/oscar/TEST/SCRIPTS/PTEs
save PTE.mat sFilesPTE_LEFT sFilesPTE_RIGHT
load /home/oscar/TEST/SCRIPTS/PTEs/PTE.mat

% We need to create a variable containing the PTE results for each subject for the LEFT hemisphere:

BrainstormMatrix_PTE_LEFT = cell ([1 length(SubjectTags2)]);

for i = (1:length(SubjectTags2))
BrainstormMatrix_PTE_LEFT{i} = load(['/home/alix/matlabtoolbox/brainstorm_db/OMEGA_AO_1021_Step5_Notch+BandpassFilter+SecondPSD/data/',sFilesPTE_LEFT(i).FileName]);
end 

% And same thing for the RIGHT hemisphere:

BrainstormMatrix_PTE_RIGHT = cell ([1 length(SubjectTags2)]);

for i = (1:length(SubjectTags2))
BrainstormMatrix_PTE_RIGHT{i} = load(['/home/alix/matlabtoolbox/brainstorm_db/OMEGA_AO_1021_Step5_Notch+BandpassFilter+SecondPSD/data/',sFilesPTE_RIGHT(i).FileName]);
end 

% Using these two new variables, we will create another pair of variables containing the 90 matrices to be imported into R

RStudioMatrix_PTE_LEFT = cell ([1 length(SubjectTags2)]);

for i = (1:length(SubjectTags2))
RStudioMatrix_PTE_LEFT{i} = bst_memory('GetConnectMatrix',BrainstormMatrix_PTE_LEFT{i});
end

RStudioMatrix_PTE_RIGHT = cell ([1 89]);

for i = (1:length(SubjectTags2))
RStudioMatrix_PTE_RIGHT{i} = bst_memory('GetConnectMatrix',BrainstormMatrix_PTE_RIGHT{i});
end

% Last but not least, we need to create a pair of variables containing the full name of the output file, including the .mat at the end:

MatrixNames_LEFT = cell ([1 length(SubjectTags2)]);

for i = (1:length(SubjectTags2))
MatrixNames_LEFT{i} = (['RStudioMatrix_PTE_LEFT_',SubjectTags2{i},'.mat']);
end

MatrixNames_RIGHT = cell ([1 length(SubjectTags2)]);

for i = 1:length(SubjectTags2)
MatrixNames_RIGHT{i} = (['RStudioMatrix_PTE_RIGHT_',SubjectTags2{i},'.mat']);
end

% Everything is ready for us to export the matrices into the desired folder:

cd /home/oscar/TEST/SCRIPTS/PTEs/LEFT 

for i = (1:length(SubjectTags2))
    temp = RStudioMatrix_PTE_LEFT(i);
    save([MatrixNames_LEFT{i}], 'temp');
end

clear temp;
clear i;

% Same for the right hemisphere outputs:

cd /home/oscar/TEST/SCRIPTS/PTEs/RIGHT

for i = (1:length(SubjectTags2))
    temp2 = RStudioMatrix_PTE_RIGHT(i);
    save([MatrixNames_RIGHT{i}], 'temp2');
end

clear temp2;
clear i;

% PENDING: Inspect the result for each subject to make sure it matches the Brainstorm matrices

% figure; 
% imagesc(A(:,:,1,1));


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 18: Export AVG PTE matrices from Matlab
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd /home/oscar/TEST/SCRIPTS/PTEs
save PTE_AVG.mat sFilesPTE_LEFT_AVG sFilesPTE_RIGHT_AVG
load /home/oscar/TEST/SCRIPTS/PTEs/PTE.mat

% We need to create a variable containing the AVG PTE results for LEFT and RIGHT separately:

BrainstormMatrix_PTE_LEFT_AVG = load('/home/alix/matlabtoolbox/brainstorm_db/OMEGA_AO_1021_Step5_Notch+BandpassFilter+SecondPSD/data/Group_analysis/@intra/timefreq_connectn_average_220607_1513.mat');
BrainstormMatrix_PTE_RIGHT_AVG = load('/home/alix/matlabtoolbox/brainstorm_db/OMEGA_AO_1021_Step5_Notch+BandpassFilter+SecondPSD/data/Group_analysis/@intra/timefreq_connectn_average_220413_1911.mat');

% Using these two new variables, we will create another pair of variables containing the 90 matrices to be imported into R

RStudioMatrix_PTE_LEFT_AVG  = bst_memory('GetConnectMatrix',BrainstormMatrix_PTE_LEFT_AVG);
RStudioMatrix_PTE_RIGHT_AVG = bst_memory('GetConnectMatrix',BrainstormMatrix_PTE_RIGHT_AVG);

% Last but not least, we need to create a pair of variables containing the full name of the output file, including the .mat at the end:

MatrixNames_LEFT_AVG    = ('RStudioMatrix_PTE_LEFT_AVG.mat');
MatrixNames_RIGHT_AVG   = ('RStudioMatrix_PTE_RIGHT_AVG.mat');

% Everything is ready for us to export the matrices into the desired folder:

cd /home/oscar/TEST/SCRIPTS/PTEs/LEFT 

temp = RStudioMatrix_PTE_LEFT_AVG;
save([MatrixNames_LEFT_AVG], 'temp');

% Same for the right hemisphere outputs:

cd /home/oscar/TEST/SCRIPTS/PTEs/RIGHT

temp2 = RStudioMatrix_PTE_RIGHT_AVG;
save([MatrixNames_RIGHT_AVG], 'temp2');

%% Export to XLS

csvwrite('PTE_LEFT_AVG.csv', 'temp')
csvwrite('PTE_LEFT_AVG.csv', 'temp2')


                                        %% %% %% DONE! %% %% %%