
%%%%%%% Load PT1 %%%%%%%

load('S1AMPE-36/S1AMPE0036_PT1_Rand1/data_S_1_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT1_s1 = History;
clear History
PT1_s1(:, 1:2) = [];
PT1_s1(1:5, :) = [];
for i = 1:numel(PT1_s1)
    PT1_s1{i} = PT1_s1{i}(4:end);
end

PT1_s1 = PT1_s1';   % this tilts the cell structure by 90 degrees

% for i = 1:numel(PT1_s1)
%     PT1_s1{i} = strrep(PT1_s1{i}, '_Real', '');
% end

PT1_s1 = bst_process('CallProcess', 'process_resample', PT1_s1, [], ...
    'freq',      200, ...
    'overwrite', 1);

load('S1AMPE-36/S1AMPE0036_PT1_Rand1/data_S_2_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT1_s2 = History;
clear History
PT1_s2(:, 1:2) = [];
PT1_s2(1:5, :) = [];
for i = 1:numel(PT1_s2)
    PT1_s2{i} = PT1_s2{i}(4:end);
end

PT1_s2 = PT1_s2';

% for i = 1:numel(PT1_s2)
%     PT1_s2{i} = strrep(PT1_s2{i}, '_Real', '');
% end

PT1_s2 = bst_process('CallProcess', 'process_resample', PT1_s2, [], ...
    'freq',      200, ...
    'overwrite', 1);

load('S1AMPE-36/S1AMPE0036_PT1_Rand1/data_S_4_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT1_s4 = History;
clear History
PT1_s4(:, 1:2) = [];
PT1_s4(1:5, :) = [];
for i = 1:numel(PT1_s4)
    PT1_s4{i} = PT1_s4{i}(4:end);
end

PT1_s4 = PT1_s4';

% for i = 1:numel(PT1_s4)
%     PT1_s4{i} = strrep(PT1_s4{i}, '_Real', '');
% end

PT1_s4 = bst_process('CallProcess', 'process_resample', PT1_s4, [], ...
    'freq',      200, ...
    'overwrite', 1);

load('S1AMPE-36/S1AMPE0036_PT1_Rand1/data_S_8_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT1_s8 = History;
clear History
PT1_s8(:, 1:2) = [];
PT1_s8(1:5, :) = [];
for i = 1:numel(PT1_s8)
    PT1_s8{i} = PT1_s8{i}(4:end);
end

PT1_s8 = PT1_s8';
% 
% for i = 1:numel(PT1_s8)
%     PT1_s8{i} = strrep(PT1_s8{i}, '_Real', '');
% end

PT1_s8 = bst_process('CallProcess', 'process_resample', PT1_s8, [], ...
    'freq',      200, ...
    'overwrite', 1);

clear ('i')

%%%%%%% Load PT2 %%%%%

load('S1AMPE-36/S1AMPE0036_PT2_Learn1/data_S_1_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT2_s1 = History;
clear History
PT2_s1(:, 1:2) = [];
PT2_s1(1:5, :) = [];
for i = 1:numel(PT2_s1)
    PT2_s1{i} = PT2_s1{i}(4:end);
end

PT2_s1 = PT2_s1';   %this tilts the cell structure by 90 degrees

% for i = 1:numel(PT2_s1)
% PT2_s1{i} = strrep(PT2_s1{i}, '_Real', '');
% end

PT2_s1 = bst_process('CallProcess', 'process_resample', PT2_s1, [], ...
    'freq',      200, ...
    'overwrite', 1);

load('S1AMPE-36/S1AMPE0036_PT2_Learn1/data_S_2_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT2_s2 = History;
clear History
PT2_s2(:, 1:2) = [];
PT2_s2(1:5, :) = [];
for i = 1:numel(PT2_s2)
    PT2_s2{i} = PT2_s2{i}(4:end);
end

for i = 1:numel(PT2_s2)
    PT2_s2{i} = strrep(PT2_s2{i}, 'PT1', 'PT2');
end

PT2_s2 = PT2_s2';

% for i = 1:numel(PT2_s2)
% PT2_s2{i} = strrep(PT2_s2{i}, '_Real', '');
% end

PT2_s2 = bst_process('CallProcess', 'process_resample', PT2_s2, [], ...
    'freq',      200, ...
    'overwrite', 1);

load('S1AMPE-36/S1AMPE0036_PT2_Learn1/data_S_4_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT2_s4 = History;
clear History
PT2_s4(:, 1:2) = [];
PT2_s4(1:5, :) = [];
for i = 1:numel(PT2_s4)
    PT2_s4{i} = PT2_s4{i}(4:end);
end


for i = 1:numel(PT2_s4)
    PT2_s4{i} = strrep(PT2_s4{i}, 'PT1', 'PT2');
end

PT2_s4 = PT2_s4';

% for i = 1:numel(PT2_s4)
% PT2_s4{i} = strrep(PT2_s4{i}, '_Real', '');
% end

PT2_s4 = bst_process('CallProcess', 'process_resample', PT2_s4, [], ...
    'freq',      200, ...
    'overwrite', 1);

load('S1AMPE-36/S1AMPE0036_PT2_Learn1/data_S_8_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT2_s8 = History;
clear History
PT2_s8(:, 1:2) = [];
PT2_s8(1:5, :) = [];
for i = 1:numel(PT2_s8)
    PT2_s8{i} = PT2_s8{i}(4:end);
end

for i = 1:numel(PT2_s8)
    PT2_s8{i} = strrep(PT2_s8{i}, 'PT1', 'PT2');
end

PT2_s8 = PT2_s8';

% for i = 1:numel(PT2_s8)
% PT2_s8{i} = strrep(PT2_s8{i}, '_Real', '');
% end

PT2_s8 = bst_process('CallProcess', 'process_resample', PT2_s8, [], ...
    'freq',      200, ...
    'overwrite', 1);

clear ('i')

%%%%%%% Load PT3 %%%%%%%%%

load('S1AMPE-36/S1AMPE0036_PT3_Rand2/data_S_1_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT3_s1 = History;
clear History
PT3_s1(:, 1:2) = [];
PT3_s1(1:5, :) = [];
for i = 1:numel(PT3_s1)
    PT3_s1{i} = PT3_s1{i}(4:end);
end

PT3_s1 = PT3_s1';   %this tilts the cell structure by 90 degrees

% for i = 1:numel(PT3_s1)
% PT3_s1{i} = strrep(PT3_s1{i}, '_Real', '');
% end

PT3_s1 = bst_process('CallProcess', 'process_resample', PT3_s1, [], ...
    'freq',      200, ...
    'overwrite', 1);

load('S1AMPE-36/S1AMPE0036_PT3_Rand2/data_S_2_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT3_s2 = History;
clear History
PT3_s2(:, 1:2) = [];
PT3_s2(1:5, :) = [];
for i = 1:numel(PT3_s2)
    PT3_s2{i} = PT3_s2{i}(4:end);
end

PT3_s2 = PT3_s2';

% for i = 1:numel(PT3_s2)
% PT3_s2{i} = strrep(PT3_s2{i}, '_Real', '');
% end

PT3_s2 = bst_process('CallProcess', 'process_resample', PT3_s2, [], ...
    'freq',      200, ...
    'overwrite', 1);

load('S1AMPE-36/S1AMPE0036_PT3_Rand2/data_S_4_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT3_s4 = History;
clear History
PT3_s4(:, 1:2) = [];
PT3_s4(1:5, :) = [];
for i = 1:numel(PT3_s4)
    PT3_s4{i} = PT3_s4{i}(4:end);
end

PT3_s4 = PT3_s4';

% for i = 1:numel(PT3_s4)
% PT3_s4{i} = strrep(PT3_s4{i}, '_Real', '');
% end

PT3_s4 = bst_process('CallProcess', 'process_resample', PT3_s4, [], ...
    'freq',      200, ...
    'overwrite', 1);

load('S1AMPE-36/S1AMPE0036_PT3_Rand2/data_S_8_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT3_s8 = History;
clear History
PT3_s8(:, 1:2) = [];
PT3_s8(1:5, :) = [];
for i = 1:numel(PT3_s8)
    PT3_s8{i} = PT3_s8{i}(4:end);
end

PT3_s8 = PT3_s8';

% for i = 1:numel(PT3_s8)
% PT3_s8{i} = strrep(PT3_s8{i}, '_Real', '');
% end

PT3_s8 = bst_process('CallProcess', 'process_resample', PT3_s8, [], ...
    'freq',      200, ...
    'overwrite', 1);

clear ('i')

%%%%%%%%% Load PT4 %%%%%%%%%

load('S1AMPE-36/S1AMPE0036_PT4_Learn2/data_S_1_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT4_s1 = History;
clear History
PT4_s1(:, 1:2) = [];
PT4_s1(1:5, :) = [];
for i = 1:numel(PT4_s1)
    PT4_s1{i} = PT4_s1{i}(4:end);
end

PT4_s1 = PT4_s1';   %this tilts the cell structure by 90 degrees

% for i = 1:numel(PT4_s1)
% PT4_s1{i} = strrep(PT4_s1{i}, '_Real', '');
% end

PT4_s1 = bst_process('CallProcess', 'process_resample', PT4_s1, [], ...
    'freq',      200, ...
    'overwrite', 1);

load('S1AMPE-36/S1AMPE0036_PT4_Learn2/data_S_2_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT4_s2 = History;
clear History
PT4_s2(:, 1:2) = [];
PT4_s2(1:5, :) = [];
for i = 1:numel(PT4_s2)
    PT4_s2{i} = PT4_s2{i}(4:end);
end

PT4_s2 = PT4_s2';

% for i = 1:numel(PT4_s2)
% PT4_s2{i} = strrep(PT4_s2{i}, '_Real', '');
% end

PT4_s2 = bst_process('CallProcess', 'process_resample', PT4_s2, [], ...
    'freq',      200, ...
    'overwrite', 1);

load('S1AMPE-36/S1AMPE0036_PT4_Learn2/data_S_4_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT4_s4 = History;
clear History
PT4_s4(:, 1:2) = [];
PT4_s4(1:5, :) = [];
for i = 1:numel(PT4_s4)
    PT4_s4{i} = PT4_s4{i}(4:end);
end

PT4_s4 = PT4_s4';

% for i = 1:numel(PT4_s4)
% PT4_s4{i} = strrep(PT4_s4{i}, '_Real', '');
% end

PT4_s4 = bst_process('CallProcess', 'process_resample', PT4_s4, [], ...
    'freq',      200, ...
    'overwrite', 1);

load('S1AMPE-36/S1AMPE0036_PT4_Learn2/data_S_8_average_230613_1746.mat');
clear ('Time', 'Std', 'nAvg', 'Leff', 'F', 'Events', 'DisplayUnits', 'Device', 'DataType', 'Comment', 'ColormapType', 'ChannelFlag')
PT4_s8 = History;
clear History
PT4_s8(:, 1:2) = [];
PT4_s8(1:5, :) = [];
for i = 1:numel(PT4_s8)
    PT4_s8{i} = PT4_s8{i}(4:end);
end

PT4_s8 = PT4_s8';

% for i = 1:numel(PT4_s8)
% PT4_s8{i} = strrep(PT4_s8{i}, '_Real', '');
% end

PT4_s8 = bst_process('CallProcess', 'process_resample', PT4_s8, [], ...
    'freq',      200, ...
    'overwrite', 1);

clear ('i')
