
                                 %% %% %% MASTER SCRIPT: OMEGA %% %% %% 
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 0: Add brainstorm paths and load the GUI 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                                        
addpath ('/home/oscar/Documents/brainstorm3');
addpath ('/home/oscar/Documents/brainstorm_db');
addpath ('/home/oscar/Documents/spm12');


brainstorm;
clc

%% %%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 1: Import the datasets
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Locate master folder
% sFilesRaw = [];
path = {'/home/oscar/DATA'};
% path = {'/home/oscar/TEST'};
RawFiles = ...
    path(1);

%% Option 1: Import individual subjects

% 1.1 First we pre-allocate a cell array called 'SubjectNames'

SubjectNames = cell([1 210]);

SubjectNames(:,(1)) = {'sub-0007'};
SubjectNames(:,(2)) = {'sub-0012'};
SubjectNames(:,(3)) = {'sub-0015'};
SubjectNames(:,(4)) = {'sub-0018'};
SubjectNames(:,(5)) = {'sub-0021'};
SubjectNames(:,(6)) = {'sub-0023'};
SubjectNames(:,(7)) = {'sub-0024'};
SubjectNames(:,(8)) = {'sub-0025'};
SubjectNames(:,(9)) = {'sub-0028'};
SubjectNames(:,(10)) = {'sub-0029'};

SubjectNames(:,(11)) = {'sub-0031'};
SubjectNames(:,(12)) = {'sub-0032'};
SubjectNames(:,(13)) = {'sub-0033'};
SubjectNames(:,(14)) = {'sub-0036'};
SubjectNames(:,(15)) = {'sub-0037'};
SubjectNames(:,(16)) = {'sub-0045'};
SubjectNames(:,(17)) = {'sub-0046'};
SubjectNames(:,(18)) = {'sub-0047'};
SubjectNames(:,(19)) = {'sub-0048'};
SubjectNames(:,(20)) = {'sub-0052'};

SubjectNames(:,(21)) = {'sub-0060'};
SubjectNames(:,(22)) = {'sub-0061'};
SubjectNames(:,(23)) = {'sub-0065'};
SubjectNames(:,(24)) = {'sub-0066'};

% 1.2 We can now iterate the subject tags into the 'SubjectNames' cell array

% for s=1:length(SubjectNames)
%     if s<10 
%     SubjectNames(s) = {...
%         ['sub-000',num2str(s)]};
%     else
%     SubjectNames(s) = {...
%         ['sub-00',num2str(s)]};
%     end
% end
% clear s;

% 1.3 We must  delete columns belonging to non-existing subject files    
    
% SubjectNames(:,[1,5]) = []; 
 
% 1.4 NOW WE IMPORT EACH FREESURFER FOLDER MANUALLY (import anatomy (auto))

% Alternatively, we can loop the directories of each participant's T1 file 

% RawMRIFiles = cell([1 24]);
% 
% for s = 1:length(SubjectNames)
%     RawMRIFiles(s) = {[...
%         '/home/oscar/DATA/OMEGA-BIDS/',SubjectNames{s},'/ses-0001/anat/',SubjectNames{s},'_ses-0001_T1w.nii.gz']};
% end

%% IMPORTANT: Switch to 'recon_all.m' to import the T1s (steps 1.1 -- 1.6)


%% 1.5 Now we will import the sub-emptyroom subject and noise recordings

% First we will create a cell where we will put the session dates 

    % NOTE: remember to automate/streamline this section

EmptyRoomDates = cell([1 24]);

EmptyRoomDates(:,(1)) = {'ses-20130315'};
EmptyRoomDates(:,(2)) = {'ses-20130717'};
EmptyRoomDates(:,(3)) = {'ses-20130715'};
EmptyRoomDates(:,(4)) = {'ses-20130715'};
EmptyRoomDates(:,(5)) = {'ses-20121114'};
EmptyRoomDates(:,(6)) = {'ses-20130918'};
EmptyRoomDates(:,(7)) = {'ses-20120731'};
EmptyRoomDates(:,(8)) = {'ses-20130206'};
EmptyRoomDates(:,(9)) = {'ses-20130305'};
EmptyRoomDates(:,(10)) = {'ses-20130731'};

EmptyRoomDates(:,(11)) = {'ses-20130711'};
EmptyRoomDates(:,(12)) = {'ses-20120724'};
EmptyRoomDates(:,(13)) = {'ses-20130712'};
EmptyRoomDates(:,(14)) = {'ses-20130306'};
EmptyRoomDates(:,(15)) = {'ses-20130717'};
EmptyRoomDates(:,(16)) = {'ses-20121121'};
EmptyRoomDates(:,(17)) = {'ses-20131007'};
EmptyRoomDates(:,(18)) = {'ses-20120725'};
EmptyRoomDates(:,(19)) = {'ses-20130808'};
EmptyRoomDates(:,(20)) = {'ses-20130727'};

EmptyRoomDates(:,(21)) = {'ses-20170327'};
EmptyRoomDates(:,(22)) = {'ses-20170222'};
EmptyRoomDates(:,(23)) = {'ses-20170228'};
EmptyRoomDates(:,(24)) = {'ses-20170328'};

% Now we need a list of subject names without the hypen (-) in SubjectNames:

    % NOTE: remember to automate/streamline this section

SubjectTags = cell([1 24]);

SubjectTags(:,(1)) = {'sub0007'};
SubjectTags(:,(2)) = {'sub0012'};
SubjectTags(:,(3)) = {'sub0015'};
SubjectTags(:,(4)) = {'sub0018'};
SubjectTags(:,(5)) = {'sub0021'};
SubjectTags(:,(6)) = {'sub0023'};
SubjectTags(:,(7)) = {'sub0024'};
SubjectTags(:,(8)) = {'sub0025'};
SubjectTags(:,(9)) = {'sub0028'};
SubjectTags(:,(10)) = {'sub0029'};

SubjectTags(:,(11)) = {'sub0031'};
SubjectTags(:,(12)) = {'sub0032'};
SubjectTags(:,(13)) = {'sub0033'};
SubjectTags(:,(14)) = {'sub0036'};
SubjectTags(:,(15)) = {'sub0037'};
SubjectTags(:,(16)) = {'sub0045'};
SubjectTags(:,(17)) = {'sub0046'};
SubjectTags(:,(18)) = {'sub0047'};
SubjectTags(:,(19)) = {'sub0048'};
SubjectTags(:,(20)) = {'sub0052'};

SubjectTags(:,(21)) = {'sub0060'};
SubjectTags(:,(22)) = {'sub0061'};
SubjectTags(:,(23)) = {'sub0065'};
SubjectTags(:,(24)) = {'sub0066'};

% Finally, we need an ordered list of all the subject (emptyroom) runs:

     % NOTE: remember to automate/streamline this section

RunNumbers = cell([1 24]);
RunNumbers(:,(1)) = {'06'};
RunNumbers(:,(2)) = {'01'};
RunNumbers(:,(3)) = {'01'};
RunNumbers(:,(4)) = {'02'};
RunNumbers(:,(5)) = {'04'};
RunNumbers(:,(6)) = {'02'};
RunNumbers(:,(7)) = {'03'};
RunNumbers(:,(8)) = {'02'};
RunNumbers(:,(9)) = {'01'};
RunNumbers(:,(10)) = {'09'};

RunNumbers(:,(11)) = {'03'};
RunNumbers(:,(12)) = {'02'};
RunNumbers(:,(13)) = {'02'};
RunNumbers(:,(14)) = {'04'};
RunNumbers(:,(15)) = {'02'};
RunNumbers(:,(16)) = {'03'};
RunNumbers(:,(17)) = {'02'};
RunNumbers(:,(18)) = {'02'};
RunNumbers(:,(19)) = {'02'};
RunNumbers(:,(20)) = {'03'};

RunNumbers(:,(21)) = {'03'};
RunNumbers(:,(22)) = {'02'};
RunNumbers(:,(23)) = {'01'};
RunNumbers(:,(24)) = {'02'};
% etc

% We are now ready to generate a string for each directory iteratively:

RawNoiseFiles = cell([1 24]);

for s = 1:length(EmptyRoomDates)
    RawNoiseFiles(s) = {[...
        '/home/oscar/DATA/OMEGA-BIDS/sub-emptyroom/',EmptyRoomDates{s},'/meg/sub-emptyroom_',EmptyRoomDates{s},'_task-noise_acq-',SubjectTags{s},'_run-',RunNumbers{s},'_meg.ds']};
end

% Finally, we will call on the import_data_raw function iteratively
for s = 1:length(SubjectTags)
bst_process('CallProcess', 'process_import_data_raw', [], [], ...
    'subjectname',    'sub-emptyroom', ...
    'datafile',       {RawNoiseFiles{s}, 'CTF'}, ...
    'channelreplace', 0, ...
    'channelalign',   0, ...
    'evtmode',        'value');
end

%% 1.6 Finally, we will import the raw MEG datafiles for each subject

% First we create two SubjectNames lists, based on the two possible path names

SubjectNamesAux     = SubjectNames(:,[1 5 7 8 12 14 16]);
SubjectNamesMEG     = SubjectNames(:,[(2:4) 6 (9:11) 13 15 (17:24)]);

% Next we create two Session lists, based on the two possible path names

SessionNumberAux    = cell([1 7]);
SessionNumberMEG    = cell([1 17]);

% We will set the default to '0001' for all and change the value for individual subjects

SessionNumberAux(1,(1:7)) = {'0001'};
SessionNumberAux(1,5)     = {'0002'};

SessionNumberMEG(1,(1:17))  = {'0001'};
SessionNumberMEG(1,[4 12])  = {'0002'};

% Finally, we will creat two ScanNumber lists, using the same logic:

ScanNumberAux               = cell([1 7]);
ScanNumberAux(1,(1:7))      = {'01'};

ScanNumberMEG               = cell([1 17]);
ScanNumberMEG(1,(1:17))     = {'01'};

% We are now ready to generate a string for each directory iteratively!
% For subjects whose path includes the tag 'acq-AUX' we will use the following code:

RawAuxFiles = cell ([1 7]);

for s = 1:7
    RawAuxFiles(s) = {[...
        '/home/oscar/DATA/OMEGA-BIDS/',SubjectNamesAux{s},'/ses-',SessionNumberAux{s},...
        '/meg/',SubjectNamesAux{s},'_ses-',SessionNumberAux{s},'_task-baselineresting_acq-AUX_run-',ScanNumberAux{s},'_meg.ds/'...
        ,SubjectNamesAux{s},'_ses-',SessionNumberAux{s},'_task-baselineresting_acq-AUX_run-',ScanNumberAux{s},'_meg.meg4']};
end
clear s;

% And for the other subjects we will use this code instead: 

RawMEGFiles = cell([1 length(ScanNumberMEG)]);

for s = 1:17
    RawMEGFiles(s) = {[...
        '/home/oscar/DATA/OMEGA-BIDS/',SubjectNamesMEG{s},'/ses-',SessionNumberMEG{s},...
        '/meg/',SubjectNamesMEG{s},'_ses-',SessionNumberMEG{s},'_task-baselineresting_run-',ScanNumberMEG{s},'_meg.ds/'...
        ,SubjectNamesMEG{s},'_ses-',SessionNumberMEG{s},'_task-baselineresting_run-',ScanNumberMEG{s},'_meg.meg4']};
end
clear s;

% Finally, we will call on the import_data_raw function iteratively
for s = 1:length(SubjectNamesAux)
bst_process('CallProcess', 'process_import_data_raw', [], [], ...
    'subjectname',    SubjectNamesAux{s}, ...
    'datafile',       {RawAuxFiles{s}, 'CTF'}, ...
    'channelreplace', 0, ...
    'channelalign',   0, ...
    'evtmode',        'value');
end
clear s;

for s = 1:length(SubjectNamesMEG)
bst_process('CallProcess', 'process_import_data_raw', [], [], ...
    'subjectname',    SubjectNamesMEG{s}, ...
    'datafile',       {RawMEGFiles{s}, 'CTF'}, ...
    'channelreplace', 0, ...
    'channelalign',   0, ...
    'evtmode',        'value');
end
clear s;

% All done! Now we will move onto STEP 2 (skip OPTION 2 below)

                        %% %% %% USE THIS SCRIPT IF YOU NEED TO DELETE ANY FILES %% %% %% 


% bst_process('CallProcess', 'process_delete', [sFilesAll], [], ...
%     'target', 2);  % Delete selected folders
 
%% OPTION 2: Import BIDS dataset
bst_process('CallProcess', 'process_import_bids', [], [], ...
    'bidsdir',       {RawFiles(1), 'BIDS'}, ...
    'selectsubj',    '', ...
    'nvertices',     15000, ...
    'channelalign',  1, ...
    'groupsessions', 1, ...
    'bem',           1, ...
    'anatregister',  'spm12');  % SPM12

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% STEP 2: Reconstruct the surfaces 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Switch to 'recon_all.m' script and run step 1.7 and then go to STEP 3

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 3: Refine the registration
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% We start by creating a variable with All subjects 
   sFilesAll = bst_process('CallProcess', 'process_select_files_data', [], [], ...
       'subjectname', 'All');
   
% We then create a variable with subjects with the tag: 'task-rest' 
% These are basically all subjects and files EXCLUDING sub-emptyroom's
   sFilesRest = bst_process('CallProcess', 'process_select_tag', sFilesAll, [], ...
       'tag',    'task-baselineresting', ...
       'search', 1, ...  % Search the file names
       'select', 1);  % Select only the files with the tag
   
% Now we will take snapshots of the sensors/MRI registration and save them in one image
bst_report('Start', sFilesRest);
bst_process('CallProcess', 'process_snapshot', sFilesRest, [], ...
      'target',         1, ...  % Sensors/MRI registration
      'modality',       1, ...  % MEG (All)
      'orient',         1);  % left
ReportFile = bst_report('Save', sFilesRest);
bst_report('Open', ReportFile);
% bst_report('Export', ReportFile, ExportDir);
   
% Next, we will remove the extra head points from the 'FilesRest' subjects
bst_process('CallProcess', 'process_headpoints_remove', sFilesRest, [], ...
    'zlimit', 0);

% And then we will use the 'Refine headpoints' function:
bst_process('CallProcess', 'process_headpoints_refine', sFilesRest, []);

% Let's have a look at the result by taking snapshots once again:
bst_report('Start', sFilesRest);
bst_process('CallProcess', 'process_snapshot', sFilesRest, [], ...
      'target',         1, ...  % Sensors/MRI registration
      'modality',       1, ...  % MEG (All)
      'orient',         1);  % left
ReportFile = bst_report('Save', sFilesRest);
bst_report('Open', ReportFile);
% bst_report('Export', ReportFile, ExportDir);

% NOTE: the report/s can be accessed via the following directory:
% /home/oscar/.brainstorm/reports

% addpath ('/home/oscar/.brainstorm/reports');

               %% %% %% MAKE SURE TO COMPARE THE TWO REGISTRATION REPORTS BEFORE PROCEEDING!!! %% %% %% 
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 4: Convert to continuous & PSD 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% First we use the process: Convert to continuous (CTF)
sFilesCTF = bst_process('CallProcess', 'process_ctf_convert', sFilesAll, [], ...
    'rectype', 2);  % Continuous

% Then we compute the Power spectrum density (Welch)
bst_process('CallProcess', 'process_psd', sFilesCTF, [], ...
    'timewindow',  [], ...
    'win_length',  4, ...
    'win_overlap', 50, ...
    'units',       'physical', ...  % Physical: U2/Hz
    'sensortypes', 'MEG, EEG', ...
    'win_std',     0, ...
    'edit',        struct(...
         'Comment',         'Power', ...
         'TimeBands',       [], ...
         'Freqs',           [], ...
         'ClusterFuncTime', 'none', ...
         'Measure',         'power', ...
         'Output',          'all', ...
         'SaveKernel',      0));
     
                        %% %% %% MAKE SURE TO INSPECT THE PSD PLOTS BEFORE PROCEEDING!!! %% %% %%      
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 5: Notch and bandpass filter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% First we notch filter at 60Hz + harmonics: 120Hz 180Hz 240Hz 300Hz
sFilesNotch = bst_process('CallProcess', 'process_notch', sFilesCTF, [], ...
    'sensortypes', 'MEG, EEG', ...
    'freqlist',    [60, 120, 180, 240, 300], ...
    'cutoffW',     2, ...
    'useold',      1, ...
    'read_all',    1);

% Then we band-pass filter from 0.3Hz-80Hz and create variable sFilesBand
sFilesBand = bst_process('CallProcess', 'process_bandpass', sFilesNotch, [], ...
    'sensortypes', 'MEG, EEG', ...
    'highpass',    0.3, ...
    'lowpass',     80, ...
    'tranband',    0, ...
    'attenuation', 'strict', ...  % 60dB
    'ver',         '2019', ...  % 2019
    'mirror',      0, ...
    'read_all',    1);

% We will compute the PSD again so that we can compare the two
bst_process('CallProcess', 'process_psd', sFilesBand, [], ...
    'timewindow',  [], ...
    'win_length',  4, ...
    'win_overlap', 50, ...
    'units',       'physical', ...  % Physical: U2/Hz
    'sensortypes', 'MEG', ...       % We can ignore the 'EEG' channels now
    'win_std',     0, ...
    'edit',        struct(...
         'Comment',         'Power', ...
         'TimeBands',       [], ...
         'Freqs',           [], ...
         'ClusterFuncTime', 'none', ...
         'Measure',         'power', ...
         'Output',          'all', ...
         'SaveKernel',      0));
     
%  % Uncomment this if you want to delete the Raw and Notched folders:

%  bst_process('CallProcess', 'process_delete', [sFilesCTF, sFilesNotch], [], ...
%   'target', 2);     

 bst_process('CallProcess', 'process_delete', (sFilesCTF), [], ...
  'target', 2);  

                            %% %% %% MAKE SURE TO COMPARE THE TWO PSD PLOTS FOR EACH SUBJECT BEFORE PROCEEDING!!! %% %% %%  
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 6: Detecth heartbeats, blinks and saccades 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% We select file names corresponding to non-emptyroom subjects within sFilesBand 
sFilesRest = bst_process('CallProcess', 'process_select_tag', sFilesBand, [], ...
       'tag',    'task-baselineresting', ...
       'search', 1, ...  % Search the file names
       'select', 1);  % Select only the files with the tag

% We are ready to use the process 'Detect heartbeats' on these subjects
bst_process('CallProcess', 'process_evt_detect_ecg', sFilesRest, [], ...
    'channelname', 'ECG', ...
    'timewindow',  [], ...
    'eventname',   'cardiac');

% And we can also use the process 'Detect eye blinks' on these subjects 
bst_process('CallProcess', 'process_evt_detect_eog', sFilesRest, [], ...
    'channelname', 'VEOG', ...
    'timewindow',  [], ...
    'eventname',   'blink');

% Process: Detect: saccades
bst_process('CallProcess', 'process_evt_detect', sFilesRest, [], ...
    'eventname',    'saccades', ...
    'channelname',  'HEOG', ...
    'timewindow',   [], ...
    'bandpass',     [1.5, 7], ...
    'threshold',    2, ...
    'blanking',     0.8, ...
    'isnoisecheck', 0, ...
    'isclassify',   0);

                                     %% %% %% MAKE SURE TO REVIEW ALL EVENTS FOR EACH SUBJECT BEFORE PROCEEDING!!! %% %% %%  
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 7: Remove heartbeats, blinks and saccades 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Now we can compute the SSP projection for the ECG artifact (cardiac)
bst_process('CallProcess', 'process_ssp_ecg', sFilesRest, [], ...
    'eventname',   'cardiac', ...
    'sensortypes', 'MEG', ...
    'usessp',      0, ...
    'select',      1);

% As well as the SSP projection for the VEOG artifact (blink)
bst_process('CallProcess', 'process_ssp_eog', sFilesRest, [], ...
    'eventname',   'blink', ...
    'sensortypes', 'MEG', ...
    'usessp',      1, ...
    'select',      1);

                %% %% %% MAKE SURE TO REVIEW 1st SSP projector BEFORE REMOVING THEM!!! %% %% %%  

%% Once you have reviewed the topography and timecourse of each projector, you can continue:

% We're ready to remove both SSP projectors simulaneously from the data
bst_process('CallProcess', 'process_evt_remove_simult', sFilesRest, [], ...
    'remove', 'cardiac', ...
    'target', 'blink', ...
    'dt',     0.25, ...
    'rename', 0);

% Finally, we will calculate the SSP projector for the HEOG artifact (saccades)
% REMEMBER: this is preferable to doing bad segments (1-7Hz)

bst_process('CallProcess', 'process_ssp', sFilesRest, [], ...
    'timewindow',  [], ...
    'eventname',   'saccades', ...
    'eventtime',   [-0.2, 0.2], ...
    'bandpass',    [1.5 7], ...
    'sensortypes', 'MEG', ...
    'usessp',      1, ...
    'saveerp',     0, ...
    'method',      1, ...  % PCA: One component per sensor
    'select',      1);

% Verify this component and remove it (?)

% We will also create a report containing snapshots of all the SSP projectors
bst_report('Start', sFilesRest);
bst_process('CallProcess', 'process_snapshot', sFilesRest, [], ...
      'target',         2, ...  % SSP projectors
      'modality',       1);     % MEG (All)
ReportFile = bst_report('Save', sFilesRest);
bst_report('Open', ReportFile);
% bst_report('Export', ReportFile, ExportDir);

% NOTE: the report/s can be accessed via the following directory:
% % /home/oscar/.brainstorm/reports   
  
                          %% %% %% MAKE SURE TO VERIFY SSP REPORT AND FIRST PROJECTORS BEFORE PROCEEDING!!! %% %% %% 
%% %%%%%%%%%%%%%%%%%%%%%%
% STEP 8: Import the data
%%%%%%%%%%%%%%%%%%%%%%%%%

% First we re-allocate the cell array 'SubjectNames'
SubjectNames = cell([1 99]);

% Iterate tags into 'SubjectNames'

for s=1:length(SubjectNames)
    
    if s<10 
    SubjectNames(s) = {...
        ['sub-000',num2str(s)]};
    else
    SubjectNames(s) = {...
        ['sub-00',num2str(s)]};
    end
    
end
clear s;

% Delete columns belonging to any non-existing subject files    
SubjectNames(:,[1 2 3]) = [];

sFilesImp = cell([1 length(SubjectNames)]);

% Process: Import MEG/EEG: Time
for s = 1:length(SubjectNames)
sFilesImp(s) = bst_process('CallProcess', 'process_import_data_time', sFilesRest(s).FileName, [], ...
    'subjectname', SubjectNames{s}, ...
    'condition',   '', ...
    'timewindow',  [], ...
    'split',       0, ...
    'ignoreshort', 1, ...
    'usectfcomp',  1, ...
    'usessp',      1, ...
    'freq',        500, ...
    'baseline',    []);

end
clear s;

                                                    %% %% %% sFilesImp = sFilesRest (:,6:10); %% %% %% 

% % Process: Select data files in: */*
%    sFilesAll = bst_process('CallProcess', 'process_select_files_data', [], [], ...
%        'subjectname', 'All');
%    
% % Process: Select file names with tag: task-rest
%    sFilesImp = bst_process('CallProcess', 'process_select_tag', sFilesAll, [], ...
%        'tag',    'imp-sub', ...
%        'search', 1, ...  % Search the file names
%        'select', 1);  % Select only the files with the tag

% % Process: Select file names with tag: task-rest
%    sFilesImp = bst_process('CallProcess', 'process_select_tag', sFilesRest, [], ...
%        'tag',    'raw', ...
%        'search', 1, ...  % Search the file names
%        'select', 2);  % Select only the files WITHOUT the tag

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 9: Create the noise matrix from empty room recordings
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
% We need to select the files with tag: task-noise
sFilesNoise = bst_process('CallProcess', 'process_select_tag', sFilesBand, [], ...
       'tag',    'sub-emptyroom', ...
       'search', 1, ...  % Search the file names
       'select', 1);  % Select only the files with the tag

% Now we're ready to process the Covariance matrices
bst_process('CallProcess', 'process_noisecov', sFilesNoise, [], ...
    'baseline',       [], ...
    'datatimewindow', [], ... % Remember: this camp needs to be empty if the above camp is empty
    'sensortypes',    'MEG, EEG', ...
    'target',         1, ...  % Noise covariance     (covariance over baseline time window)
    'dcoffset',       1, ...  % Block by block, to avoid effects of slow shifts in data
    'identity',       0, ...
    'copycond',       1, ...
    'copysubj',       1, ...
    'copymatch',      1, ...
    'replacefile',    1);  % 1 = replace redundant files

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 10: Compute the head model & sources
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% We can now compute the head model
bst_process('CallProcess', 'process_headmodel', sFilesImp, [], ...
    'Comment',     '', ...
    'sourcespace', 1, ...  % Cortex surface
    'meg',         3, ...  % Overlapping spheres
    'eeg',         1, ...  % 
    'ecog',        1, ...  % 
    'seeg',        1, ...  % 
    'channelfile', '');

% And now we can translate the signals into source space and onto the head model  
sFilesKernel = bst_process('CallProcess', 'process_inverse_2018', sFilesImp, [], ...
    'output',  2, ...  % Kernel only: one per file
    'inverse', struct(...
         'Comment',        'MN: MEG', ... % Note for Alix: change to beamformer
         'InverseMethod',  'minnorm', ... % Note for Alix: change to beamformer
         'InverseMeasure', 'amplitude', ...
         'SourceOrient',   {{'fixed'}}, ...
         'Loose',          0.2, ...
         'UseDepth',       1, ...
         'WeightExp',      0.5, ...
         'WeightLimit',    10, ...
         'NoiseMethod',    'reg', ...
         'NoiseReg',       0.1, ...
         'SnrMethod',      'fixed', ...
         'SnrRms',         1e-06, ...
         'SnrFixed',       3, ...
         'ComputeKernel',  1, ...
         'DataTypes',      {{'MEG'}}));
     
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% STEP 11: Generate hybrid atlas for each subject 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Unfortunately this is a very tedious manual step.

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% STEP 12: Compute Imaginary Coherence  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% You can use this pre-step to localize sFilesKernel if necessary:

% sFilesEmpty = [];
% 
% for i = 1:length(SubjectNames)
% sFilesKernel(i) = bst_process('CallProcess', 'process_select_files_results', sFilesEmpty, [], ...
%     'subjectname',   SubjectNames{i}, ...
%     'condition',     ['',num2str(SubjectNames{i}),'_ses-0001_task-baselineresting_acq-AUX_run-01_meg_notch_band'], ...
%     'tag',           'MN', ...
%     'includebad',    1, ...
%     'includeintra',  1, ...
%     'includecommon', 1);
% end
% clear i

% We compute the Imaginary Coherence (NxN) for the LEFT hemisphere ROIs
sFilesCoh_LEFT = bst_process('CallProcess', 'process_cohere1n', sFilesKernel, [], ... 
    'timewindow',   [0, 299.998], ... % aka shortest participant scan
    'scouts',       {'Hybrid Atlas LEFT', {'Left_A1', 'Left_STG', 'Left_V1', 'Left_M1', 'Left_vPMC', 'Left_dPMC'}}, ... 
    'scoutfunc',    1, ...  % Mean
    'scouttime',    1, ...  % Before, but consult with Sylvain
    'removeevoked', 0, ...
    'cohmeasure',   'icohere2019', ...  % Imaginary Coherence (2019)IC    = |imag(C)|
    'overlap',      50, ... % Default, but consult with Sylvain
    'maxfreqres',   2, ...
    'maxfreq',      80, ...
    'outputmode',   1);  % Save individual results (one file per input file)

% We need to set the right name for the results: "sub-000X_ImgCoh_LEFT"
for i=1:length(SubjectNames)
bst_process('CallProcess', 'process_set_comment', sFilesCoh_LEFT(i).FileName, [], ...
    'tag',           ['',num2str(SubjectNames{i}),'_ImgCoh_LEFT'], ...
    'isindex',       0);
end

% Now we compute the Imaginary Coherence (NxN) for the RIGHT hemisphere ROIs
sFilesCoh_RIGHT = bst_process('CallProcess', 'process_cohere1n', sFilesKernel, [], ... 
    'timewindow',   [0, 299.998], ... % aka shortest participant scan
    'scouts',       {'Hybrid Atlas RIGHT', {'Right_A1', 'Right_STG', 'Right_V1', 'Right_M1', 'Right_vPMC', 'Right_dPMC'}}, ... 
    'scoutfunc',    1, ...  % Mean
    'scouttime',    1, ...  % Before, but consult with Sylvain
    'removeevoked', 0, ...
    'cohmeasure',   'icohere2019', ...  % Imaginary Coherence (2019)IC    = |imag(C)|
    'overlap',      50, ... % Default, but consult with Sylvain
    'maxfreqres',   2, ...
    'maxfreq',      80, ...
    'outputmode',   1);  % Save individual results (one file per input file)

% We need to set the right name for the results: "sub-000X_ImgCoh_RIGHT"
for i=1:length(SubjectNames)
bst_process('CallProcess', 'process_set_comment', sFilesCoh_RIGHT(i).FileName, [], ...
    'tag',           ['',num2str(SubjectNames{i}),'_ImgCoh_RIGHT'], ...
    'isindex',       0);
end

clear i;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 13: Compute Phase-locking value (ISPC)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% We compute the PLV (NxN) for the LEFT hemisphere ROIs 
sFilesPLV_LEFT(5) = bst_process('CallProcess', 'process_plv1n', sFilesKernel, [], ... 
    'timewindow',   [0, 299.998], ... % aka shortest participant scan
    'scouts',       {'Hybrid Atlas LEFT', {'Left_A1', 'Left_STG', 'Left_V1', 'Left_M1', 'Left_vPMC', 'Left_dPMC'}}, ... 
    'scoutfunc',  1, ...  % Mean
    'scouttime',  2, ...  % After
    'freqbands',  {'delta', '2, 4', 'mean'; 'theta', '5, 7', 'mean'; 'alpha', '8, 12', 'mean'; 'beta', '15, 29', 'mean'; 'gamma1', '30, 59', 'mean'; 'gamma2', '60, 80', 'mean'}, ...
    'keeptime',   0, ...
    'plvmeasure', 2, ...  % Magnitude
    'outputmode', 1);  % Save individual results (one file per input file)

% We need to set the right name for the results: "sub-000X_PLV_LEFT"
for i=1:length(SubjectNames)
bst_process('CallProcess', 'process_set_comment', sFilesPLV_LEFT(i).FileName, [], ...
    'tag',           ['',num2str(SubjectNames{i}),'_PLV_LEFT'], ...
    'isindex',       1); % add path to index
end

% We compute the PLV (NxN) for the RIGHT hemisphere ROIs
sFilesPLV_RIGHT = bst_process('CallProcess', 'process_plv1n', sFilesKernel, [], ... 
    'timewindow',   [0, 299.998], ... % aka shortest participant scan
    'scouts',       {'Hybrid Atlas RIGHT', {'Right_A1', 'Right_STG', 'Right_V1', 'Right_M1', 'Right_vPMC', 'Right_dPMC'}}, ... 
    'scoutfunc',  1, ...  % Mean
    'scouttime',  2, ...  % After
    'freqbands',  {'delta', '2, 4', 'mean'; 'theta', '5, 7', 'mean'; 'alpha', '8, 12', 'mean'; 'beta', '15, 29', 'mean'; 'gamma1', '30, 59', 'mean'; 'gamma2', '60, 80', 'mean'}, ...
    'keeptime',   0, ...
    'plvmeasure', 2, ...  % Magnitude
    'outputmode', 1);  % Save individual results (one file per input file)

% We need to set the right name for the results: "sub-000X_PLV_RIGHT"
for i=1:length(SubjectNames)
bst_process('CallProcess', 'process_set_comment', sFilesPLV_RIGHT(i).FileName, [], ...
    'tag',           ['',num2str(SubjectNames{i}),'_PLV_RIGHT'], ...
    'isindex',       1); % add path to index
end

clear i;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% STEP 14: Add tags to name and path [NOT NECESSARY: YOU CAN SKIP THIS STEP]      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % Process: Find and select ALL 10 plv files (2 per subject) 
% 
% sFilesPLV = bst_process('CallProcess', 'process_select_files_timefreq', sFilesKernel, [], ...
%         'subjectname',   '', ...
%         'condition',     '', ...
%         'tag',           'plv', ...
%         'includebad',    1, ...
%         'includeintra',  1, ...
%         'includecommon', 1);   
% 
% % Segregate based on hemisphere
% 
% sFilesPLV_LEFT = sFilesPLV([sFilesRealPLV.iItem] == 3); % Should give you 5
% sFilesPLV_RIGHT = sFilesPLV([sFilesRealPLV.iItem] == 4); % Should give you the remaining 5 

% Create Subject Tags

% SubjectTags = cell([1 7]);
% 
% for s=1:length(SubjectTags)
%     if s<10 
%     SubjectTags(s) = {...
%         ['sub000',num2str(s)]}; % Same as SubjectNames but without the hyphen (-)
%     else
%     SubjectTags(s) = {...
%         ['sub00',num2str(s)]}; % Same as SubjectNames but without the hyphen (-)
%     end
% end
% clear s;
    
% SubjectTags(:,[1,5]) = []; 
% 
% for i = 1:length(SubjectTags)
% Test = bst_process('CallProcess', 'process_add_tag', sFilesPLV_LEFT(i).FileName, [], ...
%     'path',          'Test', ... % ['_',num2str(SubjectTags{i}),'_PLV_LEFT'], ...  
%     'output',        1);  % Add to file path 
% end 
% 
% for i = 1:length(SubjectTags)
% bst_process('CallProcess', 'process_add_tag', sFilesPLV_LEFT(i).FileName, [], ...
%     'path',           ['_',num2str(SubjectTags{i}),'_PLV_LEFT'], ... 
%     'output',        2);  % Add to file path 
% end
% 
% % Process: Add tag+filepath to RIGHT hemisphere PLV matrices
% 
% for i = 1:length(SubjectTags)
% bst_process('CallProcess', 'process_add_tag', sFilesPLV_RIGHT(i).FileName, [], ...
%     'tag',           ['',num2str(SubjectTags{i}),'_PLV_PHILIPPE'], ... 
%     'output',        1);  % Use tag to name file
% end 
% 
% for i = 1:length(SubjectTags)
% bst_process('CallProcess', 'process_add_tag', sFilesPLV_RIGHT(i).FileName, [], ...
%     'path',           ['_',num2str(SubjectTags{i}),'_PLV_RIGHT'], ... 
%     'output',        2);  % Add to file path 
% end
% clear i;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 15: Extract matrices to Matlab
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% New steps; Comments pending 

cd /home/oscar/TEST/SCRIPTS
save PLV.mat sFilesPLV_LEFT sFilesPLV_RIGHT
load /home/oscar/TEST/SCRIPTS/PLV.mat

BrainstormMatrix_PLV_LEFT = cell ([1 length(SubjectNames)]);

for i = 1:length(SubjectNames)
BrainstormMatrix_PLV_LEFT(i) = load(['/home/oscar/Documents/brainstorm_db/PreProcessing_Automated_Pipeline/data/',sFilesPLV_LEFT(i).FileName]);
end 

BrainstormMatrix_PLV_RIGHT = cell ([1 length(SubjectNames)]);

for i = 1:length(SubjectNames)
BrainstormMatrix_PLV_RIGHT(i) = load(['/home/oscar/Documents/brainstorm_db/PreProcessing_Automated_Pipeline/data/',sFilesPLV_RIGHT(i).FileName]);
end 

% Create a variable containing the 6 matrices to be imported into R

RStudioMatrix_PLV_LEFT_sub0007 = bst_memory('GetConnectMatrix',BrainstormMatrix_PLV_LEFT(5)); 
RStudioMatrix_PLV_RIGHT_sub0007 = bst_memory('GetConnectMatrix',BrainstormMatrix_PLV_RIGHT(5));

cd /home/oscar/TEST/SCRIPTS/MATRIX

save RStudioMAtrix_PLV_LEFT_sub0007.mat     RStudioMatrix_PLV_LEFT_sub0007
save RStudioMAtrix_PLV_RIGHT_sub0007.mat    RStudioMatrix_PLV_RIGHT_sub0007

% Look at the result to make sure it matches the Brainstorm matrices

% figure; 
% imagesc(RStudioMatrix_PLV_LEFT_sub0003(:,:,1,1)); % This is to make sure everything looks okay

%% % R.matlab (readmat 'path')

% PATH_example = /home/oscar/TEST/SCRIPTS/MATRIX/RSTudioMAtrix_PLV_LEFT_sub0002.mat
                                                        %% %% %% DONE! %% %% %%