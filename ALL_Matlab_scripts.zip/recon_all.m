                                                        %% %% %% ANATOMY SCRIPT %% %% %% 

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP 0: Add brainstorm paths and load the GUI 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                                        
addpath ('/home/oscar/Documents/brainstorm3');
addpath ('/home/oscar/Documents/brainstorm_db');
addpath ('/home/oscar/Documents/spm12');


brainstorm;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEPS 1.1 -- 1.4: Preparing cell arrays
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 1.1 First we pre-allocate a cell array called 'SubjectNames'

SubjectNames = cell([1 7]);

% 1.2 We can now iterate the subject tags into the 'SubjectNames' cell array

for s=1:length(SubjectNames)
    if s<10 
    SubjectNames(s) = {...
        ['sub-000',num2str(s)]};
    elseif s<99
    SubjectNames(s) = {...
        ['sub-00',num2str(s)]};
    else
    SubjectNames(s) = {... 
        ['sub-0',num2str(s)]};
    end
end
clear s;

% 1.3 We must  delete columns belonging to non-existing subject files    
    
SubjectNames(:,(1:68)) = [];
RawFiles = cell([1 (length(SubjectNames))]);
 
% 1.4 We can now loop the directories of each participant's T1 file

for s = 1:length(SubjectNames)
    RawFiles(s) = {[...
        '/home/oscar/DATA/OMEGA-BIDS/',SubjectNames{s},'/ses-0001/anat/',SubjectNames{s},'_ses-0001_T1w.nii.gz']};
end
clear s;

%% TEST
% SubjectNames(:,(1)) = {'sub-0150'};
% SubjectNames(:,(2)) = {'sub-0151'};
% SubjectNames(:,(3)) = {'sub-0164'};
% SubjectNames(:,(4)) = {'sub-0172'};
% SubjectNames(:,(5)) = {'sub-0173'};
% SubjectNames(:,(6)) = {'sub-0174'};
% SubjectNames(:,(7)) = {'sub-0184'};
% SubjectNames(:,(8)) = {'sub-0104'};
% SubjectNames(:,(9)) = {'sub-0134'};
% SubjectNames(:,(10)) = {'sub-0147'};

%% STEP 1.5 We are now ready to import and normalize the MRIs 

for s = 1:length(SubjectNames)
    bst_process('CallProcess', 'process_import_mri', [], [], ...
        'subjectname', SubjectNames{s}, ...
        'mrifile',     {RawFiles{s}, 'ALL'}, ...
        'nas',         [], ...
        'lpa',         [], ...
        'rpa',         [], ...
        'ac',          [], ...
        'pc',          [], ...
        'ih',          []);
end
clear s; 

% 1.6 Here we normalize the MRIs in order to set the fiducials

for s = 1:length(SubjectNames)
    bst_process('CallProcess', 'process_mni_normalize', [], [], ...
        'subjectname', SubjectNames{s}, ...
        'method',      'maff8');
end
clear s;

%% 1.7 We are finally ready to reconstruct the MRIs using CAT12

for s = 1:length(SubjectNames)
bst_process('CallProcess', 'process_segment_cat12', [], [], ...
    'subjectname', SubjectNames{s}, ...
    'nvertices',   15000, ...
    'tpmnii',      {'', 'Nifti1'}, ...
    'sphreg',      1, ...
    'vol',         1, ...
    'extramaps',   0, ...
    'cerebellum',  0);
end
clear s;
