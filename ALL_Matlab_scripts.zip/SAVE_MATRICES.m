cd /home/oscar/TEST/SCRIPTS
save PLV.mat sFilesPLV_LEFT sFilesPLV_RIGHT

load /home/oscar/TEST/SCRIPTS/PLV.mat

data = load(['/home/oscar/Documents/brainstorm_db/PreProcessing_Automated_Pipeline/data/',sFilesPLV_RIGHT(1).FileName]);

