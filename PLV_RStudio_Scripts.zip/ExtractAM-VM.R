## Extract AM & VM columns and create Subtraction column for each sub/hem/band

## Using sub0002/L as an example

Vector <- PLV_sub0002$LEFT$delta[4:6,c(1,3)]
AM_VM_L_0002_delta <- data.frame (Vector)
AM_VM_L_0002_delta$Sub <- (AM_VM_L_0002_delta$A1 - AM_VM_L_0002_delta$V1)
rm(Vector)
AM_VM_L_0002_delta

Vector <- PLV_sub0002$LEFT$theta[4:6,c(1,3)]
AM_VM_L_0002_theta <- data.frame (Vector)
AM_VM_L_0002_theta$Sub <- (AM_VM_L_0002_theta$A1 - AM_VM_L_0002_theta$V1)
rm(Vector)
AM_VM_L_0002_theta

Vector <- PLV_sub0002$LEFT$alpha[4:6,c(1,3)]
AM_VM_L_0002_alpha <- data.frame (Vector)
AM_VM_L_0002_alpha$Sub <- (AM_VM_L_0002_alpha$A1 - AM_VM_L_0002_alpha$V1)
rm(Vector)
AM_VM_L_0002_alpha

Vector <- PLV_sub0002$LEFT$beta[4:6,c(1,3)]
AM_VM_L_0002_beta <- data.frame (Vector)
AM_VM_L_0002_beta$Sub <- (AM_VM_L_0002_beta$A1 - AM_VM_L_0002_beta$V1)
rm(Vector)
AM_VM_L_0002_beta

Vector <- PLV_sub0002$LEFT$gamma1[4:6,c(1,3)]
AM_VM_L_0002_gamma1 <- data.frame (Vector)
AM_VM_L_0002_gamma1$Sub <- (AM_VM_L_0002_gamma1$A1 - AM_VM_L_0002_gamma1$V1)
rm(Vector)
AM_VM_L_0002_gamma1

Vector <- PLV_sub0002$LEFT$gamma2[4:6,c(1,3)]
AM_VM_L_0002_gamma2 <- data.frame (Vector)
AM_VM_L_0002_gamma2$Sub <- (AM_VM_L_0002_gamma2$A1 - AM_VM_L_0002_gamma2$V1)
rm(Vector)
AM_VM_L_0002_gamma2

## Using sub0002/R as an example

Vector <- PLV_sub0002$RIGHT$delta[4:6,c(1,3)]
AM_VM_R_0002_delta <- data.frame (Vector)
AM_VM_R_0002_delta$Sub <- (AM_VM_R_0002_delta$A1 - AM_VM_R_0002_delta$V1)
rm(Vector)
AM_VM_R_0002_delta

Vector <- PLV_sub0002$RIGHT$theta[4:6,c(1,3)]
AM_VM_R_0002_theta <- data.frame (Vector)
AM_VM_R_0002_theta$Sub <- (AM_VM_R_0002_theta$A1 - AM_VM_R_0002_theta$V1)
rm(Vector)
AM_VM_R_0002_theta

Vector <- PLV_sub0002$RIGHT$alpha[4:6,c(1,3)]
AM_VM_R_0002_alpha <- data.frame (Vector)
AM_VM_R_0002_alpha$Sub <- (AM_VM_R_0002_alpha$A1 - AM_VM_R_0002_alpha$V1)
rm(Vector)
AM_VM_R_0002_alpha

Vector <- PLV_sub0002$RIGHT$beta[4:6,c(1,3)]
AM_VM_R_0002_beta <- data.frame (Vector)
AM_VM_R_0002_beta$Sub <- (AM_VM_R_0002_beta$A1 - AM_VM_R_0002_beta$V1)
rm(Vector)
AM_VM_R_0002_beta

Vector <- PLV_sub0002$RIGHT$gamma1[4:6,c(1,3)]
AM_VM_R_0002_gamma1 <- data.frame (Vector)
AM_VM_R_0002_gamma1$Sub <- (AM_VM_R_0002_gamma1$A1 - AM_VM_R_0002_gamma1$V1)
rm(Vector)
AM_VM_R_0002_gamma1

Vector <- PLV_sub0002$RIGHT$gamma2[4:6,c(1,3)]
AM_VM_R_0002_gamma2 <- data.frame (Vector)
AM_VM_R_0002_gamma2$Sub <- (AM_VM_R_0002_gamma2$A1 - AM_VM_R_0002_gamma2$V1)
rm(Vector)
AM_VM_R_0002_gamma2

## We add ALL of it into a list

AM_VM_LEFT_sub0002 <- list(delta = AM_VM_L_0002_delta,
                           theta = AM_VM_L_0002_theta,
                           alpha = AM_VM_L_0002_alpha,
                           beta = AM_VM_L_0002_beta,
                           gamma1 = AM_VM_L_0002_gamma1,
                           gamma2 = AM_VM_L_0002_gamma2)

rm (AM_VM_L_0002_alpha,AM_VM_L_0002_beta,AM_VM_L_0002_delta,AM_VM_L_0002_gamma1,AM_VM_L_0002_gamma2,AM_VM_L_0002_theta)

AM_VM_RIGHT_sub0002 <- list(delta = AM_VM_R_0002_delta,
                           theta = AM_VM_R_0002_theta,
                           alpha = AM_VM_R_0002_alpha,
                           beta = AM_VM_R_0002_beta,
                           gamma1 = AM_VM_R_0002_gamma1,
                           gamma2 = AM_VM_R_0002_gamma2)

rm (AM_VM_R_0002_alpha,AM_VM_R_0002_beta,AM_VM_R_0002_delta,AM_VM_R_0002_gamma1,AM_VM_R_0002_gamma2,AM_VM_R_0002_theta)

AM_VM_sub0002 <- list(LEFT = AM_VM_LEFT_sub0002,
                      RIGHT = AM_VM_RIGHT_sub0002)

rm (AM_VM_LEFT_sub0002,AM_VM_RIGHT_sub0002)


## We create the ANOVA tables for the AM-VM values

SubjectNames <- c("sub0002","sub0002","sub0003","sub0003","sub0004","sub0004","sub0006","sub0006","sub0007","sub0007")
Hemispheres <- c("L","R","L","R","L","R","L","R","L","R")
Delta_SubValues <-c(AM_VM_sub0002$LEFT$delta[1,3],
              AM_VM_sub0002$RIGHT$delta[1,3],
              AM_VM_sub0003$LEFT$delta[1,3],
              AM_VM_sub0003$RIGHT$delta[1,3],
              AM_VM_sub0004$LEFT$delta[1,3],
              AM_VM_sub0004$RIGHT$delta[1,3],
              AM_VM_sub0006$LEFT$delta[1,3],
              AM_VM_sub0006$RIGHT$delta[1,3],
              AM_VM_sub0007$LEFT$delta[1,3],
              AM_VM_sub0007$RIGHT$delta[1,3])
AM_VM_Delta <- data.frame(cbind(SubjectNames,Hemispheres,Delta_SubValues))

Theta_SubValues <-c(AM_VM_sub0002$LEFT$theta[1,3],
                    AM_VM_sub0002$RIGHT$theta[1,3],
                    AM_VM_sub0003$LEFT$theta[1,3],
                    AM_VM_sub0003$RIGHT$theta[1,3],
                    AM_VM_sub0004$LEFT$theta[1,3],
                    AM_VM_sub0004$RIGHT$theta[1,3],
                    AM_VM_sub0006$LEFT$theta[1,3],
                    AM_VM_sub0006$RIGHT$theta[1,3],
                    AM_VM_sub0007$LEFT$theta[1,3],
                    AM_VM_sub0007$RIGHT$theta[1,3])
AM_VM_Theta <- data.frame(cbind(SubjectNames,Hemispheres,Theta_SubValues))

Alpha_SubValues <-c(AM_VM_sub0002$LEFT$alpha[1,3],
                    AM_VM_sub0002$RIGHT$alpha[1,3],
                    AM_VM_sub0003$LEFT$alpha[1,3],
                    AM_VM_sub0003$RIGHT$alpha[1,3],
                    AM_VM_sub0004$LEFT$alpha[1,3],
                    AM_VM_sub0004$RIGHT$alpha[1,3],
                    AM_VM_sub0006$LEFT$alpha[1,3],
                    AM_VM_sub0006$RIGHT$alpha[1,3],
                    AM_VM_sub0007$LEFT$alpha[1,3],
                    AM_VM_sub0007$RIGHT$alpha[1,3])
AM_VM_Alpha <- data.frame(cbind(SubjectNames,Hemispheres,Alpha_SubValues))

Beta_SubValues <-c(AM_VM_sub0002$LEFT$beta[1,3],
                    AM_VM_sub0002$RIGHT$beta[1,3],
                    AM_VM_sub0003$LEFT$beta[1,3],
                    AM_VM_sub0003$RIGHT$beta[1,3],
                    AM_VM_sub0004$LEFT$beta[1,3],
                    AM_VM_sub0004$RIGHT$beta[1,3],
                    AM_VM_sub0006$LEFT$beta[1,3],
                    AM_VM_sub0006$RIGHT$beta[1,3],
                    AM_VM_sub0007$LEFT$beta[1,3],
                    AM_VM_sub0007$RIGHT$beta[1,3])
AM_VM_Beta <- data.frame(cbind(SubjectNames,Hemispheres,Beta_SubValues))

Gamma1_SubValues <-c(AM_VM_sub0002$LEFT$gamma1[1,3],
                    AM_VM_sub0002$RIGHT$gamma1[1,3],
                    AM_VM_sub0003$LEFT$gamma1[1,3],
                    AM_VM_sub0003$RIGHT$gamma1[1,3],
                    AM_VM_sub0004$LEFT$gamma1[1,3],
                    AM_VM_sub0004$RIGHT$gamma1[1,3],
                    AM_VM_sub0006$LEFT$gamma1[1,3],
                    AM_VM_sub0006$RIGHT$gamma1[1,3],
                    AM_VM_sub0007$LEFT$gamma1[1,3],
                    AM_VM_sub0007$RIGHT$gamma1[1,3])
AM_VM_Gamma1 <- data.frame(cbind(SubjectNames,Hemispheres,Gamma1_SubValues))

Gamma2_SubValues <-c(AM_VM_sub0002$LEFT$gamma2[1,3],
                    AM_VM_sub0002$RIGHT$gamma2[1,3],
                    AM_VM_sub0003$LEFT$gamma2[1,3],
                    AM_VM_sub0003$RIGHT$gamma2[1,3],
                    AM_VM_sub0004$LEFT$gamma2[1,3],
                    AM_VM_sub0004$RIGHT$gamma2[1,3],
                    AM_VM_sub0006$LEFT$gamma2[1,3],
                    AM_VM_sub0006$RIGHT$gamma2[1,3],
                    AM_VM_sub0007$LEFT$gamma2[1,3],
                    AM_VM_sub0007$RIGHT$gamma2[1,3])
AM_VM_Gamma2 <- data.frame(cbind(SubjectNames,Hemispheres,Gamma2_SubValues))

rm (SubjectNames,Hemispheres)
rm(Delta_SubValues,Theta_SubValues,Alpha_SubValues,Beta_SubValues,Gamma1_SubValues,Gamma2_SubValues)

AM_VM_Bands <- list(delta = AM_VM_Delta,
                    theta = AM_VM_Theta,
                    alpha = AM_VM_Alpha,
                    beta = AM_VM_Beta,
                    gamma1 = AM_VM_Gamma1,
                    gamma2 = AM_VM_Gamma2)

rm(AM_VM_Delta,AM_VM_Theta,AM_VM_Alpha,AM_VM_Beta,AM_VM_Gamma1,AM_VM_Gamma2)

## We create the ANOVA tables for the AM-vPMC values

SubjectNames <- c("sub0002","sub0002","sub0003","sub0003","sub0004","sub0004","sub0006","sub0006","sub0007","sub0007")
Hemispheres <- c("L","R","L","R","L","R","L","R","L","R")
Delta_SubValues <-c(AM_VM_sub0002$LEFT$delta[2,3],
                    AM_VM_sub0002$RIGHT$delta[2,3],
                    AM_VM_sub0003$LEFT$delta[2,3],
                    AM_VM_sub0003$RIGHT$delta[2,3],
                    AM_VM_sub0004$LEFT$delta[2,3],
                    AM_VM_sub0004$RIGHT$delta[2,3],
                    AM_VM_sub0006$LEFT$delta[2,3],
                    AM_VM_sub0006$RIGHT$delta[2,3],
                    AM_VM_sub0007$LEFT$delta[2,3],
                    AM_VM_sub0007$RIGHT$delta[2,3])
AM_vPMC_Delta <- data.frame(cbind(SubjectNames,Hemispheres,Delta_SubValues))

Theta_SubValues <-c(AM_VM_sub0002$LEFT$theta[2,3],
                    AM_VM_sub0002$RIGHT$theta[2,3],
                    AM_VM_sub0003$LEFT$theta[2,3],
                    AM_VM_sub0003$RIGHT$theta[2,3],
                    AM_VM_sub0004$LEFT$theta[2,3],
                    AM_VM_sub0004$RIGHT$theta[2,3],
                    AM_VM_sub0006$LEFT$theta[2,3],
                    AM_VM_sub0006$RIGHT$theta[2,3],
                    AM_VM_sub0007$LEFT$theta[2,3],
                    AM_VM_sub0007$RIGHT$theta[2,3])
AM_vPMC_Theta <- data.frame(cbind(SubjectNames,Hemispheres,Theta_SubValues))

Alpha_SubValues <-c(AM_VM_sub0002$LEFT$alpha[2,3],
                    AM_VM_sub0002$RIGHT$alpha[2,3],
                    AM_VM_sub0003$LEFT$alpha[2,3],
                    AM_VM_sub0003$RIGHT$alpha[2,3],
                    AM_VM_sub0004$LEFT$alpha[2,3],
                    AM_VM_sub0004$RIGHT$alpha[2,3],
                    AM_VM_sub0006$LEFT$alpha[2,3],
                    AM_VM_sub0006$RIGHT$alpha[2,3],
                    AM_VM_sub0007$LEFT$alpha[2,3],
                    AM_VM_sub0007$RIGHT$alpha[2,3])
AM_vPMC_Alpha <- data.frame(cbind(SubjectNames,Hemispheres,Alpha_SubValues))

Beta_SubValues <-c(AM_VM_sub0002$LEFT$beta[2,3],
                   AM_VM_sub0002$RIGHT$beta[2,3],
                   AM_VM_sub0003$LEFT$beta[2,3],
                   AM_VM_sub0003$RIGHT$beta[2,3],
                   AM_VM_sub0004$LEFT$beta[2,3],
                   AM_VM_sub0004$RIGHT$beta[2,3],
                   AM_VM_sub0006$LEFT$beta[2,3],
                   AM_VM_sub0006$RIGHT$beta[2,3],
                   AM_VM_sub0007$LEFT$beta[2,3],
                   AM_VM_sub0007$RIGHT$beta[2,3])
AM_vPMC_Beta <- data.frame(cbind(SubjectNames,Hemispheres,Beta_SubValues))

Gamma1_SubValues <-c(AM_VM_sub0002$LEFT$gamma1[2,3],
                     AM_VM_sub0002$RIGHT$gamma1[2,3],
                     AM_VM_sub0003$LEFT$gamma1[2,3],
                     AM_VM_sub0003$RIGHT$gamma1[2,3],
                     AM_VM_sub0004$LEFT$gamma1[2,3],
                     AM_VM_sub0004$RIGHT$gamma1[2,3],
                     AM_VM_sub0006$LEFT$gamma1[2,3],
                     AM_VM_sub0006$RIGHT$gamma1[2,3],
                     AM_VM_sub0007$LEFT$gamma1[2,3],
                     AM_VM_sub0007$RIGHT$gamma1[2,3])
AM_vPMC_Gamma1 <- data.frame(cbind(SubjectNames,Hemispheres,Gamma1_SubValues))

Gamma2_SubValues <-c(AM_VM_sub0002$LEFT$gamma2[2,3],
                     AM_VM_sub0002$RIGHT$gamma2[2,3],
                     AM_VM_sub0003$LEFT$gamma2[2,3],
                     AM_VM_sub0003$RIGHT$gamma2[2,3],
                     AM_VM_sub0004$LEFT$gamma2[2,3],
                     AM_VM_sub0004$RIGHT$gamma2[2,3],
                     AM_VM_sub0006$LEFT$gamma2[2,3],
                     AM_VM_sub0006$RIGHT$gamma2[2,3],
                     AM_VM_sub0007$LEFT$gamma2[2,3],
                     AM_VM_sub0007$RIGHT$gamma2[2,3])
AM_vPMC_Gamma2 <- data.frame(cbind(SubjectNames,Hemispheres,Gamma2_SubValues))

rm (SubjectNames,Hemispheres)
rm(Delta_SubValues,Theta_SubValues,Alpha_SubValues,Beta_SubValues,Gamma1_SubValues,Gamma2_SubValues)

AM_vPMC_Bands <- list(delta = AM_vPMC_Delta,
                    theta = AM_vPMC_Theta,
                    alpha = AM_vPMC_Alpha,
                    beta = AM_vPMC_Beta,
                    gamma1 = AM_vPMC_Gamma1,
                    gamma2 = AM_vPMC_Gamma2)

rm(AM_vPMC_Delta,AM_vPMC_Theta,AM_vPMC_Alpha,AM_vPMC_Beta,AM_vPMC_Gamma1,AM_vPMC_Gamma2)

## We create the ANOVA tables for the AM-dPMC values

SubjectNames <- c("sub0002","sub0002","sub0003","sub0003","sub0004","sub0004","sub0006","sub0006","sub0007","sub0007")
Hemispheres <- c("L","R","L","R","L","R","L","R","L","R")
Delta_SubValues <-c(AM_VM_sub0002$LEFT$delta[3,3],
                    AM_VM_sub0002$RIGHT$delta[3,3],
                    AM_VM_sub0003$LEFT$delta[3,3],
                    AM_VM_sub0003$RIGHT$delta[3,3],
                    AM_VM_sub0004$LEFT$delta[3,3],
                    AM_VM_sub0004$RIGHT$delta[3,3],
                    AM_VM_sub0006$LEFT$delta[3,3],
                    AM_VM_sub0006$RIGHT$delta[3,3],
                    AM_VM_sub0007$LEFT$delta[3,3],
                    AM_VM_sub0007$RIGHT$delta[3,3])
AM_dPMC_Delta <- data.frame(cbind(SubjectNames,Hemispheres,Delta_SubValues))

Theta_SubValues <-c(AM_VM_sub0002$LEFT$theta[3,3],
                    AM_VM_sub0002$RIGHT$theta[3,3],
                    AM_VM_sub0003$LEFT$theta[3,3],
                    AM_VM_sub0003$RIGHT$theta[3,3],
                    AM_VM_sub0004$LEFT$theta[3,3],
                    AM_VM_sub0004$RIGHT$theta[3,3],
                    AM_VM_sub0006$LEFT$theta[3,3],
                    AM_VM_sub0006$RIGHT$theta[3,3],
                    AM_VM_sub0007$LEFT$theta[3,3],
                    AM_VM_sub0007$RIGHT$theta[3,3])
AM_dPMC_Theta <- data.frame(cbind(SubjectNames,Hemispheres,Theta_SubValues))

Alpha_SubValues <-c(AM_VM_sub0002$LEFT$alpha[3,3],
                    AM_VM_sub0002$RIGHT$alpha[3,3],
                    AM_VM_sub0003$LEFT$alpha[3,3],
                    AM_VM_sub0003$RIGHT$alpha[3,3],
                    AM_VM_sub0004$LEFT$alpha[3,3],
                    AM_VM_sub0004$RIGHT$alpha[3,3],
                    AM_VM_sub0006$LEFT$alpha[3,3],
                    AM_VM_sub0006$RIGHT$alpha[3,3],
                    AM_VM_sub0007$LEFT$alpha[3,3],
                    AM_VM_sub0007$RIGHT$alpha[3,3])
AM_dPMC_Alpha <- data.frame(cbind(SubjectNames,Hemispheres,Alpha_SubValues))

Beta_SubValues <-c(AM_VM_sub0002$LEFT$beta[3,3],
                   AM_VM_sub0002$RIGHT$beta[3,3],
                   AM_VM_sub0003$LEFT$beta[3,3],
                   AM_VM_sub0003$RIGHT$beta[3,3],
                   AM_VM_sub0004$LEFT$beta[3,3],
                   AM_VM_sub0004$RIGHT$beta[3,3],
                   AM_VM_sub0006$LEFT$beta[3,3],
                   AM_VM_sub0006$RIGHT$beta[3,3],
                   AM_VM_sub0007$LEFT$beta[3,3],
                   AM_VM_sub0007$RIGHT$beta[3,3])
AM_dPMC_Beta <- data.frame(cbind(SubjectNames,Hemispheres,Beta_SubValues))

Gamma1_SubValues <-c(AM_VM_sub0002$LEFT$gamma1[3,3],
                     AM_VM_sub0002$RIGHT$gamma1[3,3],
                     AM_VM_sub0003$LEFT$gamma1[3,3],
                     AM_VM_sub0003$RIGHT$gamma1[3,3],
                     AM_VM_sub0004$LEFT$gamma1[3,3],
                     AM_VM_sub0004$RIGHT$gamma1[3,3],
                     AM_VM_sub0006$LEFT$gamma1[3,3],
                     AM_VM_sub0006$RIGHT$gamma1[3,3],
                     AM_VM_sub0007$LEFT$gamma1[3,3],
                     AM_VM_sub0007$RIGHT$gamma1[3,3])
AM_dPMC_Gamma1 <- data.frame(cbind(SubjectNames,Hemispheres,Gamma1_SubValues))

Gamma2_SubValues <-c(AM_VM_sub0002$LEFT$gamma2[3,3],
                     AM_VM_sub0002$RIGHT$gamma2[3,3],
                     AM_VM_sub0003$LEFT$gamma2[3,3],
                     AM_VM_sub0003$RIGHT$gamma2[3,3],
                     AM_VM_sub0004$LEFT$gamma2[3,3],
                     AM_VM_sub0004$RIGHT$gamma2[3,3],
                     AM_VM_sub0006$LEFT$gamma2[3,3],
                     AM_VM_sub0006$RIGHT$gamma2[3,3],
                     AM_VM_sub0007$LEFT$gamma2[3,3],
                     AM_VM_sub0007$RIGHT$gamma2[3,3])
AM_dPMC_Gamma2 <- data.frame(cbind(SubjectNames,Hemispheres,Gamma2_SubValues))

rm (SubjectNames,Hemispheres)
rm(Delta_SubValues,Theta_SubValues,Alpha_SubValues,Beta_SubValues,Gamma1_SubValues,Gamma2_SubValues)

AM_dPMC_Bands <- list(delta = AM_dPMC_Delta,
                      theta = AM_dPMC_Theta,
                      alpha = AM_dPMC_Alpha,
                      beta = AM_dPMC_Beta,
                      gamma1 = AM_dPMC_Gamma1,
                      gamma2 = AM_dPMC_Gamma2)

rm(AM_dPMC_Delta,AM_dPMC_Theta,AM_dPMC_Alpha,AM_dPMC_Beta,AM_dPMC_Gamma1,AM_dPMC_Gamma2)

## We create the definitive ANOVA tables

ANOVA_Delta <- data.frame(c(AM_VM_Bands$delta,AM_vPMC_Bands$delta,AM_dPMC_Bands$delta))
ANOVA_Delta <- ANOVA_Delta[,c(1,2,3,6,9)] 
colnames(ANOVA_Delta) <- c("ID","Hemisphere","AM-VM","AM-vPMC","AM-dPMC")

ANOVA_Theta <- data.frame(c(AM_VM_Bands$theta,AM_vPMC_Bands$theta,AM_dPMC_Bands$theta))
ANOVA_Theta <- ANOVA_Theta[,c(1,2,3,6,9)] 
colnames(ANOVA_Theta) <- c("ID","Hemisphere","AM-VM","AM-vPMC","AM-dPMC")

ANOVA_Alpha <- data.frame(c(AM_VM_Bands$alpha,AM_vPMC_Bands$alpha,AM_dPMC_Bands$alpha))
ANOVA_Alpha <- ANOVA_Alpha[,c(1,2,3,6,9)] 
colnames(ANOVA_Alpha) <- c("ID","Hemisphere","AM-VM","AM-vPMC","AM-dPMC")

ANOVA_Beta <- data.frame(c(AM_VM_Bands$beta,AM_vPMC_Bands$beta,AM_dPMC_Bands$beta))
ANOVA_Beta <- ANOVA_Beta[,c(1,2,3,6,9)] 
colnames(ANOVA_Beta) <- c("ID","Hemisphere","AM-VM","AM-vPMC","AM-dPMC")

ANOVA_Gamma1 <- data.frame(c(AM_VM_Bands$gamma1,AM_vPMC_Bands$gamma1,AM_dPMC_Bands$gamma1))
ANOVA_Gamma1 <- ANOVA_Gamma1[,c(1,2,3,6,9)] 
colnames(ANOVA_Gamma1) <- c("ID","Hemisphere","AM-VM","AM-vPMC","AM-dPMC")

ANOVA_Gamma2 <- data.frame(c(AM_VM_Bands$gamma2,AM_vPMC_Bands$gamma2,AM_dPMC_Bands$gamma2))
ANOVA_Gamma2 <- ANOVA_Gamma2[,c(1,2,3,6,9)] 
colnames(ANOVA_Gamma2) <- c("ID","Hemisphere","AM-VM","AM-vPMC","AM-dPMC")

ANOVA_BANDS <- list(delta = ANOVA_Delta,
                    theta = ANOVA_Theta,
                    alpha = ANOVA_Alpha,
                    beta = ANOVA_Beta,
                    gamma1 = ANOVA_Gamma1,
                    gamma2 = ANOVA_Gamma2)

rm(ANOVA_Delta,
   ANOVA_Theta, 
   ANOVA_Alpha,
   ANOVA_Beta,
   ANOVA_Gamma1,
   ANOVA_Gamma2)

Musicianship <- c("Non-Musician","Non-Musician","Non-Musician","Non-Musician","Non-Musician","Non-Musician","Musician","Musician","Non-Musician","Non-Musician")

ANOVA_BANDS$delta$Musicianship <- Musicianship
ANOVA_BANDS$theta$Musicianship <- Musicianship
ANOVA_BANDS$alpha$Musicianship <- Musicianship
ANOVA_BANDS$beta$Musicianship <- Musicianship
ANOVA_BANDS$gamma1$Musicianship <- Musicianship
ANOVA_BANDS$gamma2$Musicianship <- Musicianship

rm(Musicianship)

col_names <- c("ID", "Hemisphere", "Musicianship", "AM-VM", "AM-vPMC", "AM-dPMC")
ANOVA_BANDS$delta <- ANOVA_BANDS$delta[,col_names]
ANOVA_BANDS$theta <- ANOVA_BANDS$theta[,col_names]
ANOVA_BANDS$alpha <- ANOVA_BANDS$alpha[,col_names]
ANOVA_BANDS$beta <- ANOVA_BANDS$beta[,col_names]
ANOVA_BANDS$gamma1 <- ANOVA_BANDS$gamma1[,col_names]
ANOVA_BANDS$gamma2 <- ANOVA_BANDS$gamma2[,col_names]

rm(col_names)