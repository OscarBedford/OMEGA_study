# First we widen by Hemisphere 

library(tidyr)

Delta_Kazuma <- pivot_wider(ANOVA_BANDS$delta, ID, names_from = "Hemisphere", values_from = 3:9)
Theta_Kazuma <- pivot_wider(ANOVA_BANDS$theta, ID, names_from = "Hemisphere", values_from = 3:9)
Alpha_Kazuma <- pivot_wider(ANOVA_BANDS$alpha, ID, names_from = "Hemisphere", values_from = 3:9)
Beta_Kazuma <- pivot_wider(ANOVA_BANDS$beta, ID, names_from = "Hemisphere", values_from = 3:9)
Gamma1_Kazuma <- pivot_wider(ANOVA_BANDS$gamma1, ID, names_from = "Hemisphere", values_from = 3:9)
Gamma2_Kazuma <- pivot_wider(ANOVA_BANDS$gamma2, ID, names_from = "Hemisphere", values_from = 3:9)

# Now we fix the last column 

Delta_Kazuma <- subset (Delta_Kazuma, select = -Musicianship_R)
colnames(Delta_Kazuma)[14] <- "Musicianship"

Theta_Kazuma <- subset (Theta_Kazuma, select = -Musicianship_R)
colnames(Theta_Kazuma)[14] <- "Musicianship"

Alpha_Kazuma <- subset (Alpha_Kazuma, select = -Musicianship_R)
colnames(Alpha_Kazuma)[14] <- "Musicianship"

Beta_Kazuma <- subset (Beta_Kazuma, select = -Musicianship_R)
colnames(Beta_Kazuma)[14] <- "Musicianship"

Gamma1_Kazuma <- subset (Gamma1_Kazuma, select = -Musicianship_R)
colnames(Gamma1_Kazuma)[14] <- "Musicianship"

Gamma2_Kazuma <- subset (Gamma2_Kazuma, select = -Musicianship_R)
colnames(Gamma2_Kazuma)[14] <- "Musicianship"

# Add prefixes

Delta_Values <- Delta_Kazuma[2:13]
colnames(Delta_Values) <- paste0("Delta_", colnames(Delta_Values))

Theta_Values <- Theta_Kazuma[2:13]
colnames(Theta_Values) <- paste0("Theta_", colnames(Theta_Values))

Alpha_Values <- Alpha_Kazuma[2:13]
colnames(Alpha_Values) <- paste0("Alpha_", colnames(Alpha_Values))

Beta_Values <- Beta_Kazuma[2:13]
colnames(Beta_Values) <- paste0("Beta_", colnames(Beta_Values))

Gamma1_Values <- Gamma1_Kazuma[2:13]
colnames(Gamma1_Values) <- paste0("Gamma1_", colnames(Gamma1_Values))

Gamma2_Values <- Gamma2_Kazuma[2:13]
colnames(Gamma2_Values) <- paste0("Gamma2_", colnames(Gamma2_Values))

# Add ID and musicianship to Delta

library("dplyr")

Delta_Values[13] <- Delta_Kazuma[1]
Theta_Values[13] <- Theta_Kazuma[1]
Alpha_Values[13] <- Alpha_Kazuma[1]
Beta_Values[13] <- Beta_Kazuma[1]
Gamma1_Values[13] <- Gamma1_Kazuma[1]
Gamma2_Values[13] <- Gamma2_Kazuma[1]

Delta_Values <- Delta_Values[, c(13, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)]
Theta_Values <- Theta_Values[, c(13, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)]
Alpha_Values <- Alpha_Values[, c(13, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)]
Beta_Values <- Beta_Values[, c(13, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)]
Gamma1_Values <- Gamma1_Values[, c(13, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)]
Gamma2_Values <- Gamma2_Values[, c(13, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)]

library(tidyverse)

Kazuma_mega <- full_join(Delta_Values,Theta_Values, by = "ID")
Kazuma_mega <- full_join(Kazuma_mega, Alpha_Values, by = "ID")
Kazuma_mega <- full_join(Kazuma_mega, Beta_Values, by = "ID")
Kazuma_mega <- full_join(Kazuma_mega, Gamma1_Values, by = "ID")
Kazuma_mega <- full_join(Kazuma_mega, Gamma2_Values, by = "ID")

Kazuma_mega[74] <- Delta_Kazuma[14]
Kazuma_mega <- Kazuma_mega[,c(74, 1:73)]
Kazuma_mega <- subset(Kazuma_mega, select = -c(ID))

Kazuma_mega <- apply(Kazuma_mega,2,as.character)

write.csv(Kazuma_mega, file = "Kazuma_ML.csv",row.names = TRUE)
