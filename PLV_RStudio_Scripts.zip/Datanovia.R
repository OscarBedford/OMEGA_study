# STEP 0: We load the required libraries

library(tidyr)
library(ggpubr)
library(rstatix)
library(tibble)

# STEP 1.1: We Identify the outliers

Delta_outliers <- Delta %>%
  identify_outliers(PLV)

Theta_outliers <- Theta %>%
  identify_outliers(PLV)

Alpha_outliers <- Alpha %>%
  identify_outliers(PLV)

Beta_outliers <- Beta %>%
  identify_outliers(PLV)

Gamma1_outliers <- Gamma1 %>%
  identify_outliers(PLV)

Gamma2_outliers <- Gamma2 %>%
  identify_outliers(PLV)

Outliers_Bands = list(Delta = Delta_outliers,
                      Theta = Theta_outliers,
                      Alpha = Alpha_outliers,
                      Beta = Beta_outliers,
                      Gamma1 = Gamma1_outliers,
                      Gamma2 = Gamma2_outliers)

rm(Delta_outliers, Theta_outliers, Alpha_outliers, Beta_outliers, Gamma1_outliers, Gamma2_outliers)

# Step 1.2: Removing outliers from the data

Q1 <- quantile(Delta$PLV, .25)
Q3 <- quantile(Delta$PLV, .75)
IQR <- IQR(Delta$PLV)
Delta_no_outliers = subset(Delta, Delta$PLV > (Q1 - 1.5*IQR) & Delta$PLV < (Q3 + 1.5*IQR))

Q1 <- quantile(Theta$PLV, .25)
Q3 <- quantile(Theta$PLV, .75)
IQR <- IQR(Theta$PLV)
Theta_no_outliers = subset(Theta, Theta$PLV > (Q1 - 1.5*IQR) & Theta$PLV < (Q3 + 1.5*IQR))

Q1 <- quantile(Alpha$PLV, .25)
Q3 <- quantile(Alpha$PLV, .75)
IQR <- IQR(Alpha$PLV)
Alpha_no_outliers = subset(Alpha, Alpha$PLV > (Q1 - 1.5*IQR) & Alpha$PLV < (Q3 + 1.5*IQR))

Q1 <- quantile(Beta$PLV, .25)
Q3 <- quantile(Beta$PLV, .75)
IQR <- IQR(Beta$PLV)
Beta_no_outliers = subset(Beta, Beta$PLV > (Q1 - 1.5*IQR) & Beta$PLV < (Q3 + 1.5*IQR))

Q1 <- quantile(Gamma1$PLV, .25)
Q3 <- quantile(Gamma1$PLV, .75)
IQR <- IQR(Gamma1$PLV)
Gamma1_no_outliers = subset(Gamma1, Gamma1$PLV > (Q1 - 1.5*IQR) & Gamma1$PLV < (Q3 + 1.5*IQR))

Q1 <- quantile(Gamma2$PLV, .25)
Q3 <- quantile(Gamma2$PLV, .75)
IQR <- IQR(Gamma2$PLV)
Gamma2_no_outliers = subset(Gamma2, Gamma2$PLV > (Q1 - 1.5*IQR) & Gamma2$PLV < (Q3 + 1.5*IQR))

# STEP 2: Summary statistics

Delta_Summary_Musicianship <- Delta %>%
  group_by(Musicianship) %>%
  get_summary_stats(PLV, type = "mean_sd")

Delta_Summary_Musicianship$n <- as.numeric(as.character(Delta_Summary_Musicianship$n)) / 12

Delta_Summary_Hem.Mod.MR <- Delta %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Delta_Summary = list(Musicianship = Delta_Summary_Musicianship, Modality = Delta_Summary_Hem.Mod.MR)

rm(Delta_Summary_Hem.Mod.MR,Delta_Summary_Musicianship)

Theta_Summary_Musicianship <- Theta %>%
  group_by(Musicianship) %>%
  get_summary_stats(PLV, type = "mean_sd")

Theta_Summary_Musicianship$n <- as.numeric(as.character(Theta_Summary_Musicianship$n)) / 12

Theta_Summary_Hem.Mod.MR <- Theta %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Theta_Summary = list(Musicianship = Theta_Summary_Musicianship, Modality = Theta_Summary_Hem.Mod.MR)

rm(Theta_Summary_Hem.Mod.MR,Theta_Summary_Musicianship)

Alpha_Summary_Musicianship <- Alpha %>%
  group_by(Musicianship) %>%
  get_summary_stats(PLV, type = "mean_sd")

Alpha_Summary_Musicianship$n <- as.numeric(as.character(Alpha_Summary_Musicianship$n)) / 12

Alpha_Summary_Hem.Mod.MR <- Alpha %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Alpha_Summary = list(Musicianship = Alpha_Summary_Musicianship, Modality = Alpha_Summary_Hem.Mod.MR)

rm(Alpha_Summary_Hem.Mod.MR,Alpha_Summary_Musicianship)

Beta_Summary_Musicianship <- Beta %>%
  group_by(Musicianship) %>%
  get_summary_stats(PLV, type = "mean_sd")

Beta_Summary_Musicianship$n <- as.numeric(as.character(Beta_Summary_Musicianship$n)) / 12

Beta_Summary_Hem.Mod.MR <- Beta %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Beta_Summary = list(Musicianship = Beta_Summary_Musicianship, Modality = Beta_Summary_Hem.Mod.MR)

rm(Beta_Summary_Hem.Mod.MR,Beta_Summary_Musicianship)

Gamma1_Summary_Musicianship <- Gamma1 %>%
  group_by(Musicianship) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma1_Summary_Musicianship$n <- as.numeric(as.character(Gamma1_Summary_Musicianship$n)) / 12

Gamma1_Summary_Hem.Mod.MR <- Gamma1 %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma1_Summary = list(Musicianship = Gamma1_Summary_Musicianship, Modality = Gamma1_Summary_Hem.Mod.MR)

rm(Gamma1_Summary_Hem.Mod.MR,Gamma1_Summary_Musicianship)

Gamma2_Summary_Musicianship <- Gamma2 %>%
  group_by(Musicianship) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma2_Summary_Musicianship$n <- as.numeric(as.character(Gamma2_Summary_Musicianship$n)) / 12

Gamma2_Summary_Hem.Mod.MR <- Gamma2 %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma2_Summary = list(Musicianship = Gamma2_Summary_Musicianship, Modality = Gamma2_Summary_Hem.Mod.MR)

rm(Gamma2_Summary_Hem.Mod.MR,Gamma2_Summary_Musicianship)

# STEP 3: Boxplots

Delta_Boxplot_Musicianship <- ggboxplot(
     Delta, x = "Musicianship", y = "PLV",
     color = "Modality", palette = "jco",
     facet.by = "Hemisphere", short.panel.labs = FALSE,
     title= "Delta: Boxplot of 'Musicianship/Hemisphere/Modality' BEFORE outlier removal",
     )

custom_colors <- c("gray50", "gray90")

Delta_Boxplot_MotorRegions <- ggboxplot(
  Delta, x = "Motor_Region", y = "PLV",
  xlab = "Motor region",
  fill = "Hemisphere", 
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Delta: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region'"
) +
  scale_fill_manual(values = custom_colors) +
  theme(strip.text = element_text(size = 12)) +
  theme(legend.position = "top", 
        axis.text.x =  element_text(face = "bold", size = 13),
        strip.text.x = element_text(face = "bold", size = 13),
        axis.title.x = element_text(size = 13))

Delta_Boxplot_MotorRegions

Delta_Clean_Boxplot_Musicianship <- ggboxplot(
  Delta, x = "Musicianship", y = "PLV",
  color = "Modality", palette = "jco",
  facet.by = "Hemisphere", short.panel.labs = FALSE,
  title= "Delta: Boxplot of 'Musicianship/Hemisphere/Modality' AFTER outlier removal",
)

Delta_Clean_Boxplot_MotorRegions <- ggboxplot(
  Delta, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Delta: Boxplot of 'Hemisphere/Modality/Motor_Region'",
)

Delta_Boxplots = list(Musicianship_BEFORE = Delta_Boxplot_Musicianship, 
                      Musicianship_AFTER = Delta_Clean_Boxplot_Musicianship, 
                      MotorRegions_BEFORE = Delta_Boxplot_MotorRegions,
                      MotorRegions_AFTER = Delta_Clean_Boxplot_MotorRegions)
rm (Delta_Boxplot_Musicianship,Delta_Boxplot_MotorRegions,
    Delta_Clean_Boxplot_Musicianship,Delta_Clean_Boxplot_MotorRegions)

Theta_Boxplot_Musicianship <- ggboxplot(
  Theta, x = "Musicianship", y = "PLV",
  color = "Modality", palette = "jco",
  facet.by = "Hemisphere", short.panel.labs = FALSE,
  title= "Theta: Boxplot of 'Musicianship/Hemisphere/Modality' BEFORE outlier removal",
)

custom_colors <- c("dodgerblue", "indianred2")

Theta_Boxplot_MotorRegions <- ggboxplot(
  Theta, x = "Motor_Region", y = "PLV",
  xlab = "Motor region",
  fill = "Hemisphere", 
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Theta: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region'"
) +
  scale_fill_manual(values = custom_colors) +
  theme(strip.text = element_text(size = 12)) +
  theme(legend.position = "top", 
        axis.text.x =  element_text(face = "bold", size = 13),
        strip.text.x = element_text(face = "bold", size = 13),
        axis.title.x = element_text(size = 13))

Theta_Boxplot_MotorRegions

Theta_Clean_Boxplot_Musicianship <- ggboxplot(
  Theta_no_outliers, x = "Musicianship", y = "PLV",
  color = "Modality", palette = "jco",
  facet.by = "Hemisphere", short.panel.labs = FALSE,
  title= "Theta: Boxplot of 'Musicianship/Hemisphere/Modality' AFTER outlier removal",
)

Theta_Clean_Boxplot_MotorRegions <- ggboxplot(
  Theta_no_outliers, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Theta: Boxplot of 'Hemisphere/Modality/Motor_Region' AFTER outlier removal",
)

Theta_Boxplots = list(Musicianship_BEFORE = Theta_Boxplot_Musicianship, 
                      Musicianship_AFTER = Theta_Clean_Boxplot_Musicianship, 
                      MotorRegions_BEFORE = Theta_Boxplot_MotorRegions,
                      MotorRegions_AFTER = Theta_Clean_Boxplot_MotorRegions)
rm (Theta_Boxplot_Musicianship,Theta_Boxplot_MotorRegions,
    Theta_Clean_Boxplot_Musicianship,Theta_Clean_Boxplot_MotorRegions)

Alpha_Boxplot_Musicianship <- ggboxplot(
  Alpha, x = "Musicianship", y = "PLV",
  color = "Modality", palette = "jco",
  facet.by = "Hemisphere", short.panel.labs = FALSE,
  title= "Alpha: Boxplot of 'Musicianship/Hemisphere/Modality' BEFORE outlier removal",
)

custom_colors <- c("dodgerblue", "indianred2")

Alpha_Boxplot_MotorRegions <- ggboxplot(
  Alpha, x = "Motor_Region", y = "PLV",
  xlab = "Motor region",
  fill = "Hemisphere", 
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Alpha: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region'"
) +
  scale_fill_manual(values = custom_colors) +
  theme(strip.text = element_text(size = 12)) +
  theme(legend.position = "top", 
        axis.text.x =  element_text(face = "bold", size = 13),
        strip.text.x = element_text(face = "bold", size = 13),
        axis.title.x = element_text(size = 13))

Alpha_Boxplot_MotorRegions

Alpha_Clean_Boxplot_Musicianship <- ggboxplot(
  Alpha_no_outliers, x = "Musicianship", y = "PLV",
  color = "Modality", palette = "jco",
  facet.by = "Hemisphere", short.panel.labs = FALSE,
  title= "Alpha: Boxplot of 'Musicianship/Hemisphere/Modality' AFTER outlier removal",
)

Alpha_Clean_Boxplot_MotorRegions <- ggboxplot(
  Alpha_no_outliers, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Alpha: Boxplot of 'Hemisphere/Modality/Motor_Region' AFTER outlier removal",
)

Alpha_Boxplots = list(Musicianship_BEFORE = Alpha_Boxplot_Musicianship, 
                      Musicianship_AFTER = Alpha_Clean_Boxplot_Musicianship, 
                      MotorRegions_BEFORE = Alpha_Boxplot_MotorRegions,
                      MotorRegions_AFTER = Alpha_Clean_Boxplot_MotorRegions)
rm (Alpha_Boxplot_Musicianship,Alpha_Boxplot_MotorRegions,
    Alpha_Clean_Boxplot_Musicianship,Alpha_Clean_Boxplot_MotorRegions)

Beta_Boxplot_Musicianship <- ggboxplot(
  Beta, x = "Musicianship", y = "PLV",
  color = "Modality", palette = "jco",
  facet.by = "Hemisphere", short.panel.labs = FALSE,
  title= "Beta: Boxplot of 'Musicianship/Hemisphere/Modality' BEFORE outlier removal",
)

set2_colors <- brewer.pal(11, "RdBu")
print(set2_colors)

custom_colors <- c("dodgerblue", "indianred2")

Beta_Boxplot_MotorRegions <- ggboxplot(
  Beta, x = "Motor_Region", y = "PLV",
  xlab = "Motor region",
  fill = "Hemisphere", 
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Beta: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region'"
) +
  scale_fill_manual(values = custom_colors) +
  theme(strip.text = element_text(size = 12)) +
  theme(legend.position = "top", 
        axis.text.x =  element_text(face = "bold", size = 13),
        strip.text.x = element_text(face = "bold", size = 13),
        axis.title.x = element_text(size = 13))

Beta_Boxplot_MotorRegions

Beta_Boxplot_MotorRegions +
  font("xlab", size = 17, color = "navy", face = "bold")+
  font("ylab", size = 17, color = "navy", face = "bold")+
  font("x.text", size = 15)+
  font("y.text", size = 15)

Beta_Clean_Boxplot_Musicianship <- ggboxplot(
  Beta_no_outliers, x = "Musicianship", y = "PLV",
  color = "Modality", palette = "jco",
  facet.by = "Hemisphere", short.panel.labs = FALSE,
  title= "Beta: Boxplot of 'Musicianship/Hemisphere/Modality' AFTER outlier removal",
)

Beta_Clean_Boxplot_MotorRegions <- ggboxplot(
  Beta_no_outliers, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Beta: Boxplot of 'Hemisphere/Modality/Motor_Region' AFTER outlier removal",
)

Beta_Boxplots = list(Musicianship_BEFORE = Beta_Boxplot_Musicianship, 
                      Musicianship_AFTER = Beta_Clean_Boxplot_Musicianship, 
                      MotorRegions_BEFORE = Beta_Boxplot_MotorRegions,
                      MotorRegions_AFTER = Beta_Clean_Boxplot_MotorRegions)
rm (Beta_Boxplot_Musicianship,Beta_Boxplot_MotorRegions,
    Beta_Clean_Boxplot_Musicianship,Beta_Clean_Boxplot_MotorRegions)

Gamma1_Boxplot_Musicianship <- ggboxplot(
  Gamma1, x = "Musicianship", y = "PLV",
  color = "Modality", palette = "jco",
  facet.by = "Hemisphere", short.panel.labs = FALSE,
  title= "Gamma1: Boxplot of 'Musicianship/Hemisphere/Modality' BEFORE outlier removal",
)

custom_colors <- c("dodgerblue", "indianred2")

Gamma1_Boxplot_MotorRegions <- ggboxplot(
  Gamma1, x = "Motor_Region", y = "PLV",
  xlab = "Motor region",
  fill = "Hemisphere", 
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma1: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region'"
) +
  scale_fill_manual(values = custom_colors) +
  theme(strip.text = element_text(size = 12)) +
  theme(legend.position = "top", 
        axis.text.x =  element_text(face = "bold", size = 13),
        strip.text.x = element_text(face = "bold", size = 13),
        axis.title.x = element_text(size = 13))

Gamma1_Boxplot_MotorRegions

Gamma1_Clean_Boxplot_Musicianship <- ggboxplot(
  Gamma1_no_outliers, x = "Musicianship", y = "PLV",
  color = "Modality", palette = "jco",
  facet.by = "Hemisphere", short.panel.labs = FALSE,
  title= "Gamma1: Boxplot of 'Musicianship/Hemisphere/Modality' AFTER outlier removal",
)

Gamma1_Clean_Boxplot_MotorRegions <- ggboxplot(
  Gamma1_no_outliers, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma1: Boxplot of 'Hemisphere/Modality/Motor_Region' AFTER outlier removal",
)

Gamma1_Boxplots = list(Musicianship_BEFORE = Gamma1_Boxplot_Musicianship, 
                      Musicianship_AFTER = Gamma1_Clean_Boxplot_Musicianship, 
                      MotorRegions_BEFORE = Gamma1_Boxplot_MotorRegions,
                      MotorRegions_AFTER = Gamma1_Clean_Boxplot_MotorRegions)
rm (Gamma1_Boxplot_Musicianship,Gamma1_Boxplot_MotorRegions,
    Gamma1_Clean_Boxplot_Musicianship,Gamma1_Clean_Boxplot_MotorRegions)

Gamma2_Boxplot_Musicianship <- ggboxplot(
  Gamma2, x = "Musicianship", y = "PLV",
  color = "Modality", palette = "jco",
  facet.by = "Hemisphere", short.panel.labs = FALSE,
  title= "Gamma2: Boxplot of 'Musicianship/Hemisphere/Modality' BEFORE outlier removal",
)

custom_colors <- c("dodgerblue", "indianred2")

Gamma2_Boxplot_MotorRegions <- ggboxplot(
  Gamma2, x = "Motor_Region", y = "PLV",
  xlab = "Motor region",
  fill = "Hemisphere", 
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma2: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region'"
) +
  scale_fill_manual(values = custom_colors) +
  theme(strip.text = element_text(size = 12)) +
  theme(legend.position = "top", 
        axis.text.x =  element_text(face = "bold", size = 13),
        strip.text.x = element_text(face = "bold", size = 13),
        axis.title.x = element_text(size = 13))

Gamma2_Boxplot_MotorRegions

Gamma2_Clean_Boxplot_Musicianship <- ggboxplot(
  Gamma2_no_outliers, x = "Musicianship", y = "PLV",
  color = "Modality", palette = "jco",
  facet.by = "Hemisphere", short.panel.labs = FALSE,
  title= "Gamma2: Boxplot of 'Musicianship/Hemisphere/Modality' AFTER outlier removal",
)

Gamma2_Clean_Boxplot_MotorRegions <- ggboxplot(
  Gamma2_no_outliers, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma2: Boxplot of 'Hemisphere/Modality/Motor_Region' AFTER outlier removal",
)

Gamma2_Boxplots = list(Musicianship_BEFORE = Gamma2_Boxplot_Musicianship, 
                      Musicianship_AFTER = Gamma2_Clean_Boxplot_Musicianship, 
                      MotorRegions_BEFORE = Gamma2_Boxplot_MotorRegions,
                      MotorRegions_AFTER = Gamma2_Clean_Boxplot_MotorRegions)
rm (Gamma2_Boxplot_Musicianship,Gamma2_Boxplot_MotorRegions,
    Gamma2_Clean_Boxplot_Musicianship,Gamma2_Clean_Boxplot_MotorRegions)

# Step 4: We funnel everything into one mega-list

Delta_Info = list(Stats = Delta_Summary, Plots = Delta_Boxplots)
rm (Delta_Summary,Delta_Boxplots)

Theta_Info = list(Stats = Theta_Summary, Plots = Theta_Boxplots)
rm (Theta_Summary,Theta_Boxplots)

Alpha_Info = list(Stats = Alpha_Summary, Plots = Alpha_Boxplots)
rm (Alpha_Summary,Alpha_Boxplots)

Beta_Info = list(Stats = Beta_Summary, Plots = Beta_Boxplots)
rm (Beta_Summary,Beta_Boxplots)

Gamma1_Info = list(Stats = Gamma1_Summary, Plots = Gamma1_Boxplots)
rm (Gamma1_Summary,Gamma1_Boxplots)

Gamma2_Info = list(Stats = Gamma2_Summary, Plots = Gamma2_Boxplots)
rm (Gamma2_Summary,Gamma2_Boxplots)

Summary_Bands = list (Delta = Delta_Info,
                      Theta = Theta_Info,
                      Alpha = Alpha_Info,
                      Beta = Beta_Info,
                      Gamma1 = Gamma1_Info,
                      Gamma2 = Gamma2_Info)

rm (Delta_Info,Theta_Info,Alpha_Info,Beta_Info,Gamma1_Info,Gamma2_Info)

# Step 7: Normality assumptions: Shapiro-Wilk

Delta_normality <- Delta %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  shapiro_test(PLV)

Theta_normality <- Theta %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  shapiro_test(PLV)

Alpha_normality <- Alpha %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  shapiro_test(PLV)

Beta_normality <- Beta %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  shapiro_test(PLV)

Gamma1_normality <- Gamma1 %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  shapiro_test(PLV)

Gamma2_normality <- Gamma2 %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  shapiro_test(PLV)

Normality_Bands = list(Delta = Delta_normality,
                       Theta = Theta_normality,
                       Alpha = Alpha_normality,
                       Beta = Beta_normality,
                       Gamma1 = Gamma1_normality,
                       Gamma2 = Gamma2_normality)

rm(Delta_normality,Theta_normality,Alpha_normality,Beta_normality,Gamma1_normality,Gamma2_normality)

# Step 8: QQ plots and Density plots

Delta_QQ <- ggqqplot(Delta, "PLV", ggtheme = theme_bw(), 
            title= "Delta: QQ plot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal") +
            facet_grid(Hemisphere ~ Modality + Motor_Region, labeller = "label_both")

Theta_QQ <- ggqqplot(Theta, "PLV", ggtheme = theme_bw(), 
            title= "Theta: QQ plot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal") +
            facet_grid(Hemisphere ~ Modality + Motor_Region, labeller = "label_both")

Alpha_QQ <- ggqqplot(Alpha, "PLV", ggtheme = theme_bw(), 
            title= "Alpha: QQ plot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal") +
            facet_grid(Hemisphere ~ Modality + Motor_Region, labeller = "label_both")

Beta_QQ <-  ggqqplot(Beta, "PLV", ggtheme = theme_bw(), 
            title= "Beta: QQ plot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal") +
            facet_grid(Hemisphere ~ Modality + Motor_Region, labeller = "label_both")

Gamma1_QQ <- ggqqplot(Gamma1, "PLV", ggtheme = theme_bw(), 
            title= "Gamma1: QQ plot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal") +
            facet_grid(Hemisphere ~ Modality + Motor_Region, labeller = "label_both")

Gamma2_QQ <- ggqqplot(Gamma2, "PLV", ggtheme = theme_bw(), 
            title= "Gamma2: QQ plot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal") +
            facet_grid(Hemisphere ~ Modality + Motor_Region, labeller = "label_both")

QQ_Bands = list(Delta = Delta_QQ,
                     Theta = Theta_QQ,
                     Alpha = Alpha_QQ,
                     Beta = Beta_QQ,
                     Gamma1 = Gamma1_QQ,
                     Gamma2 = Gamma2_QQ)

rm(Delta_QQ,Theta_QQ,Alpha_QQ,Beta_QQ,Gamma1_QQ,Gamma2_QQ)

Delta_density <- ggdensity(Delta$PLV, fill = "lightgray",title="Delta: density plot BEFORE outlier removal")
Theta_density <- ggdensity(Theta$PLV, fill = "lightgray",title="Theta: density plot BEFORE outlier removal")
Alpha_density <- ggdensity(Alpha$PLV, fill = "lightgray",title="Alpha: density plot BEFORE outlier removal")
Beta_density <- ggdensity(Beta$PLV, fill = "lightgray",title="Beta: density plot BEFORE outlier removal")
Gamma1_density <- ggdensity(Gamma1$PLV, fill = "lightgray",title="Gamam1:: density plot BEFORE outlier removal")
Gamma2_density <- ggdensity(Gamma2$PLV, fill = "lightgray",title="Gamma2: density plot BEFORE outlier removal")

Density_Bands = list(Delta = Delta_density,
                   Theta = Theta_density,
                   Alpha = Alpha_density,
                   Beta = Beta_density,
                   Gamma1 = Gamma1_density,
                   Gamma2 = Gamma2_density)

rm(Delta_density,Theta_density,Alpha_density,Beta_density,Gamma1_density,Gamma2_density)

# Step 8: Homogeneity

Delta_homogeneity = Delta %>%
  group_by(Hemisphere, Modality, Motor_Region) %>%
  levene_test(PLV ~ Musicianship)

Theta_homogeneity = Theta %>%
  group_by(Hemisphere, Modality, Motor_Region) %>%
  levene_test(PLV ~ Musicianship)

Alpha_homogeneity = Alpha %>%
  group_by(Hemisphere, Modality, Motor_Region) %>%
  levene_test(PLV ~ Musicianship)

Beta_homogeneity = Beta %>%
  group_by(Hemisphere, Modality, Motor_Region) %>%
  levene_test(PLV ~ Musicianship)

Gamma1_homogeneity = Gamma1 %>%
  group_by(Hemisphere, Modality, Motor_Region) %>%
  levene_test(PLV ~ Musicianship)

Gamma2_homogeneity = Gamma2 %>%
  group_by(Hemisphere, Modality, Motor_Region) %>%
  levene_test(PLV ~ Musicianship)

Homogeneity_Bands = list(Delta = Delta_homogeneity,
                         Theta = Theta_homogeneity,
                         Alpha = Alpha_homogeneity,
                         Beta = Beta_homogeneity,
                         Gamma1 = Gamma1_homogeneity,
                         Gamma2 = Gamma2_homogeneity)

rm(Delta_homogeneity,Theta_homogeneity,Alpha_homogeneity,Beta_homogeneity,Gamma1_homogeneity,Gamma2_homogeneity)


