## NOTE: This example will use Oscar's data! 

########################################
## STEP 1: Extract the AM and VM columns 
########################################

## Let us begin by pre-allocating some variables and computing some initial Vectors for the Left hemisphere

AM_VM_LEFT = list()
AM_VM_RIGHT = list()
AM_VM = list () 

for (i in 1:length(SubjectNames)){
   
Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$LEFT$delta[4:6,c(1,3)]"))))
AM_VM_L_delta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$LEFT$theta[4:6,c(1,3)]"))))
AM_VM_L_theta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$LEFT$alpha[4:6,c(1,3)]"))))
AM_VM_L_alpha <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$LEFT$beta[4:6,c(1,3)]"))))
AM_VM_L_beta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$LEFT$gamma1[4:6,c(1,3)]"))))
AM_VM_L_gamma1 <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$LEFT$gamma2[4:6,c(1,3)]"))))
AM_VM_L_gamma2 <- data.frame (Vector)
rm(Vector)

## We do the same for the right hemisphere

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$RIGHT$delta[4:6,c(1,3)]"))))
AM_VM_R_delta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$RIGHT$theta[4:6,c(1,3)]"))))
AM_VM_R_theta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$RIGHT$alpha[4:6,c(1,3)]"))))
AM_VM_R_alpha <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$RIGHT$beta[4:6,c(1,3)]"))))
AM_VM_R_beta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$RIGHT$gamma1[4:6,c(1,3)]"))))
AM_VM_R_gamma1 <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$RIGHT$gamma2[4:6,c(1,3)]"))))
AM_VM_R_gamma2 <- data.frame (Vector)
rm(Vector)

## We now add ALL of it into a list

AM_VM_LEFT[[i]] <- list(delta = AM_VM_L_delta,
                           theta = AM_VM_L_theta,
                           alpha = AM_VM_L_alpha,
                           beta = AM_VM_L_beta,
                           gamma1 = AM_VM_L_gamma1,
                           gamma2 = AM_VM_L_gamma2)

rm (AM_VM_L_alpha,AM_VM_L_beta,AM_VM_L_delta,AM_VM_L_gamma1,AM_VM_L_gamma2,AM_VM_L_theta)

AM_VM_RIGHT[[i]] <- list(delta = AM_VM_R_delta,
                           theta = AM_VM_R_theta,
                           alpha = AM_VM_R_alpha,
                           beta = AM_VM_R_beta,
                           gamma1 = AM_VM_R_gamma1,
                           gamma2 = AM_VM_R_gamma2)

rm (AM_VM_R_alpha,AM_VM_R_beta,AM_VM_R_delta,AM_VM_R_gamma1,AM_VM_R_gamma2,AM_VM_R_theta)

AM_VM[[i]] <- list(LEFT = AM_VM_LEFT[[i]],
                      RIGHT = AM_VM_RIGHT[[i]])

}

rm (AM_VM_LEFT)
rm (AM_VM_RIGHT)
rm (i)

names(AM_VM) <- SubjectNames

########################################
## STEP 2.1: We isolate the A1-M1 values
########################################

# First we will create a list that duplicates each element in SubjectNames

SubjectNames_Double = list()

for (i in 1:length(SubjectNames)){
SubjectNames_Double[[i]] <- (rep(SubjectNames[i], 2))
}

# We need to flatten the resulting nested list into a single-layer list:

SubjectNames_Double <- lapply(rapply(SubjectNames_Double, enquote, how="unlist"), eval)

# Now we need to create a list containing as many pairs of "L" & "R" as Subjects

Hemispheres <- list("L","R")
Hemispheres <- (rep(Hemispheres, length(SubjectNames)))

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the A1-M1 values from AM_VM and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
   Delta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$delta[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$delta[1,1]"))
   Theta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$theta[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$theta[1,1]"))
   Alpha_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$alpha[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$alpha[1,1]"))
   Beta_Values[[i]] =   list(paste0("AM_VM$",SubjectNames[i],"$LEFT$beta[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$beta[1,1]"))  
   Gamma1_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma1[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma1[1,1]"))
   Gamma2_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma2[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma2[1,1]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
   Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
   Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
   Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
   Beta_Values [[i]] <- (eval(parse(text=Beta_Values[[i]])))
   Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
   Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PLV values per freq band

A1_V1_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
A1_V1_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
A1_V1_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
A1_V1_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
A1_V1_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
A1_V1_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm(Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all A1_M1 values

A1_M1_Bands <- list(delta = A1_V1_Delta,
                    theta = A1_V1_Theta,
                    alpha = A1_V1_Alpha,
                    beta = A1_V1_Beta,
                    gamma1 = A1_V1_Gamma1,
                    gamma2 = A1_V1_Gamma2)

# We delete the last miscellaneous variables

rm(A1_V1_Delta,A1_V1_Theta,A1_V1_Alpha,A1_V1_Beta,A1_V1_Gamma1,A1_V1_Gamma2)

##########################################
## STEP 2.2: We isolate the A1-vPMC values
##########################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the A1-vPMC values from AM_VM and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
   Delta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$delta[2,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$delta[2,1]"))
   Theta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$theta[2,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$theta[2,1]"))
   Alpha_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$alpha[2,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$alpha[2,1]"))
   Beta_Values[[i]] =   list(paste0("AM_VM$",SubjectNames[i],"$LEFT$beta[2,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$beta[2,1]"))  
   Gamma1_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma1[2,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma1[2,1]"))
   Gamma2_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma2[2,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma2[2,1]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
   Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
   Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
   Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
   Beta_Values[[i]] <- (eval(parse(text=Beta_Values[[i]])))
   Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
   Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PLV values per freq band

A1_vPMC_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
A1_vPMC_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
A1_vPMC_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
A1_vPMC_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
A1_vPMC_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
A1_vPMC_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm (Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all A1_vPMC values

A1_vPMC_Bands <- list(delta = A1_vPMC_Delta,
                        theta = A1_vPMC_Theta,
                        alpha = A1_vPMC_Alpha,
                        beta = A1_vPMC_Beta,
                        gamma1 = A1_vPMC_Gamma1,
                        gamma2 = A1_vPMC_Gamma2)

# We delete the last miscellaneous variables

rm(A1_vPMC_Delta,A1_vPMC_Theta,A1_vPMC_Alpha,A1_vPMC_Beta,A1_vPMC_Gamma1,A1_vPMC_Gamma2)

##########################################
## STEP 2.3: We isolate the A1-dPMC values
##########################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the A1-dPMC values from AM_VM and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
   Delta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$delta[3,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$delta[3,1]"))
   Theta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$theta[3,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$theta[3,1]"))
   Alpha_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$alpha[3,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$alpha[3,1]"))
   Beta_Values[[i]] =   list(paste0("AM_VM$",SubjectNames[i],"$LEFT$beta[3,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$beta[3,1]"))  
   Gamma1_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma1[3,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma1[3,1]"))
   Gamma2_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma2[3,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma2[3,1]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
   Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
   Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
   Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
   Beta_Values[[i]] <- (eval(parse(text=Beta_Values[[i]])))
   Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
   Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PLV values per freq band

A1_dPMC_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
A1_dPMC_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
A1_dPMC_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
A1_dPMC_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
A1_dPMC_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
A1_dPMC_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm(Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all A1_dPMC values

A1_dPMC_Bands <- list(delta = A1_dPMC_Delta,
                          theta = A1_dPMC_Theta,
                          alpha = A1_dPMC_Alpha,
                          beta = A1_dPMC_Beta,
                          gamma1 = A1_dPMC_Gamma1,
                          gamma2 = A1_dPMC_Gamma2)

# We delete the last miscellaneous variables

rm(A1_dPMC_Delta,A1_dPMC_Theta,A1_dPMC_Alpha,A1_dPMC_Beta,A1_dPMC_Gamma1,A1_dPMC_Gamma2)

########################################
## STEP 3.1: We isolate the V1-M1 values
########################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the V1-M1 values from AM_VM and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
   Delta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$delta[1,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$delta[1,2]"))
   Theta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$theta[1,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$theta[1,2]"))
   Alpha_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$alpha[1,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$alpha[1,2]"))
   Beta_Values[[i]] =   list(paste0("AM_VM$",SubjectNames[i],"$LEFT$beta[1,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$beta[1,2]"))  
   Gamma1_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma1[1,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma1[1,2]"))
   Gamma2_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma2[1,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma2[1,2]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
   Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
   Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
   Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
   Beta_Values [[i]] <- (eval(parse(text=Beta_Values[[i]])))
   Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
   Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PLV values per freq band

V1_M1_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
V1_M1_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
V1_M1_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
V1_M1_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
V1_M1_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
V1_M1_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm(Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all A1_M1 values

V1_M1_Bands <- list(delta = V1_M1_Delta,
                    theta = V1_M1_Theta,
                    alpha = V1_M1_Alpha,
                    beta = V1_M1_Beta,
                    gamma1 = V1_M1_Gamma1,
                    gamma2 = V1_M1_Gamma2)

# We delete the last miscellaneous variables

rm(V1_M1_Delta,V1_M1_Theta,V1_M1_Alpha,V1_M1_Beta,V1_M1_Gamma1,V1_M1_Gamma2)

##########################################
## STEP 3.2: We isolate the V1-vPMC values
##########################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the V1-vPMC values from AM_VM and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
   Delta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$delta[2,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$delta[2,2]"))
   Theta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$theta[2,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$theta[2,2]"))
   Alpha_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$alpha[2,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$alpha[2,2]"))
   Beta_Values[[i]] =   list(paste0("AM_VM$",SubjectNames[i],"$LEFT$beta[2,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$beta[2,2]"))  
   Gamma1_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma1[2,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma1[2,2]"))
   Gamma2_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma2[2,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma2[2,2]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
   Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
   Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
   Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
   Beta_Values[[i]] <- (eval(parse(text=Beta_Values[[i]])))
   Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
   Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PLV values per freq band

V1_vPMC_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
V1_vPMC_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
V1_vPMC_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
V1_vPMC_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
V1_vPMC_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
V1_vPMC_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm (Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all A1_vPMC values

V1_vPMC_Bands <- list(delta = V1_vPMC_Delta,
                      theta = V1_vPMC_Theta,
                      alpha = V1_vPMC_Alpha,
                      beta = V1_vPMC_Beta,
                      gamma1 = V1_vPMC_Gamma1,
                      gamma2 = V1_vPMC_Gamma2)

# We delete the last miscellaneous variables

rm(V1_vPMC_Delta,V1_vPMC_Theta,V1_vPMC_Alpha,V1_vPMC_Beta,V1_vPMC_Gamma1,V1_vPMC_Gamma2)

##########################################
## STEP 3.3: We isolate the V1-dPMC values
##########################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the A1-dPMC values from AM_VM and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
   Delta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$delta[3,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$delta[3,2]"))
   Theta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$theta[3,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$theta[3,2]"))
   Alpha_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$alpha[3,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$alpha[3,2]"))
   Beta_Values[[i]] =   list(paste0("AM_VM$",SubjectNames[i],"$LEFT$beta[3,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$beta[3,2]"))  
   Gamma1_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma1[3,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma1[3,2]"))
   Gamma2_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma2[3,2]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma2[3,2]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
   Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
   Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
   Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
   Beta_Values[[i]] <- (eval(parse(text=Beta_Values[[i]])))
   Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
   Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PLV values per freq band

V1_dPMC_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
V1_dPMC_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
V1_dPMC_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
V1_dPMC_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
V1_dPMC_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
V1_dPMC_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm(Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all V1_dPMC values

V1_dPMC_Bands <- list(delta = V1_dPMC_Delta,
                      theta = V1_dPMC_Theta,
                      alpha = V1_dPMC_Alpha,
                      beta = V1_dPMC_Beta,
                      gamma1 = V1_dPMC_Gamma1,
                      gamma2 = V1_dPMC_Gamma2)

# We delete the last miscellaneous variables

rm(V1_dPMC_Delta,V1_dPMC_Theta,V1_dPMC_Alpha,V1_dPMC_Beta,V1_dPMC_Gamma1,V1_dPMC_Gamma2)

#############################################
## STEP 4: Create the definitive ANOVA tables
#############################################

ANOVA_Delta <- data.frame(A1_M1_Bands$delta,A1_vPMC_Bands$delta,A1_dPMC_Bands$delta,V1_M1_Bands$delta,V1_vPMC_Bands$delta,V1_dPMC_Bands$delta)
ANOVA_Delta <- ANOVA_Delta[,c(1,2,3,6,9,12,15,18)] 
colnames(ANOVA_Delta) <- c("ID","Hemisphere","A1-M1","A1-vPMC","A1-dPMC","V1-M1","V1-vPMC","V1-dPMC")

ANOVA_Theta <- data.frame(A1_M1_Bands$theta,A1_vPMC_Bands$theta,A1_dPMC_Bands$theta,V1_M1_Bands$theta,V1_vPMC_Bands$theta,V1_dPMC_Bands$theta)
ANOVA_Theta <- ANOVA_Theta[,c(1,2,3,6,9,12,15,18)]  
colnames(ANOVA_Theta) <- c("ID","Hemisphere","A1-M1","A1-vPMC","A1-dPMC","V1-M1","V1-vPMC","V1-dPMC")

ANOVA_Alpha <- data.frame(A1_M1_Bands$alpha,A1_vPMC_Bands$alpha,A1_dPMC_Bands$alpha,V1_M1_Bands$alpha,V1_vPMC_Bands$alpha,V1_dPMC_Bands$alpha)
ANOVA_Alpha <- ANOVA_Alpha[,c(1,2,3,6,9,12,15,18)] 
colnames(ANOVA_Alpha) <- c("ID","Hemisphere","A1-M1","A1-vPMC","A1-dPMC","V1-M1","V1-vPMC","V1-dPMC")

ANOVA_Beta <- data.frame(A1_M1_Bands$beta,A1_vPMC_Bands$beta,A1_dPMC_Bands$beta,V1_M1_Bands$beta,V1_vPMC_Bands$beta,V1_dPMC_Bands$beta)
ANOVA_Beta <- ANOVA_Beta[,c(1,2,3,6,9,12,15,18)] 
colnames(ANOVA_Beta) <- c("ID","Hemisphere","A1-M1","A1-vPMC","A1-dPMC","V1-M1","V1-vPMC","V1-dPMC")

ANOVA_Gamma1 <- data.frame(A1_M1_Bands$gamma1,A1_vPMC_Bands$gamma1,A1_dPMC_Bands$gamma1,V1_M1_Bands$gamma1,V1_vPMC_Bands$gamma1,V1_dPMC_Bands$gamma1)
ANOVA_Gamma1 <- ANOVA_Gamma1[,c(1,2,3,6,9,12,15,18)] 
colnames(ANOVA_Gamma1) <- c("ID","Hemisphere","A1-M1","A1-vPMC","A1-dPMC","V1-M1","V1-vPMC","V1-dPMC")

ANOVA_Gamma2 <- data.frame(A1_M1_Bands$gamma2,A1_vPMC_Bands$gamma2,A1_dPMC_Bands$gamma2,V1_M1_Bands$gamma2,V1_vPMC_Bands$gamma2,V1_dPMC_Bands$gamma2)
ANOVA_Gamma2 <- ANOVA_Gamma2[,c(1,2,3,6,9,12,15,18)] 
colnames(ANOVA_Gamma2) <- c("ID","Hemisphere","A1-M1","A1-vPMC","A1-dPMC","V1-M1","V1-vPMC","V1-dPMC")

ANOVA_BANDS <- list(delta = ANOVA_Delta,
                    theta = ANOVA_Theta,
                    alpha = ANOVA_Alpha,
                    beta = ANOVA_Beta,
                    gamma1 = ANOVA_Gamma1,
                    gamma2 = ANOVA_Gamma2)

rm(ANOVA_Delta,
   ANOVA_Theta, 
   ANOVA_Alpha,
   ANOVA_Beta,
   ANOVA_Gamma1,
   ANOVA_Gamma2)

Musicianship <- list("non-musician",
                      "non-musician",
                      "non-musician",
                      "non-musician",
                      "non-musician",
                      "musician",
                      "non-musician",
                      "musician",
                      "musician",
                      "non-musician",
                      "non-musician",
                      "non-musician",
                      "non-musician",
                      "non-musician",
                      "musician",
                      "non-musician",
                      "musician",
                      "non-musician",
                      "musician",
                      "non-musician",
                      "non-musician",
                      "musician",
                      "non-musician",
                      "musician",
                      "musician",
                      "non-musician",
                      "musician",
                      "non-musician",
                      "musician",
                      "non-musician",
                      "musician",
                      "non-musician",
                      "non-musician",
                      "non-musician",
                      "musician",
                      "musician",
                      "non-musician",
                      "musician",
                      "non-musician",
                      "musician",
                      "non-musician",
                      "non-musician",
                      "musician",
                      "musician",
                      "musician",
                      "musician",
                      "musician",
                      "musician",
                      "non-musician",
                      "non-musician",
                      "musician",
                      "musician",
                      "non-musician",
                      "non-musician",
                      "non-musician",
                      "non-musician",
                      "musician",
                      "non-musician",
                      "non-musician",
                      "musician",
                      "non-musician",
                      "musician",
                      "musician",
                      "non-musician",
                      "musician")

Musicianship_Double = list()

for (i in 1:length(SubjectNames)){
   Musicianship_Double[[i]] <- (rep(Musicianship[i], 2))
}

Musicianship_Double <- lapply(rapply(Musicianship_Double, enquote, how="unlist"), eval)

ANOVA_BANDS$delta$Musicianship <- Musicianship_Double
ANOVA_BANDS$theta$Musicianship <- Musicianship_Double
ANOVA_BANDS$alpha$Musicianship <- Musicianship_Double
ANOVA_BANDS$beta$Musicianship <- Musicianship_Double
ANOVA_BANDS$gamma1$Musicianship <- Musicianship_Double
ANOVA_BANDS$gamma2$Musicianship <- Musicianship_Double

rm(Musicianship, Musicianship_Double,i)
