library(emmeans)
library(glmmTMB)
library(rstatix)

###############
# STEP 1: DELTA
###############

# Full model

GLMM_Delta= glmmTMB(PLV~Musicianship*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                    data = Delta,
                    family = beta_family(link = "logit"))

# Repeated measures model

GLMM_Delta_2= glmmTMB(PLV~Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                      data = Delta,
                      family = beta_family(link = "logit"))

# Create grid

ref <- emmeans(GLMM_Delta,specs = c("Hemisphere", "Modality", "Motor_Region"))

# Compute omnibus test (main effects and interactions)

Omnibus_GLMM_Delta    = joint_tests(GLMM_Delta)
Omnibus_GLMM_Delta_2  = joint_tests(GLMM_Delta_2)
Omnibus_GLMM_Delta_2$p.value = round(Omnibus_GLMM_Delta_2$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

GLMM1_Delta_pairs_HM   =   pairs(emmeans(GLMM_Delta_2,~ Modality|Hemisphere), adjust="bonferroni")
summary_Delta_GLMM1_HM =   summary(GLMM1_Delta_pairs_HM)

GLMM1_Delta_pairs_HMr   =    pairs(emmeans(GLMM_Delta_2,~ Motor_Region|Hemisphere), adjust="bonferroni")
summary_Delta_GLMM1_HMr =    summary(GLMM1_Delta_pairs_HMr)
                           
GLMM1_Delta_pairs_MMr   =  pairs(emmeans(GLMM_Delta_2,~ Modality|Motor_Region), adjust="bonferroni")
summary_Delta_GLMM1_MMr =  summary(GLMM1_Delta_pairs_MMr)

GLMM1_Delta_pairs_MrM   =  pairs(emmeans(GLMM_Delta_2,~ Motor_Region|Modality), adjust="bonferroni")
summary_Delta_GLMM1_MrM =  summary(GLMM1_Delta_pairs_MrM)

GLMM1_Delta_pairs_asterix     = pairs(emmeans(GLMM_Delta_2,~ Modality*Motor_Region), adjust="bonferroni")
summary_Delta_GLMM1_asterix =  summary(GLMM1_Delta_pairs_asterix)      

# Correcting p values

GLMM1_HM_Result   =  adjust_pvalue(summary_Delta_GLMM1_HM, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_HMr_Result  =  adjust_pvalue(summary_Delta_GLMM1_HMr, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_MMr_Result  =  adjust_pvalue(summary_Delta_GLMM1_MMr, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_MrM_Result  =  adjust_pvalue(summary_Delta_GLMM1_MrM, "p.value", "bonferroni", method = "bonferroni")
GLMM1_X_Result  =  adjust_pvalue(summary_Delta_GLMM1_asterix, "p.value", "bonferroni", method = "bonferroni")

GLMM1_HM_Result$p.value    = round(GLMM1_HM_Result$p.value,digits=3)
GLMM1_HM_Result$bonferroni = round(GLMM1_HM_Result$bonferroni,digits=3)

GLMM1_HMr_Result$p.value    = round(GLMM1_HMr_Result$p.value,digits=3)
GLMM1_HMr_Result$bonferroni = round(GLMM1_HMr_Result$bonferroni,digits=3)

GLMM1_MMr_Result$p.value    = round(GLMM1_MMr_Result$p.value,digits=3)
GLMM1_MMr_Result$bonferroni = round(GLMM1_MMr_Result$bonferroni,digits=3)

GLMM1_MrM_Result$p.value    = round(GLMM1_MrM_Result$p.value,digits=3)
GLMM1_MrM_Result$bonferroni = round(GLMM1_MrM_Result$bonferroni,digits=3)

GLMM1_X_Result$p.value    = round(GLMM1_X_Result$p.value,digits=3)
GLMM1_X_Result$bonferroni = round(GLMM1_X_Result$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM1_Delta = list(Omnibus = Omnibus_GLMM_Delta_2,
                   Mod_given_Hem = GLMM1_HM_Result,
                   MR_given_Hem = GLMM1_HMr_Result,
                   Mod_given_MR = GLMM1_MMr_Result,
                   MR_given_Mod = GLMM1_MrM_Result,
                   Mod_by_MR = GLMM1_X_Result)

rm(GLMM_Delta_2,Omnibus_GLMM_Delta_2,GLMM1_Delta_pairs_HM,
   summary_Delta_GLMM1_HM,GLMM1_Delta_pairs_MMr,summary_Delta_GLMM1_MMr,
   GLMM1_HM_Result,GLMM1_MMr_Result,GLMM1_Delta_pairs_TRI,summary_Delta_GLMM1_TRI,
   GLMM1_TRI_Result)

# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

###############
# STEP 2: THETA
###############

# Full model

GLMM_Theta= glmmTMB(PLV~Musicianship*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                    data = Theta,
                    family = beta_family(link = "logit")
                    )

# Repeated measures model

GLMM_Theta_2 = glmmTMB(PLV~Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                      data = Theta,
                      family = beta_family(link = "logit")
                      )

# Create grid

ref <- emmeans(GLMM_Theta_2,specs = c("Hemisphere", "Modality", "Motor_Region"))

# Compute omnibus test (main effects and interactions)

Omnibus_GLMM_Theta   = joint_tests(GLMM_Theta)
Omnibus_GLMM_Theta_2 = joint_tests(GLMM_Theta_2)
Omnibus_GLMM_Theta_2$p.value = round(Omnibus_GLMM_Theta_2$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

GLMM1_Theta_pairs_HMr   =   pairs(emmeans(GLMM_Theta_2,~ Motor_Region|Hemisphere), adjust="bonferroni")
summary_GLMM1_Theta_HMr =   summary(GLMM1_Theta_pairs_HMr)

GLMM1_Theta_pairs_MMr   =  pairs(emmeans(GLMM_Theta_2,~ Modality|Motor_Region), adjust="bonferroni")
summary_GLMM1_Theta_MMr =  summary(GLMM1_Theta_pairs_MMr)

GLMM1_Theta_pairs_MrM   =  pairs(emmeans(GLMM_Theta_2,~ Motor_Region|Modality), adjust="bonferroni")
summary_Theta_GLMM1_MrM =  summary(GLMM1_Theta_pairs_MrM)

GLMM1_Theta_pairs_asterix     = pairs(emmeans(GLMM_Theta_2,~ Modality*Motor_Region), adjust="bonferroni")
summary_Theta_GLMM1_asterix =  summary(GLMM1_Theta_pairs_asterix)      

# Correcting p values

GLMM1_HMr_Result   =  adjust_pvalue(summary_GLMM1_Theta_HMr, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_MMr_Result  =  adjust_pvalue(summary_GLMM1_Theta_MMr, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_MrM_Result  =  adjust_pvalue(summary_Theta_GLMM1_MrM, "p.value", "bonferroni", method = "bonferroni")
GLMM1_X_Result  =  adjust_pvalue(summary_Theta_GLMM1_asterix, "p.value", "bonferroni", method = "bonferroni")

GLMM1_HMr_Result$p.value    = round(GLMM1_HMr_Result$p.value,digits=3)
GLMM1_HMr_Result$bonferroni = round(GLMM1_HMr_Result$bonferroni,digits=3)

GLMM1_MMr_Result$p.value    = round(GLMM1_MMr_Result$p.value,digits=3)
GLMM1_MMr_Result$bonferroni = round(GLMM1_MMr_Result$bonferroni,digits=3)

GLMM1_MrM_Result$p.value    = round(GLMM1_MrM_Result$p.value,digits=3)
GLMM1_MrM_Result$bonferroni = round(GLMM1_MrM_Result$bonferroni,digits=3)

GLMM1_X_Result$p.value    = round(GLMM1_X_Result$p.value,digits=3)
GLMM1_X_Result$bonferroni = round(GLMM1_X_Result$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM1_Theta = list(Omnibus = Omnibus_GLMM_Theta_2,
                   MR_given_Hem = GLMM1_HMr_Result,
                   Mod_given_MR = GLMM1_MMr_Result,
                   MR_given_Mod = GLMM1_MrM_Result,
                   Mod_by_MR = GLMM1_X_Result)

rm(GLMM_Theta_2,Omnibus_GLMM_Theta_2,GLMM1_Theta_pairs_HMr,
   summary_GLMM1_Theta_HMr,GLMM1_Theta_pairs_MMr,summary_GLMM1_Theta_MMr,
   GLMM1_HMr_Result,GLMM1_MMr_Result, summary_Theta_GLMM1_TRI,GLMM1_Theta_pairs_TRI,GLMM1_TRI_Result)

# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

###############
# STEP 3: Alpha
###############

# Full model

GLMM_Alpha= glmmTMB(PLV~Musicianship*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
  data = Alpha,
  family = beta_family(link = "logit"))

# Repeated measures model

GLMM_Alpha_2= glmmTMB(PLV~Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
  data = Alpha,
  family = beta_family(link = "logit")
  )

# Create grid

ref <- emmeans(GLMM_Alpha_2,specs = c("Hemisphere", "Modality", "Motor_Region"))

# Compute omnibus test (main effects and interactions)

Omnibus_GLMM_Alpha = joint_tests(GLMM_Alpha)
Omnibus_GLMM_Alpha_2 = joint_tests(GLMM_Alpha_2)
Omnibus_GLMM_Alpha_2$p.value = round(Omnibus_GLMM_Alpha_2$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

GLMM1_Alpha_pairs_BI          =  pairs(emmeans(GLMM_Alpha_2,~ Modality|Motor_Region), adjust="bonferroni")
summary_Alpha_GLMM1_BI        =  summary(GLMM1_Alpha_pairs_BI)

GLMM1_Alpha_pairs_MrM         =   pairs(emmeans(GLMM_Alpha_2,~ Motor_Region|Modality), adjust="bonferroni")
summary_Alpha_GLMM1_MrM        =   summary(GLMM1_Alpha_pairs_MrM)

GLMM1_Alpha_pairs_asterix         =   pairs(emmeans(GLMM_Alpha_2,~ Modality*Motor_Region), adjust="bonferroni")
summary_Alpha_GLMM1_asterix        =   summary(GLMM1_Alpha_pairs_asterix)

GLMM1_Alpha_pairs_TRI         =  pairs(emmeans(GLMM_Alpha_2,~ Modality*Motor_Region|Hemisphere), adjust="bonferroni")
summary_Alpha_GLMM1_TRI       =  summary(GLMM1_Alpha_pairs_TRI)

# Correcting p values

GLMM1_MMr_Result   =  adjust_pvalue(summary_Alpha_GLMM1_BI, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_MrM_Result   =  adjust_pvalue(summary_Alpha_GLMM1_MrM, "p.value", "bonferroni", method = "bonferroni")
GLMM1_X_Result    =  adjust_pvalue(summary_Alpha_GLMM1_asterix, "p.value", "bonferroni", method = "bonferroni")
GLMM1_TRI_Result  =  adjust_pvalue(summary_Alpha_GLMM1_TRI, "p.value", "bonferroni", method = "bonferroni")

GLMM1_MMr_Result$p.value    = round(GLMM1_BI_Result$p.value,digits=3)
GLMM1_MMr_Result$bonferroni = round(GLMM1_BI_Result$bonferroni,digits=3)

GLMM1_MrM_Result$p.value    = round(GLMM1_MrM_Result$p.value,digits=3)
GLMM1_MrM_Result$bonferroni = round(GLMM1_MrM_Result$bonferroni,digits=3)

GLMM1_X_Result$p.value    = round(GLMM1_X_Result$p.value,digits=3)
GLMM1_X_Result$bonferroni = round(GLMM1_X_Result$bonferroni,digits=3)

GLMM1_TRI_Result$p.value    = round(GLMM1_TRI_Result$p.value,digits=3)
GLMM1_TRI_Result$bonferroni = round(GLMM1_TRI_Result$bonferroni,digits=3)


# Add everything into one big list and remove extraneous variables

GLMM1_Alpha = list(Omnibus = Omnibus_GLMM_Alpha_2,
                   Mod_given_MR = GLMM1_BI_Result,
                   MR_given_Mod = GLMM1_MrM_Result,
                   Mod_by_MR = GLMM1_X_Result,
                   Mod_by_MR_given_Hem = GLMM1_TRI_Result)

rm(GLMM_Alpha_2,Omnibus_GLMM_Alpha_2,GLMM1_Alpha_pairs_BI,
   summary_Alpha_GLMM1_BI,GLMM1_Alpha_pairs_TRI,summary_Alpha_GLMM1_TRI,
   GLMM1_BI_Result,GLMM1_TRI_Result)

# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

##############
# STEP 4: Beta
##############

# Full model

GLMM_Beta= glmmTMB(PLV~Musicianship*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                    data = Beta,
                    family = beta_family(link = "logit"))

# Repeated measures model

GLMM_Beta_2= glmmTMB(PLV~Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                      data = Beta,
                      family = beta_family(link = "logit")
                      )

# Create grid

ref <- emmeans(GLMM_Beta_2,specs = c("Hemisphere", "Modality", "Motor_Region"))

# Compute omnibus test (main effects and interactions)

Omnibus_GLMM_Beta = joint_tests(GLMM_Beta)
Omnibus_GLMM_Beta_2 = joint_tests(GLMM_Beta_2) 
Omnibus_GLMM_Beta_2$p.value = round(Omnibus_GLMM_Beta_2$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

GLMM1_Beta_pairs_MMr     =   pairs(emmeans(GLMM_Beta_2,~ Modality*Motor_Region), adjust="bonferroni")
summary_GLMM1_Beta_MMr   =   summary(GLMM1_Beta_pairs_MMr)

# Correcting p values

GLMM1_MMr_Result   =  adjust_pvalue(summary_GLMM1_Beta_MMr, "p.value", "bonferroni", method = "bonferroni") 

GLMM1_MMr_Result$p.value    = round(GLMM1_MMr_Result$p.value,digits=3)
GLMM1_MMr_Result$bonferroni = round(GLMM1_MMr_Result$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM1_Beta = list(Omnibus = Omnibus_GLMM_Beta_2,
                   Mod_by_MR = GLMM1_MMr_Result)

rm(GLMM_Beta_2,Omnibus_GLMM_Beta_2,GLMM1_Beta_pairs_MMr,
   summary_GLMM1_Beta_MMr,GLMM1_MMr_Result)

# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

################
# STEP 5: Gamma1
################

# Full model

GLMM_Gamma1= glmmTMB(PLV~Musicianship*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                    data = Gamma1,
                    family = beta_family(link = "logit"))

# Repeated measures model

GLMM_Gamma1_2= glmmTMB(PLV~Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                      data = Gamma1,
                      family = beta_family(link = "logit")
                      )

# Create grid

ref <- emmeans(GLMM_Gamma1_2,specs = c("Hemisphere", "Modality", "Motor_Region"))

# Compute omnibus test (main effects and interactions)

(Omnibus_GLMM_Gamma1 = joint_tests(GLMM_Gamma1))
Omnibus_GLMM_Gamma1_2 = joint_tests(GLMM_Gamma1_2)
Omnibus_GLMM_Gamma1_2$p.value = round(Omnibus_GLMM_Gamma1_2$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

GLMM1_Gamma1_pairs_HM   =   pairs(emmeans(GLMM_Gamma1_2,~ Modality|Hemisphere), adjust="bonferroni")
summary_Gamma1_GLMM1_HM =   summary(GLMM1_Gamma1_pairs_HM)

GLMM1_Gamma1_pairs_MMr   =  pairs(emmeans(GLMM_Gamma1_2,~ Modality*Motor_Region), adjust="bonferroni")
summary_Gamma1_GLMM1_MMr =  summary(GLMM1_Gamma1_pairs_MMr)

GLMM1_Gamma1_pairs_TRI   =  pairs(emmeans(GLMM_Gamma1_2,~ Modality*Motor_Region|Hemisphere), adjust="bonferroni")
summary_Gamma1_GLMM1_TRI =  summary(GLMM1_Gamma1_pairs_TRI)

# Correcting p values

GLMM1_HM_Result   =  adjust_pvalue(summary_Gamma1_GLMM1_HM, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_MMr_Result  =  adjust_pvalue(summary_Gamma1_GLMM1_MMr, "p.value", "bonferroni", method = "bonferroni")
GLMM1_TRI_Result  =  adjust_pvalue(summary_Gamma1_GLMM1_TRI, "p.value", "bonferroni", method = "bonferroni")

GLMM1_HM_Result$p.value    = round(GLMM1_HM_Result$p.value,digits=3)
GLMM1_HM_Result$bonferroni = round(GLMM1_HM_Result$bonferroni,digits=3)

GLMM1_MMr_Result$p.value    = round(GLMM1_MMr_Result$p.value,digits=3)
GLMM1_MMr_Result$bonferroni = round(GLMM1_MMr_Result$bonferroni,digits=3)

GLMM1_TRI_Result$p.value    = round(GLMM1_TRI_Result$p.value,digits=3)
GLMM1_TRI_Result$bonferroni = round(GLMM1_TRI_Result$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM1_Gamma1 = list(Omnibus = Omnibus_GLMM_Gamma1_2,
                    Hem_given_Mod = GLMM1_HM_Result,
                    Mod_by_MR  = GLMM1_MMr_Result,
                    Mod_by_MR_given_Hem  = GLMM1_TRI_Result)

rm(GLMM_Gamma1_2,Omnibus_GLMM_Gamma1_2,GLMM1_Gamma1_pairs_HM,
   summary_Gamma1_GLMM1_HM,GLMM1_Gamma1_pairs_MMr,summary_Gamma1_GLMM1_MMr,
   GLMM1_HM_Result,GLMM1_MMr_Result, GLMM1_TRI_Result,summary_Gamma1_GLMM1_TRI,
   GLMM1_Gamma1_pairs_TRI)

# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

################
# STEP 6: GAMMA2
################

'GLMM_Gamma2= glmmTMB(PLV~Musicianship*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                     data = Gamma2,
                     family = beta_family(link = "logit"))'t
                     #control=glmmTMBControl(optCtrl=list(iter.max=1e3,eval.max=1e3)))

# Full model


GLMM_Gamma2_1 = glmmTMB(PLV~Musicianship*Hemisphere*Modality*Motor_Region+(1|ID),
                     data = Gamma2,
                     family = beta_family(link = "logit"))

# Repeated measures model

GLMM_Gamma2_2 = glmmTMB(PLV~Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                       data = Gamma2,
                       family = beta_family(link = "logit"))

# Create grid

ref <- emmeans(GLMM_Gamma2,specs = c("Hemisphere", "Modality", "Motor_Region"))

# Compute omnibus test (main effects and interactions)

(Omnibus_GLMM_Gamma2 = joint_tests(GLMM_Gamma2))
Omnibus_GLMM_Gamma2_2 = joint_tests(GLMM_Gamma2_2)
Omnibus_GLMM_Gamma2_2$p.value = round(Omnibus_GLMM_Gamma2_2$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

GLMM1_Gamma2_pairs_MMr   =  pairs(emmeans(GLMM_Gamma2_2,~ Modality*Motor_Region), adjust="bonferroni")
summary_Gamma2_GLMM1_MMr =  summary(GLMM1_Gamma2_pairs_MMr)

GLMM1_Gamma2_pairs_TRI   =  pairs(emmeans(GLMM_Gamma2_2,~ Modality*Motor_Region|Hemisphere), adjust="bonferroni")
summary_Gamma2_GLMM1_TRI =  summary(GLMM1_Gamma2_pairs_TRI)

# Correcting p values

GLMM1_MMr_Result  =  adjust_pvalue(summary_Gamma2_GLMM1_MMr, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_TRI_Result  =  adjust_pvalue(summary_Gamma2_GLMM1_TRI, "p.value", "bonferroni", method = "bonferroni")

GLMM1_MMr_Result$p.value    = round(GLMM1_MMr_Result$p.value,digits=3)
GLMM1_MMr_Result$bonferroni = round(GLMM1_MMr_Result$bonferroni,digits=3)

GLMM1_TRI_Result$p.value    = round(GLMM1_TRI_Result$p.value,digits=3)
GLMM1_TRI_Result$bonferroni = round(GLMM1_TRI_Result$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables
 
GLMM1_Gamma2 = list(Omnibus          = Omnibus_GLMM_Gamma2_2,
                    Mod_by_MR         = GLMM1_MMr_Result,
                    Mod_by_MR_given_Hem  = GLMM1_TRI_Result)

rm(GLMM_Gamma2,Omnibus_GLMM_Gamma2,GLMM1_Gamma2_pairs_HM,
   summary_Gamma2_GLMM1_HM,GLMM1_Gamma2_pairs_MMr,summary_Gamma2_GLMM1_MMr,
   GLMM1_HM_Result,GLMM1_MMr_Result, GLMM1_TRI_Result,summary_Gamma2_GLMM1_TRI,
   GLMM1_Gamma2_pairs_TRI)

# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

# Plot main effects and post-hocs 

#############
# Extra plots
#############

library(ggplot2)
library(ggpubr)

Delta_Summary1 <- Delta %>%
  group_by(Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Delta_Boxplot_Interaction1 <- ggbarplot(
  Delta_Summary1, x = "Modality", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Delta: Barplot of 'Hemisphere*Modality' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

Delta_Summary2 <- Delta %>%
  group_by(Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Delta_Boxplot_Interaction2 <- ggbarplot(
  Delta_Summary2, x = "Motor_Region", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Delta: Barplot of 'Modality*Motor_Region' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

# Theta

Theta_Summary1 <- Theta %>%
  group_by(Hemisphere,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Theta_Boxplot_Interaction1 <- ggbarplot(
  Theta_Summary1, x = "Motor_Region", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Theta: Barplot of 'Hemisphere*Motor_Region' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

Theta_Summary2 <- Theta %>%
  group_by(Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Theta_Boxplot_Interaction2 <- ggbarplot(
  Theta_Summary2, x = "Motor_Region", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Theta: Barplot of 'Modality*Motor_Region' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)
# Alpha

Alpha_Summary1 <- Alpha %>%
  group_by(Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Alpha_Boxplot_Interaction1 <- ggbarplot(
  Alpha_Summary1, x = "Motor_Region", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Alpha: Barplot of 'Modality*Motor_Region' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Beta

Beta_Summary1 <- Beta %>%
  group_by(Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Beta_Summary2 <- Beta %>%
  group_by(Hemisphere) %>%
  get_summary_stats(PLV, type = "mean_sd")

Beta_Boxplot2 <- ggbarplot(
  Beta_Summary2, x = "Hemisphere", y = "mean",
  title= "Beta: Barplot of 'Hemisphere' (main effect)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  color = "black",
  fill = "white",
  label = TRUE, lab.vjust = -0.4
)

Beta_Boxplot_Interaction <- ggbarplot(
  Beta_Summary1, x = "Motor_Region", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Beta: Barplot of 'Modality*Motor_Region' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Gamma1 

Gamma1_Summary1 <- Gamma1 %>%
  group_by(Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma1_Boxplot_Interaction1 <- ggbarplot(
  Gamma1_Summary1, x = "Modality", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Gamma1: Barplot of 'Hemisphere*Modality' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

Gamma1_Summary2 <- Gamma1 %>%
  group_by(Hemisphere,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma1_Boxplot_Interaction2 <- ggbarplot(
  Gamma1_Summary2, x = "Motor_Region", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Gamma1: Barplot of 'Hemisphere*Motor_Region' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

Gamma1_Summary3 <- Gamma1 %>%
  group_by(Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma1_Boxplot_Interaction3 <- ggbarplot(
  Gamma1_Summary3, x = "Motor_Region", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Gamma1: Barplot of 'Modality*Motor_Region' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Gamma2

Gamma2_Summary1 <- Gamma2 %>%
  group_by(Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma2_Boxplot_Interaction1 <- ggbarplot(
  Gamma2_Summary1, x = "Motor_Region", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Hemisphere*Motor_Region' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

Gamma2_Summary2 <- Gamma2 %>%
  group_by(Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma2_Boxplot_Interaction2 <- ggbarplot(
  Gamma2_Summary2, x = "Motor_Region", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Modality*Motor_Region' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Export everything into PDF

pdf("Delta_MIXED_stats_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

options(digits=5)

grid.arrange(nrow=1,top="Delta: 'Musicianship' summary", tableGrob(Summary_Bands$Delta$Stats$Musicianship))
grid.arrange(nrow=1,top="Delta: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Delta$Stats$Modality))

plot(Summary_Bands$Delta$Plots$Musicianship_BEFORE, main = "Delta band: Musicianship")
plot(Summary_Bands$Delta$Plots$MotorRegions_BEFORE, main = "Delta band: Motor Regions")

grid.arrange(nrow=1,top="Delta: Number of outliers removed out of 1080 PLVs", tableGrob(summary(Outliers_Bands$Delta$is.outlier)))

plot(Summary_Bands$Delta$Plots$Musicianship_AFTER, main = "Delta band: Musicianship")
plot(Summary_Bands$Delta$Plots$MotorRegions_AFTER, main = "Delta band: Motor Regions")

plot(QQ_Bands$Delta)

grid.arrange(nrow=1,top="Delta: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Delta))

plot(Density_Bands$Delta)

GLMM1_Delta$Omnibus$p.value <- round(GLMM1_Delta$Omnibus$p.value,3)
GLMM1_Delta$Hem_by_Mod$p.value <- round(GLMM1_Delta$Hem_by_Mod$p.value,3)
GLMM1_Delta$Hem_by_Mod$bonferroni <- round(GLMM1_Delta$Hem_by_Mod$bonferroni,3)
GLMM1_Delta$Hem_by_MR$p.value <- round(GLMM1_Delta$Hem_by_MR$p.value,3)
GLMM1_Delta$Hem_by_MR$bonferroni <- round(GLMM1_Delta$Hem_by_MR$bonferroni,3)
GLMM1_Delta$Mod_by_MR$p.value <- round(GLMM1_Delta$Mod_by_MR$p.value,3)
GLMM1_Delta$Mod_by_MR$bonferroni <- round(GLMM1_Delta$Mod_by_MR$bonferroni,3)
GLMM1_Delta$Hem_by_Mod_by_MR$p.value <- round(GLMM1_Delta$Hem_by_Mod_by_MR$p.value,3)
GLMM1_Delta$Hem_by_Mod_by_MR$bonferroni <- round(GLMM1_Delta$Hem_by_Mod_by_MR$bonferroni,3)


grid.arrange(nrow=1,top="Delta: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Delta))
grid.arrange(nrow=1,top="Delta: GLM main effects and interactions", tableGrob(GLMM1_Delta$Omnibus))
grid.arrange(nrow=1,top="Delta: GLM post-hoc test: 'Hemisphere*Modality'", tableGrob(GLMM1_Delta$Hem_by_Mod))
grid.arrange(nrow=1,top="Delta: GLM post-hoc test: 'Hemisphere*Motor_Region'", tableGrob(GLMM1_Delta$Hem_by_MR))
grid.arrange(nrow=1,top="Delta: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM1_Delta$Mod_by_MR))
grid.arrange(nrow=1,top="Delta: GLM post-hoc test: 'Hemisphere*Modality*Motor_Region'", tableGrob(GLMM1_Delta$Hem_by_Mod_by_MR))

plot(Delta_Boxplot_Interaction1)
plot(Delta_Boxplot_Interaction2)

dev.off()

pdf("Theta_Mixed_stats_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Theta: 'Musicianship' summary", tableGrob(Summary_Bands$Theta$Stats$Musicianship))
grid.arrange(nrow=1,top="Theta: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Theta$Stats$Modality))

plot(Summary_Bands$Theta$Plots$Musicianship_BEFORE, main = "Theta band: Musicianship")
plot(Summary_Bands$Theta$Plots$MotorRegions_BEFORE, main = "Theta band: Motor Regions")

grid.arrange(nrow=1,top="Theta: Number of outliers removed out of 1080 PLVs", tableGrob(summary(Outliers_Bands$Theta$is.outlier)))

plot(Summary_Bands$Theta$Plots$Musicianship_AFTER, main = "Theta band: Musicianship")
plot(Summary_Bands$Theta$Plots$MotorRegions_AFTER, main = "Theta band: Motor Regions")

plot(QQ_Bands$Theta, main = "Theta band: QQ plot BEFORE outlier removal")

grid.arrange(nrow=1,top="Theta: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Theta))

plot(Density_Bands$Theta, main = "Density plot BEFORE outlier removal")

GLMM1_Theta$Omnibus$p.value <- round(GLMM1_Theta$Omnibus$p.value,3)
GLMM1_Theta$Hem_by_MR$p.value <- round(GLMM1_Theta$Hem_by_MR$p.value,3)
GLMM1_Theta$Hem_by_MR$bonferroni <- round(GLMM1_Theta$Hem_by_MR$bonferroni,3)
GLMM1_Theta$Mod_by_MR$p.value <- round(GLMM1_Theta$Mod_by_MR$p.value,3)
GLMM1_Theta$Mod_by_MR$bonferroni <- round(GLMM1_Theta$Mod_by_MR$bonferroni,3)
GLMM1_Theta$Hem_by_Mod_by_MR$p.value <- round(GLMM1_Theta$Hem_by_Mod_by_MR$p.value,3)
GLMM1_Theta$Hem_by_Mod_by_MR$bonferroni <- round(GLMM1_Theta$Hem_by_Mod_by_MR$bonferroni,3)

grid.arrange(nrow=1,top="Theta: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Theta))
grid.arrange(nrow=1,top="Theta: GLM main effects and interactions", tableGrob(GLMM1_Theta$Omnibus))
grid.arrange(nrow=1,top="Theta: GLM post-hoc test: 'Hemisphere*Motor_Region'", tableGrob(GLMM1_Theta$Hem_by_MR))
grid.arrange(nrow=1,top="Theta: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM1_Theta$Mod_by_MR))
grid.arrange(nrow=1,top="Theta: GLM post-hoc test: 'Hemisphere*Modality*Motor_Region'", tableGrob(GLMM1_Theta$Hem_by_Mod_by_MR))

plot(Theta_Boxplot_Interaction1)
plot(Theta_Boxplot_Interaction2)

dev.off()

pdf("Alpha_MIXED_stats_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Alpha: 'Musicianship' summary", tableGrob(Summary_Bands$Alpha$Stats$Musicianship))
grid.arrange(nrow=1,top="Alpha: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Alpha$Stats$Modality))

plot(Summary_Bands$Alpha$Plots$Musicianship_BEFORE, main = "Alpha band: Musicianship")
plot(Summary_Bands$Alpha$Plots$MotorRegions_BEFORE, main = "Alpha band: Motor Regions")

grid.arrange(nrow=1,top="Alpha: Number of outliers removed out of 1080 PLVs", tableGrob(summary(Outliers_Bands$Alpha$is.outlier)))

plot(Summary_Bands$Alpha$Plots$Musicianship_AFTER, main = "Alpha band: Musicianship")
plot(Summary_Bands$Alpha$Plots$MotorRegions_AFTER, main = "Alpha band: Motor Regions")

plot(QQ_Bands$Alpha, main = "Alpha band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Alpha: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Alpha))

plot(Density_Bands$Alpha, main = "Density plot after outlier removal")

GLMM1_Alpha$Omnibus$p.value <- round(GLMM1_Alpha$Omnibus$p.value,3)
GLMM1_Alpha$Mod_by_MR$p.value <- round(GLMM1_Alpha$Mod_by_MR$p.value,3)
GLMM1_Alpha$Mod_by_MR$bonferroni <- round(GLMM1_Alpha$Mod_by_MR$bonferroni,3)
GLMM1_Alpha$Hem_by_Mod_by_MR$p.value <- round(GLMM1_Alpha$Hem_by_Mod_by_MR$p.value,3)
GLMM1_Alpha$Hem_by_Mod_by_MR$bonferroni <- round(GLMM1_Alpha$Hem_by_Mod_by_MR$bonferroni,3)

grid.arrange(nrow=1,top="Alpha: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Alpha))
grid.arrange(nrow=1,top="Alpha: GLM main effects and interactions", tableGrob(GLMM1_Alpha$Omnibus))
grid.arrange(nrow=1,top="Alpha: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM1_Alpha$Mod_by_MR))
grid.arrange(nrow=1,top="Alpha: GLM post-hoc test: 'Hemisphere*Modality*Motor_Region'", tableGrob(GLMM1_Alpha$Hem_by_Mod_by_MR))

plot(Alpha_Boxplot_Interaction1)

dev.off()

pdf("Beta_MIXED_stats_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Beta: 'Musicianship' summary", tableGrob(Summary_Bands$Beta$Stats$Musicianship))
grid.arrange(nrow=1,top="Beta: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Beta$Stats$Modality))

plot(Summary_Bands$Beta$Plots$Musicianship_BEFORE, main = "Beta band: Musicianship")
plot(Summary_Bands$Beta$Plots$MotorRegions_BEFORE, main = "Beta band: Motor Regions")

grid.arrange(nrow=1,top="Beta: Number of outliers removed out of 1080 PLVs", tableGrob(summary(Outliers_Bands$Beta$is.outlier)))

plot(Summary_Bands$Beta$Plots$Musicianship_AFTER, main = "Beta band: Musicianship")
plot(Summary_Bands$Beta$Plots$MotorRegions_AFTER, main = "Beta band: Motor Regions")

plot(QQ_Bands$Beta, main = "Beta band: QQ plot BEFORE outlier removal")

grid.arrange(nrow=1,top="Beta: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Beta))

plot(Density_Bands$Beta, main = "Density plot BEFORE outlier removal")

GLMM1_Beta$Omnibus$p.value <- round(GLMM1_Beta$Omnibus$p.value,3)
GLMM1_Beta$Mod_by_MR$p.value <- round(GLMM1_Beta$Mod_by_MR$p.value,3)
GLMM1_Beta$Mod_by_MR$bonferroni <- round(GLMM1_Beta$Mod_by_MR$bonferroni,3)


grid.arrange(nrow=1,top="Beta: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Beta))
grid.arrange(nrow=1,top="Beta: GLM main effects and interactions", tableGrob(GLMM1_Beta$Omnibus))
grid.arrange(nrow=1,top="Beta: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM1_Beta$Mod_by_MR))

plot(Beta_Boxplot2)
plot(Beta_Boxplot_Interaction)

dev.off()

options(digits=3)

pdf("Gamma1_MIXED_stats_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Gamma1: 'Musicianship' summary", tableGrob(Summary_Bands$Gamma1$Stats$Musicianship))
grid.arrange(nrow=1,top="Gamma1: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Gamma1$Stats$Modality))

plot(Summary_Bands$Gamma1$Plots$Musicianship_BEFORE, main = "Gamma1 band: Musicianship")
plot(Summary_Bands$Gamma1$Plots$MotorRegions_BEFORE, main = "Gamma1 band: Motor Regions")

grid.arrange(nrow=1,top="Gamma1: Number of outliers removed out of 1080 PLVs", tableGrob(summary(Outliers_Bands$Gamma1$is.outlier)))

plot(Summary_Bands$Gamma1$Plots$Musicianship_AFTER, main = "Gamma1 band: Musicianship")
plot(Summary_Bands$Gamma1$Plots$MotorRegions_AFTER, main = "Gamma1 band: Motor Regions")

plot(QQ_Bands$Gamma1, main = "Gamma1 band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Gamma1: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Gamma1))

plot(Density_Bands$Gamma1, main = "Density plot after outlier removal")

GLMM1_Gamma1$Omnibus$p.value <- round(GLMM1_Gamma1$Omnibus$p.value,3)
GLMM1_Gamma1$Hem_by_Mod$p.value <- round(GLMM1_Gamma1$Hem_by_Mod$p.value,3)
GLMM1_Gamma1$Hem_by_Mod$bonferroni <- round(GLMM1_Gamma1$Hem_by_Mod$bonferroni,3)
GLMM1_Gamma1$Mod_by_MR$p.value <- round(GLMM1_Gamma1$Mod_by_MR$p.value,3)
GLMM1_Gamma1$Mod_by_MR$bonferroni <- round(GLMM1_Gamma1$Mod_by_MR$bonferroni,3)
GLMM1_Gamma1$Hem_by_Mod_by_MR$p.value <- round(GLMM1_Gamma1$Hem_by_Mod_by_MR$p.value,3)
GLMM1_Gamma1$Hem_by_Mod_by_MR$bonferroni <- round(GLMM1_Gamma1$Hem_by_Mod_by_MR$bonferroni,3)

grid.arrange(nrow=1,top="Gamma1: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Gamma1))
grid.arrange(nrow=1,top="Gamma1: GLM main effects and interactions", tableGrob(GLMM1_Gamma1$Omnibus))
grid.arrange(nrow=1,top="Gamma1: GLM post-hoc test: 'Hemisphere*Modality'", tableGrob(GLMM1_Gamma1$Hem_by_Mod))
grid.arrange(nrow=1,top="Gamma1: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM1_Gamma1$Mod_by_MR))
grid.arrange(nrow=1,top="Gamma1: GLM post-hoc test: 'Hemisphere*Modality*Motor_Region'", tableGrob(GLMM1_Gamma1$Hem_by_Mod_by_MR))

plot(Gamma1_Boxplot_Interaction1)
plot(Gamma1_Boxplot_Interaction3)

dev.off()

pdf("Gamma2_MIXED_stats_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Gamma2: 'Musicianship' summary", tableGrob(Summary_Bands$Gamma2$Stats$Musicianship))
grid.arrange(nrow=1,top="Gamma2: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Gamma2$Stats$Modality))

plot(Summary_Bands$Gamma2$Plots$Musicianship_BEFORE, main = "Gamma2 band: Musicianship")
plot(Summary_Bands$Gamma2$Plots$MotorRegions_BEFORE, main = "Gamma2 band: Motor Regions")

grid.arrange(nrow=1,top="Gamma2: Number of outliers removed out of 1080 PLVs", tableGrob(summary(Outliers_Bands$Gamma2$is.outlier)))

plot(Summary_Bands$Gamma2$Plots$Musicianship_AFTER, main = "Gamma2 band: Musicianship")
plot(Summary_Bands$Gamma2$Plots$MotorRegions_AFTER, main = "Gamma2 band: Motor Regions")

plot(QQ_Bands$Gamma2, main = "Gamma2 band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Gamma2: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Gamma2))

plot(Density_Bands$Gamma2, main = "Density plot after outlier removal")

GLMM1_Gamma2$Omnibus$p.value <- round(GLMM1_Gamma2$Omnibus$p.value,3)
GLMM1_Gamma2$Hem_by_MR_by_MR$p.value <- round(GLMM1_Gamma2$Hem_by_MR$p.value,3)
GLMM1_Gamma2$Hem_by_MR$bonferroni <- round(GLMM1_Gamma2$Hem_by_MR$bonferroni,3)
GLMM1_Gamma2$Mod_by_MR$p.value <- round(GLMM1_Gamma2$Mod_by_MR$p.value,3)
GLMM1_Gamma2$Mod_by_MR$bonferroni <- round(GLMM1_Gamma2$Mod_by_MR$bonferroni,3)
GLMM1_Gamma2$Hem_by_Mod_by_MR$p.value <- round(GLMM1_Gamma2$Hem_by_Mod_by_MR$p.value,3)
GLMM1_Gamma2$Hem_by_Mod_by_MR$bonferroni <- round(GLMM1_Gamma2$Hem_by_Mod_by_MR$bonferroni,3)

grid.arrange(nrow=1,top="Gamma2: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Gamma2))
grid.arrange(nrow=1,top="Gamma2: GLM main effects and interactions", tableGrob(GLMM1_Gamma2$Omnibus))
grid.arrange(nrow=1,top="Gamma2: GLM post-hoc test: 'Hemisphere*Motor_Region'", tableGrob(GLMM1_Gamma2$Hem_by_MR))
grid.arrange(nrow=1,top="Gamma2: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM1_Gamma2$Mod_by_MR))
grid.arrange(nrow=1,top="Gamma2: GLM post-hoc test: 'Hemisphere*Modality*Motor_Region'", tableGrob(GLMM1_Gamma2$Hem_by_Mod_by_MR))

plot(Gamma2_Boxplot_Interaction1)
plot(Gamma2_Boxplot_Interaction2)

dev.off()