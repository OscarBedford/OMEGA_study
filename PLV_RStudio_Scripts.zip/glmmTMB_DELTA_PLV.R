library(emmeans)
library(glmmTMB)
library(rstatix)

# STEP 1: We compute the repeated measures GLMM model

GLMM_Delta = glmmTMB(PLV~Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                       data = Delta,
                       family = beta_family(link = "logit")
)

# Musicianship model

# GLMM_Delta_2 = glmmTMB(PLV~Musicianship*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
#                     data = Delta,
#                     family = beta_family(link = "logit"))

# STEP 2: We compute the omnibus test for the model (with main effects and interactions)

Omnibus_GLMM_Delta          = joint_tests(GLMM_Delta)
Omnibus_GLMM_Delta$p.value  = round(Omnibus_GLMM_Delta$p.value,digits=5)

# STEP 3: We compute the pairwise comparisons for the significant interactions 

GLMM1_Delta_pairs_HM    =   pairs(emmeans(GLMM_Delta,~ Hemisphere|Modality), adjust="bonferroni")
summary_Delta_GLMM1_HM  =   summary(GLMM1_Delta_pairs_HM)

GLMM1_Delta_pairs_HMr   =   pairs(emmeans(GLMM_Delta,~ Hemisphere|Motor_Region), adjust="bonferroni")
summary_Delta_GLMM1_HMr =   summary(GLMM1_Delta_pairs_HMr)

GLMM1_Delta_pairs_MrMOD   =   pairs(emmeans(GLMM_Delta,~ Motor_Region|Modality), adjust="bonferroni")
summary_Delta_GLMM1_MrMOD =   summary(GLMM1_Delta_pairs_MMr)
                           
GLMM1_Delta_pairs_X     =   pairs(emmeans(GLMM_Delta,~ Modality*Motor_Region), adjust="bonferroni")
summary_Delta_GLMM1_X   =   summary(GLMM1_Delta_pairs_X)      

# STEP 4: We round down all p-values

GLMM1_HM_Result   =  adjust_pvalue(summary_Delta_GLMM1_HM,  "p.value", "bonferroni", method = "bonferroni") 
GLMM1_HMr_Result  =  adjust_pvalue(summary_Delta_GLMM1_HMr, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_X_Result    =  adjust_pvalue(summary_Delta_GLMM1_X,   "p.value", "bonferroni", method = "bonferroni")

GLMM1_HM_Result$p.value    = round(GLMM1_HM_Result$p.value,    digits=3)
GLMM1_HM_Result$bonferroni = round(GLMM1_HM_Result$bonferroni, digits=3)

GLMM1_HMr_Result$p.value    = round(GLMM1_HMr_Result$p.value,    digits=3)
GLMM1_HMr_Result$bonferroni = round(GLMM1_HMr_Result$bonferroni, digits=3)

GLMM1_X_Result$p.value    = round(GLMM1_X_Result$p.value,    digits=3)
GLMM1_X_Result$bonferroni = round(GLMM1_X_Result$bonferroni, digits=3)

# STEP 5: We add everything into one big list called GLMM1_Delta and we remove extraneous variables

GLMM1_Delta = list(Omnibus = Omnibus_GLMM_Delta_2,
                   Hem_given_Mod = GLMM1_HM_Result,
                   Hem_given_MR = GLMM1_HMr_Result,
                   Mod_by_MR = GLMM1_X_Result)

# We remove all the variables we created along the way

rm(GLMM_Delta,
   Omnibus_GLMM_Delta,
   
   GLMM1_Delta_pairs_HM, 
   summary_Delta_GLMM1_HM,
   GLMM1_Delta_pairs_HMr,
   summary_Delta_GLMM1_HMr,
   GLMM1_Delta_pairs_X,
   summary_Delta_GLMM1_X, 
   
   GLMM1_HM_Result,
   GLMM1_HMr_Result,
   GLMM1_X_Result)

# Uncomment this if you need to back-transform the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale
