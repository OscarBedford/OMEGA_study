library(emmeans)
library(glmmTMB)
library(rstatix)

# STEP 1: We compute the repeated measures GLMM model

GLMM_Gamma1 = glmmTMB(PLV~Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                      data = Gamma1,
                      family = beta_family(link = "logit"))

# Musicianship model

# GLMM_Gamma1_2 = glmmTMB(PLV~Musicianship*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
#                      data = Gamma1,
#                      family = beta_family(link = "logit"))

# STEP 2: We compute the omnibus test for the model (with main effects and interactions)

Omnibus_GLMM_Gamma1         = joint_tests(GLMM_Gamma1)
Omnibus_GLMM_Gamma1$p.value = round(Omnibus_GLMM_Gamma1_2$p.value,digits=5)

# STEP 3: We compute the pairwise comparisons for the significant interactions

GLMM1_Gamma1_pairs_HM     =   pairs(emmeans(GLMM_Gamma1_2,~ Hemisphere|Modality), adjust="bonferroni")
summary_Gamma1_GLMM1_HM   =   summary(GLMM1_Gamma1_pairs_HM)

GLMM1_Gamma1_pairs_X      =  pairs(emmeans(GLMM_Gamma1_2,~ Modality*Motor_Region), adjust="bonferroni")
summary_Gamma1_GLMM1_X    =  summary(GLMM1_Gamma1_pairs_X)

GLMM1_Gamma1_pairs_TRI    =  pairs(emmeans(GLMM_Gamma1_2,~ Modality*Motor_Region*Hemisphere), adjust="bonferroni")
summary_Gamma1_GLMM1_TRI  =  summary(GLMM1_Gamma1_pairs_TRI)

# STEP 4: We round down all p-values

GLMM1_HM_Result   =  adjust_pvalue(summary_Gamma1_GLMM1_HM,  "p.value", "bonferroni", method = "bonferroni") 
GLMM1_X_Result  =  adjust_pvalue(summary_Gamma1_GLMM1_X,     "p.value", "bonferroni", method = "bonferroni")
GLMM1_TRI_Result  =  adjust_pvalue(summary_Gamma1_GLMM1_TRI, "p.value", "bonferroni", method = "bonferroni")

GLMM1_HM_Result$p.value    = round(GLMM1_HM_Result$p.value,      digits=3)
GLMM1_HM_Result$bonferroni = round(GLMM1_HM_Result$bonferroni,   digits=3)

GLMM1_X_Result$p.value    = round(GLMM1_X_Result$p.value,        digits=3)
GLMM1_X_Result$bonferroni = round(GLMM1_X_Result$bonferroni,     digits=3)

GLMM1_TRI_Result$p.value    = round(GLMM1_TRI_Result$p.value,    digits=3)
GLMM1_TRI_Result$bonferroni = round(GLMM1_TRI_Result$bonferroni, digits=3)

# STEP 5: We add everything into one big list called GLMM1_Delta and we remove extraneous variables

GLMM1_Gamma1 = list(Omnibus = Omnibus_GLMM_Gamma1_2,
                    Hem_given_Mod = GLMM1_HM_Result,
                    Mod_by_MR  = GLMM1_X_Result,
                    Mod_by_MR_by_Hem  = GLMM1_TRI_Result)

# We remove all the variables we created along the way

rm(GLMM_Gamma1,
   Omnibus_GLMM_Gamma1,
   
   GLMM1_Gamma1_pairs_HM,
   summary_Gamma1_GLMM1_HM,
   GLMM1_Gamma1_pairs_X,
   summary_Gamma1_GLMM1_X,
   GLMM1_Gamma1_pairs_TRI,
   summary_Gamma1_GLMM1_TRI,
   
   GLMM1_HM_Result,
   GLMM1_X_Result,
   GLMM1_TRI_Result
   )

# Uncomment this if you need to back-transform the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale