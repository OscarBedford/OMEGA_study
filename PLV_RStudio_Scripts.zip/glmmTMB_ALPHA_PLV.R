library(emmeans)
library(glmmTMB)
library(rstatix)

# STEP 1: We compute the repeated measures GLMM model

GLMM_Alpha= glmmTMB(PLV~Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                    data = Alpha,
                    family = beta_family(link = "logit"))

# Musicianship model

# GLMM_Alpha_2= glmmTMB(PLV~Musicianship*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
#                     data = Alpha,
#                     family = beta_family(link = "logit"))

# STEP 2: We compute the omnibus test for the model (with main effects and interactions)

Omnibus_GLMM_Alpha = joint_tests(GLMM_Alpha)
Omnibus_GLMM_Alpha$p.value = round(Omnibus_GLMM_Alpha$p.value,digits=5)

# STEP 3: We compute the pairwise comparisons for the significant interactions

GLMM1_Alpha_pairs_X       =  pairs(emmeans(GLMM_Alpha,~ Modality*Motor_Region), adjust="bonferroni")
summary_Alpha_GLMM1_X     =  summary(GLMM1_Alpha_pairs_X)

GLMM1_Alpha_pairs_TRI     =  pairs(emmeans(GLMM_Alpha,~ Modality:Motor_Region:Hemisphere), adjust="bonferroni")
summary_Alpha_GLMM1_TRI   =  summary(GLMM1_Alpha_pairs_TRI)

# STEP 4: We round down all p-values

GLMM1_X_Result    =  adjust_pvalue(summary_Alpha_GLMM1_X,   "p.value", "bonferroni", method = "bonferroni")
GLMM1_TRI_Result  =  adjust_pvalue(summary_Alpha_GLMM1_TRI, "p.value", "bonferroni", method = "bonferroni")

GLMM1_X_Result$p.value    = round(GLMM1_X_Result$p.value,    digits=3)
GLMM1_X_Result$bonferroni = round(GLMM1_X_Result$bonferroni, digits=3)

GLMM1_TRI_Result$p.value    = round(GLMM1_TRI_Result$p.value,    digits=3)
GLMM1_TRI_Result$bonferroni = round(GLMM1_TRI_Result$bonferroni, digits=3)

# STEP 5: We add everything into one big list called GLMM1_Delta and we remove extraneous variables

GLMM1_Alpha = list(Omnibus = Omnibus_GLMM_Alpha,
                   Mod_by_MR = GLMM1_X_Result,
                   Hem_by_Mod_by_MR = GLMM1_TRI_Result)

# We remove all the variables we created along the way

rm(GLMM_Alpha,
   Omnibus_GLMM_Alpha,
   
   GLMM1_Alpha_pairs_X,
   summary_Alpha_GLMM1_X,
   GLMM1_Alpha_pairs_TRI,
   summary_Alpha_GLMM1_TRI,
   
   GLMM1_X_Result,
   GLMM1_TRI_Result)

# Uncomment this if you need to back-transform the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale
