library(emmeans)
library(glmmTMB)
library(rstatix)

# STEP 1: We compute the repeated measures GLMM model

GLMM_Theta = glmmTMB(PLV~Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                       data = Theta,
                       family = beta_family(link = "logit"))

# Musicianship model

# GLMM_Theta_2 = glmmTMB(PLV~Musicianship*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
#                     data = Theta,
#                     family = beta_family(link = "logit"))

# STEP 2: We compute the omnibus test for the model (with main effects and interactions)

Omnibus_GLMM_Theta          = joint_tests(GLMM_Theta)
Omnibus_GLMM_Theta$p.value  = round(Omnibus_GLMM_Theta$p.value,digits=5)

# STEP 3: We compute the pairwise comparisons for the significant interactions  

GLMM1_Theta_pairs_HMr   =   pairs(emmeans(GLMM_Theta,~ Hemisphere|Motor_Region), adjust="bonferroni")
summary_GLMM1_Theta_HMr =   summary(GLMM1_Theta_pairs_HMr)

GLMM1_Theta_pairs_X     =   pairs(emmeans(GLMM_Theta,~ Modality*Motor_Region), adjust="bonferroni")
summary_Theta_GLMM1_X   =   summary(GLMM1_Theta_pairs_X)      

# STEP 4: We round down all p-values

GLMM1_HMr_Result   =  adjust_pvalue(summary_GLMM1_Theta_HMr,     "p.value", "bonferroni", method = "bonferroni") 
GLMM1_X_Result     =  adjust_pvalue(summary_Theta_GLMM1_asterix, "p.value", "bonferroni", method = "bonferroni")

GLMM1_HMr_Result$p.value    = round(GLMM1_HMr_Result$p.value,digits=3)
GLMM1_HMr_Result$bonferroni = round(GLMM1_HMr_Result$bonferroni,digits=3)

GLMM1_X_Result$p.value    = round(GLMM1_X_Result$p.value,digits=3)
GLMM1_X_Result$bonferroni = round(GLMM1_X_Result$bonferroni,digits=3)

# STEP 5: We add everything into one big list called GLMM1_Delta and we remove extraneous variables

GLMM1_Theta = list(Omnibus = Omnibus_GLMM_Theta_2,
                   Hem_given_MR = GLMM1_HMr_Result,
                   Mod_by_MR = GLMM1_X_Result)

# We remove all the variables we created along the way

rm(GLMM_Theta,
   Omnibus_GLMM_Theta,
   
   GLMM1_Theta_pairs_HMr,
   summary_GLMM1_Theta_HMr,
   GLMM1_Theta_pairs_X,
   summary_Theta_GLMM1_X,
   
   GLMM1_HMr_Result,
   GLMM1_X_Result)

# Uncomment this if you need to back-transform the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale