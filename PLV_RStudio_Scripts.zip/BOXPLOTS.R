
library(tidyr)
library(ggpubr)
library(rstatix)
library(tibble)
library(ggplot2)

# Original Delta plot

Delta_Clean_Boxplot_MotorRegions <- ggboxplot(
  Delta, x = "Motor_Region", y = "PLV",
  color = "black", fill = "Hemisphere", palette = c("dodgerblue", "indianred2"),
  facet.by = "Modality", short.panel.labs = FALSE,
  title = "Delta: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region'",
  size = 0.5,
  outlier.size = 1.5
) +
  labs(x = "Motor region", fill= 'Hemisphere  ') +
  theme(
    axis.text.x = element_text(size=12.5, face = "bold", vjust = 0.85),
    axis.text.y = element_text(size = 12),
    strip.text = element_text(size = 13, face = "bold"), 
    axis.title.x = element_text(size = 13),
    axis.title.y = element_text(size = 12),
    plot.title = element_text(size = 13.5),
    panel.border = element_rect(linewidth = 0.8),
    legend.text = element_text(size = 10),
    legend.title = element_text(size = 11.5),
    axis.ticks.length.x = unit(.08, "cm")
  ) 
Delta_Clean_Boxplot_MotorRegions

# Original Theta plot 

Theta_Clean_Boxplot_MotorRegions <- ggboxplot(
  Theta, x = "Motor_Region", y = "PLV",
  color = "black", fill = "Hemisphere", palette = c("dodgerblue", "indianred2"),
  facet.by = "Modality", short.panel.labs = FALSE,
  title = "Theta: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region'",
  size = 0.5,
  outlier.size = 1.5
) +
  labs(x = "Motor region", fill= 'Hemisphere  ') +
  theme(
    axis.text.x = element_text(size=12.5, face = "bold", vjust = 0.85),
    axis.text.y = element_text(size = 12),
    strip.text = element_text(size = 13, face = "bold"), 
    axis.title.x = element_text(size = 13),
    axis.title.y = element_text(size = 12),
    plot.title = element_text(size = 13.5),
    panel.border = element_rect(linewidth = 0.8),
    legend.text = element_text(size = 10),
    legend.title = element_text(size = 11.5),
    axis.ticks.length.x = unit(.08, "cm")
  ) 
Theta_Clean_Boxplot_MotorRegions

# Original Alpha plot 

Alpha_Clean_Boxplot_MotorRegions <- ggboxplot(
  Alpha, x = "Motor_Region", y = "PLV",
  color = "black", fill = "Hemisphere", palette = c("dodgerblue", "indianred2"),
  facet.by = "Modality", short.panel.labs = FALSE,
  title = "Alpha: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region'",
  size = 0.5,
  outlier.size = 1.5
) +
  labs(x = "Motor region", fill= 'Hemisphere  ') +
  theme(
    axis.text.x = element_text(size=12.5, face = "bold", vjust = 0.85),
    axis.text.y = element_text(size = 12),
    strip.text = element_text(size = 13, face = "bold"), 
    axis.title.x = element_text(size = 13),
    axis.title.y = element_text(size = 12),
    plot.title = element_text(size = 13.5),
    panel.border = element_rect(linewidth = 0.8),
    legend.text = element_text(size = 10),
    legend.title = element_text(size = 11.5),
    axis.ticks.length.x = unit(.08, "cm")
  ) 
Alpha_Clean_Boxplot_MotorRegions

# Original Beta plot 

Beta_Clean_Boxplot_MotorRegions <- ggboxplot(
  Beta, x = "Motor_Region", y = "PLV",
  color = "black", fill = "Hemisphere", palette = c("dodgerblue", "indianred2"),
  facet.by = "Modality", short.panel.labs = FALSE,
  title = "Beta: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region'",
  size = 0.5,
  outlier.size = 1.5
) +
  labs(x = "Motor region", fill= 'Hemisphere  ') +
  theme(
    axis.text.x = element_text(size=12.5, face = "bold", vjust = 0.85),
    axis.text.y = element_text(size = 12),
    strip.text = element_text(size = 13, face = "bold"), 
    axis.title.x = element_text(size = 13),
    axis.title.y = element_text(size = 12),
    plot.title = element_text(size = 13.5),
    panel.border = element_rect(linewidth = 0.8),
    legend.text = element_text(size = 10),
    legend.title = element_text(size = 11.5),
    axis.ticks.length.x = unit(.08, "cm")
  ) 
Beta_Clean_Boxplot_MotorRegions

# Original Gamma1 plot 

Gamma1_Clean_Boxplot_MotorRegions <- ggboxplot(
  Gamma1, x = "Motor_Region", y = "PLV",
  color = "black", fill = "Hemisphere", palette = c("dodgerblue", "indianred2"),
  facet.by = "Modality", short.panel.labs = FALSE,
  title = "Gamma1: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region'",
  size = 0.5,
  outlier.size = 1.5
) +
  labs(x = "Motor region", fill= 'Hemisphere  ') +
  theme(
    axis.text.x = element_text(size=12.5, face = "bold", vjust = 0.85),
    axis.text.y = element_text(size = 12),
    strip.text = element_text(size = 13, face = "bold"), 
    axis.title.x = element_text(size = 13),
    axis.title.y = element_text(size = 12),
    plot.title = element_text(size = 13.5),
    panel.border = element_rect(linewidth = 0.8),
    legend.text = element_text(size = 10),
    legend.title = element_text(size = 11.5),
    axis.ticks.length.x = unit(.08, "cm")
  ) 
Gamma1_Clean_Boxplot_MotorRegions

# Original Gamma2 plot 

Gamma2_Clean_Boxplot_MotorRegions <- ggboxplot(
  Gamma2, x = "Motor_Region", y = "PLV",
  color = "black", fill = "Hemisphere", palette = c("dodgerblue", "indianred2"),
  facet.by = "Modality", short.panel.labs = FALSE,
  title = "Gamma2: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region'",
  size = 0.5,
  outlier.size = 1.5
) +
  labs(x = "Motor region", fill= 'Hemisphere  ') +
  theme(
    axis.text.x = element_text(size=12.5, face = "bold", vjust = 0.85),
    axis.text.y = element_text(size = 12),
    strip.text = element_text(size = 13, face = "bold"), 
    axis.title.x = element_text(size = 13),
    axis.title.y = element_text(size = 12),
    plot.title = element_text(size = 13.5),
    panel.border = element_rect(linewidth = 0.8),
    legend.text = element_text(size = 10),
    legend.title = element_text(size = 11.5),
    axis.ticks.length.x = unit(.08, "cm")
  ) 
Gamma2_Clean_Boxplot_MotorRegions

# Re-scaled Delta plot

Delta_Clean_Boxplot_MotorRegions <- ggboxplot(
  Delta, x = "Motor_Region", y = "PLV",
  color = "black", fill = "Hemisphere", palette = c("dodgerblue", "indianred2"),
  facet.by = "Modality", short.panel.labs = FALSE,
  title = "Delta: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region' (Re-scaled)",
  size = 0.5,
  outlier.size = 1.5
) +
  labs(x = "Motor region", fill= 'Hemisphere  ') +
  theme(
    axis.text.x = element_text(size=12.5, face = "bold", vjust = 0.85),
    axis.text.y = element_text(size = 12),
    strip.text = element_text(size = 13, face = "bold"), 
    axis.title.x = element_text(size = 13),
    axis.title.y = element_text(size = 12),
    plot.title = element_text(size = 13.5),
    panel.border = element_rect(linewidth = 0.8),
    legend.text = element_text(size = 10),
    legend.title = element_text(size = 11.5),
    axis.ticks.length.x = unit(.08, "cm")
) +
ylim(0,0.35)
Delta_Clean_Boxplot_MotorRegions

# Re-scaled Theta plot 

Theta_Clean_Boxplot_MotorRegions <- ggboxplot(
  Theta, x = "Motor_Region", y = "PLV",
  color = "black", fill = "Hemisphere", palette = c("dodgerblue", "indianred2"),
  facet.by = "Modality", short.panel.labs = FALSE,
  title = "Theta: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region' (Re-scaled)",
  size = 0.5,
  outlier.size = 1.5
) +
  labs(x = "Motor region", fill= 'Hemisphere  ') +
  theme(
    axis.text.x = element_text(size=12.5, face = "bold", vjust = 0.85),
    axis.text.y = element_text(size = 12),
    strip.text = element_text(size = 13, face = "bold"), 
    axis.title.x = element_text(size = 13),
    axis.title.y = element_text(size = 12),
    plot.title = element_text(size = 13.5),
    panel.border = element_rect(linewidth = 0.8),
    legend.text = element_text(size = 10),
    legend.title = element_text(size = 11.5),
    axis.ticks.length.x = unit(.08, "cm")
  ) +
ylim(0,0.35)
Theta_Clean_Boxplot_MotorRegions

# Re-scaled Alpha plot 

Alpha_Clean_Boxplot_MotorRegions <- ggboxplot(
  Alpha, x = "Motor_Region", y = "PLV",
  color = "black", fill = "Hemisphere", palette = c("dodgerblue", "indianred2"),
  facet.by = "Modality", short.panel.labs = FALSE,
  title = "Alpha: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region' (Re-scaled)",
  size = 0.5,
  outlier.size = 1.5
) +
  labs(x = "Motor region", fill= 'Hemisphere  ') +
  theme(
    axis.text.x = element_text(size=12.5, face = "bold", vjust = 0.85),
    axis.text.y = element_text(size = 12),
    strip.text = element_text(size = 13, face = "bold"), 
    axis.title.x = element_text(size = 13),
    axis.title.y = element_text(size = 12),
    plot.title = element_text(size = 13.5),
    panel.border = element_rect(linewidth = 0.8),
    legend.text = element_text(size = 10),
    legend.title = element_text(size = 11.5),
    axis.ticks.length.x = unit(.08, "cm")
  ) +
ylim(0,0.35) 
Alpha_Clean_Boxplot_MotorRegions

# Re-scaled Beta plot 

Beta_Clean_Boxplot_MotorRegions <- ggboxplot(
  Beta, x = "Motor_Region", y = "PLV",
  color = "black", fill = "Hemisphere", palette = c("dodgerblue", "indianred2"),
  facet.by = "Modality", short.panel.labs = FALSE,
  title = "Beta: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region' (Re-scaled)",
  size = 0.5,
  outlier.size = 1.5
) +
  labs(x = "Motor region", fill= 'Hemisphere  ') +
  theme(
    axis.text.x = element_text(size=12.5, face = "bold", vjust = 0.85),
    axis.text.y = element_text(size = 12),
    strip.text = element_text(size = 13, face = "bold"), 
    axis.title.x = element_text(size = 13),
    axis.title.y = element_text(size = 12),
    plot.title = element_text(size = 13.5),
    panel.border = element_rect(linewidth = 0.8),
    legend.text = element_text(size = 10),
    legend.title = element_text(size = 11.5),
    axis.ticks.length.x = unit(.08, "cm")
  ) +
ylim(0,0.35)
Beta_Clean_Boxplot_MotorRegions

# Re-scaled Gamma1 plot 

Gamma1_Clean_Boxplot_MotorRegions <- ggboxplot(
  Gamma1, x = "Motor_Region", y = "PLV",
  color = "black", fill = "Hemisphere", palette = c("dodgerblue", "indianred2"),
  facet.by = "Modality", short.panel.labs = FALSE,
  title = "Gamma1: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region' (Re-scaled)",
  size = 0.5,
  outlier.size = 1.5
) +
  labs(x = "Motor region", fill= 'Hemisphere  ') +
  theme(
    axis.text.x = element_text(size=12.5, face = "bold", vjust = 0.85),
    axis.text.y = element_text(size = 12),
    strip.text = element_text(size = 13, face = "bold"), 
    axis.title.x = element_text(size = 13),
    axis.title.y = element_text(size = 12),
    plot.title = element_text(size = 13.5),
    panel.border = element_rect(linewidth = 0.8),
    legend.text = element_text(size = 10),
    legend.title = element_text(size = 11.5),
    axis.ticks.length.x = unit(.08, "cm")
  ) +
ylim(0,0.35)
Gamma1_Clean_Boxplot_MotorRegions

# Re-scaled Gamma2 plot 

Gamma2_Clean_Boxplot_MotorRegions <- ggboxplot(
  Gamma2, x = "Motor_Region", y = "PLV",
  color = "black", fill = "Hemisphere", palette = c("dodgerblue", "indianred2"),
  facet.by = "Modality", short.panel.labs = FALSE,
  title = "Gamma2: Boxplot of 'Hemisphere' by 'Modality' by 'Motor region' (Re-scaled)",
  size = 0.5,
  outlier.size = 1.5
) +
  labs(x = "Motor region", fill= 'Hemisphere  ') +
  theme(
    axis.text.x = element_text(size=12.5, face = "bold", vjust = 0.85),
    axis.text.y = element_text(size = 12),
    strip.text = element_text(size = 13, face = "bold"), 
    axis.title.x = element_text(size = 13),
    axis.title.y = element_text(size = 12),
    plot.title = element_text(size = 13.5),
    panel.border = element_rect(linewidth = 0.8),
    legend.text = element_text(size = 10),
    legend.title = element_text(size = 11.5),
    axis.ticks.length.x = unit(.08, "cm")
  ) +
  ylim(0,0.35)
Gamma2_Clean_Boxplot_MotorRegions