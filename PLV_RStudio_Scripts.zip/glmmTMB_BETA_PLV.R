library(emmeans)
library(glmmTMB)
library(rstatix)

# STEP 1: We compute the repeated measures GLMM model

GLMM_Beta= glmmTMB(PLV~Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                   data = Beta,
                   family = beta_family(link = "logit"))

# Musicianship model

# GLMM_Beta_2= glmmTMB(PLV~Musicianship*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                   # data = Beta,
                   # family = beta_family(link = "logit"))

# STEP 2: We compute the omnibus test for the model (with main effects and interactions)

Omnibus_GLMM_Beta = joint_tests(GLMM_Beta)
Omnibus_GLMM_Beta$p.value = round(Omnibus_GLMM_Beta$p.value,digits=5)

# STEP 3: We compute the pairwise comparisons for the significant interactions

GLMM1_Beta_pairs_MMr     =   pairs(emmeans(GLMM_Beta,~ Modality*Motor_Region), adjust="bonferroni")
summary_GLMM1_Beta_MMr   =   summary(GLMM1_Beta_pairs_MMr)

# STEP 4: We round down all p-values

GLMM1_MMr_Result   =  adjust_pvalue(summary_GLMM1_Beta_MMr, "p.value", "bonferroni", method = "bonferroni") 

GLMM1_MMr_Result$p.value    = round(GLMM1_MMr_Result$p.value,    digits=3)
GLMM1_MMr_Result$bonferroni = round(GLMM1_MMr_Result$bonferroni, digits=3)

# STEP 5: We add everything into one big list called GLMM1_Delta and we remove extraneous variables

GLMM1_Beta = list(Omnibus = Omnibus_GLMM_Beta_2,
                  Mod_by_MR = GLMM1_MMr_Result)

# We remove all the variables we created along the way

rm(GLMM_Beta_2,
   Omnibus_GLMM_Beta_2,
   
   GLMM1_Beta_pairs_MMr,
   summary_GLMM1_Beta_MMr,
   
   GLMM1_MMr_Result)

# Uncomment this if you need to back-transform the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale