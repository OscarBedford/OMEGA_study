## Transform: MATLAB matrix to RSTUDIO list

# Just like in Matlab, we will create a variable SubjectNames 
# Note that SubjectNames needs to be as long as the last subject's tag (e.g. 1:210)

SubjectNames <- vector("list",210)

# Now we will iteratively append the character string "sub000" or "sub00" or "sub0"

for (i in 1:length(SubjectNames)){
  if(i <= 9){
    SubjectNames[i] = paste0("sub000",(i)) 
  }
  else if(i <= 99){
    SubjectNames[i] = paste0("sub00",(i))
  }
  else{
    SubjectNames[i] = paste0("sub0",(i))
  }
}

# Now we will remove all subject NUMBERS that we don't need
# So if we wanted to exclude subjects 1, 33 and 190 we would write:
# SubjectNames <-SubjectNames[-c(1,33,190)]

SubjectNames <- SubjectNames[-c(6,9,10,17,19,22,27,34,38:39,41:44,51,53:54,57,59:62,66:68,71:73,75,
                                78:81,85,88:89,92,95:96,98,100,107:133,135:144,147,153,155,158:165,
                                167,168,170,173,177:178,180,182:183,185:190,192:194,196:207,209)]

# We will also need a SubjectPath variable for each hemisphere
# This variable will contain the directories of each subject's LEFT and RIGHT PLV results:

SubjectPathsLEFT <- list (1:length(SubjectNames))
for (i in 1:length(SubjectNames)){
  SubjectPathsLEFT[i] = paste0("C:/Users/usuario/Desktop/IPN/PLV/MATRICES/LEFT/RStudioMatrix_PLV_LEFT_",SubjectNames[i],".mat")
}

SubjectPathsRIGHT <- list (1:length(SubjectNames))
for (i in 1:length(SubjectNames)){
  SubjectPathsRIGHT[i] = paste0("C:/Users/usuario/Desktop/IPN/PLV/MATRICES/RIGHT/RStudioMatrix_PLV_RIGHT_",SubjectNames[i],".mat")
}

# We also need to pre-allocate three lists which we will be using further down the line:

PLV_LEFT = list()
PLV_RIGHT = list()
PLV = list()

#################################
# Step 1: Importing the .mat file
#################################

# The first step is to import the raw .mat file as variable 'x' and 'y'

library(R.matlab)

for (i in 1:length(SubjectNames)){

  x <- readMat(SubjectPathsLEFT[i])
  y <- readMat(SubjectPathsRIGHT[i])

###########################################
# Step 2: Converting variable into a matrix
###########################################

# First we convert 'x' into a matrix called 'mat' with 6 rows and 36 columns:

matX = matrix(unlist(x),nrow = 6)
matY = matrix(unlist(y),nrow = 6)

# Now we need to segment 'matX' into 6 separate matrices

delta <- matX[1:6,1:6]
theta <- matX[1:6,7:12]
alpha <- matX[1:6,13:18]
beta <- matX[1:6,19:24]
gamma1 <- matX[1:6,25:30]
gamma2 <- matX[1:6,31:36]

######################################
# Step 3: Adding row and column labels
######################################

# Before we recombine these 6 matrices, let's first add the row and col labels

rownames(delta) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(theta) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(alpha) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(beta) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(gamma1) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(gamma2) <- c("A1","STG","V1","M1","vPMC","dPMC")

colnames(delta) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(theta) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(alpha) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(beta) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(gamma1) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(gamma2) <- c("A1","STG","V1","M1","vPMC","dPMC")

###############################################
# Step 4: Re-combining all matrices into a list
###############################################

PLV_LEFT[[i]] <- list(delta = delta, # note that we're also adding names to each sub-matrix 
                          theta = theta,
                          alpha = alpha,
                          beta = beta,
                          gamma1 = gamma1,
                          gamma2 = gamma2)

######################################
# Step 5: Deleting redundant variables
######################################

# We won't be needing x, mat, nor the individual matrices anymore 

rm(x,matX,delta,theta,alpha,beta,gamma1,gamma2)

##################################
# Step 6: Rinse and repeat for 'y'
##################################

delta <- matY[1:6,1:6]
theta <- matY[1:6,7:12]
alpha <- matY[1:6,13:18]
beta <- matY[1:6,19:24]
gamma1 <- matY[1:6,25:30]
gamma2 <- matY[1:6,31:36]

rownames(delta) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(theta) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(alpha) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(beta) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(gamma1) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(gamma2) <- c("A1","STG","V1","M1","vPMC","dPMC")

colnames(delta) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(theta) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(alpha) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(beta) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(gamma1) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(gamma2) <- c("A1","STG","V1","M1","vPMC","dPMC")

PLV_RIGHT[[i]] <- list(delta = delta, # note that we're also adding names to each sub-matrix 
                         theta = theta,
                         alpha = alpha,
                         beta = beta,
                         gamma1 = gamma1,
                         gamma2 = gamma2)

rm(y,matY,delta,theta,alpha,beta,gamma1,gamma2)

################################################################  
# Step 7: Condense LEFT/RIGHT into one mega list for each subject
################################################################

# In the end we only want one nested list, so we say:

PLV[[i]] <- list(LEFT = PLV_LEFT[[i]],
                     RIGHT = PLV_RIGHT[[i]])

}

# Now that we have that nested list, we can delete the standalone LEFT and RIGHT lists:

rm(PLV_LEFT)
rm(PLV_RIGHT)
rm(i)

# We will name each row in the first layer of the nested list (PLV) using the the elements in SubjectNames

names(PLV) <- SubjectNames

# DONE -- You can proceed to ExtractAM-VM.R
