library(emmeans)
library(glmmTMB)
library(rstatix)

# STEP 1: We compute the repeated measures GLMM model

GLMM_Gamma2 = glmmTMB(PLV~Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                        data = Gamma2,
                        family = beta_family(link = "logit"))

# Musicianship model

# GLMM_Gamma2= glmmTMB(PLV~Musicianship*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
#                      data = Gamma2,
#                      family = beta_family(link = "logit"))
# control=glmmTMBControl(optCtrl=list(iter.max=1e3,eval.max=1e3)))


# STEP 2: We compute the omnibus test for the model (with main effects and interactions)

Omnibus_GLMM_Gamma2 = joint_tests(GLMM_Gamma2)
Omnibus_GLMM_Gamma2$p.value = round(Omnibus_GLMM_Gamma2$p.value,digits=5)

# STEP 3: We compute the pairwise comparisons for the significant interactions

GLMM1_Gamma2_pairs_MMr   =  pairs(emmeans(GLMM_Gamma2,~ Modality*Motor_Region), adjust="bonferroni")
summary_Gamma2_GLMM1_MMr =  summary(GLMM1_Gamma2_pairs_MMr)

GLMM1_Gamma2_pairs_TRI   =  pairs(emmeans(GLMM_Gamma2,~ Modality*Motor_Region*Hemisphere), adjust="bonferroni")
summary_Gamma2_GLMM1_TRI =  summary(GLMM1_Gamma2_pairs_TRI)

# STEP 4: We round down all p-values

GLMM1_MMr_Result  =  adjust_pvalue(summary_Gamma2_GLMM1_MMr, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_TRI_Result  =  adjust_pvalue(summary_Gamma2_GLMM1_TRI, "p.value", "bonferroni", method = "bonferroni")

GLMM1_MMr_Result$p.value    = round(GLMM1_MMr_Result$p.value,    digits=3)
GLMM1_MMr_Result$bonferroni = round(GLMM1_MMr_Result$bonferroni, digits=3)

GLMM1_TRI_Result$p.value    = round(GLMM1_TRI_Result$p.value,    digits=3)
GLMM1_TRI_Result$bonferroni = round(GLMM1_TRI_Result$bonferroni, digits=3)

# STEP 5: We add everything into one big list called GLMM1_Delta and we remove extraneous variables

GLMM1_Gamma2 = list(Omnibus              = Omnibus_GLMM_Gamma2_2,
                    Mod_by_MR            = GLMM1_MMr_Result,
                    Mod_by_MR_by_Hem  = GLMM1_TRI_Result)

# We remove all the variables we created along the way

rm(GLMM_Gamma2,
   Omnibus_GLMM_Gamma2,
   
   GLMM1_Gamma2_pairs_MMr,
   summary_Gamma2_GLMM1_MMr,
   GLMM1_Gamma2_pairs_TRI,
   summary_Gamma2_GLMM1_TRI,
   
   GLMM1_MMr_Result,
   GLMM1_TRI_Result
)

# Uncomment this if you need to back-transform the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale
