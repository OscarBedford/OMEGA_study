library(emmeans)
library(glmmTMB)
library(rstatix)
library(optimx)

Theta_PTE <-subset(Theta, Modality!="Visual")
Theta_PTE = subset(Theta_PTE, select = -c(Musicianship,Connection, Modality))

Alpha_PTE <-subset(Alpha, Modality!="Visual")
Alpha_PTE = subset(Alpha_PTE, select = -c(Musicianship,Connection, Modality))

Beta_PTE <-subset(Beta, Modality!="Visual")
Beta_PTE = subset(Beta_PTE, select = -c(Musicianship,Connection, Modality))

#############
##  THETA  ##
#############

# We define the model

Model_Theta = glmmTMB(PTE~Hemisphere*Direction*Motor_Region+(1+Hemisphere*Direction*Motor_Region||ID),
                      data = Theta_PTE,
                      family = Gamma(link = "inverse"),
                      control = glmmTMBControl(optimizer=optimr,
                                               optArgs=list(method="L-BFGS-B"),
                                               profile = TRUE,
                                               collect = TRUE)
                      )

# We compute omnibus tests (main effects and interactions) and round the values

Omnibus_Theta = joint_tests(Model_Theta)
Omnibus_Theta$p.value = round(Omnibus_Theta$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

Theta_pairs   =  pairs(emmeans(Model_Theta,~ Direction|Motor_Region), adjust="bonferroni")
summary_Theta_pairs   =   summary(Theta_pairs)

# Correcting p values

Theta_Interaction   =  adjust_pvalue(summary_Theta_pairs, "p.value", "bonferroni", method = "bonferroni") 

Theta_Interaction$p.value    = round(Theta_Interaction$p.value,digits=3)
Theta_Interaction$bonferroni = round(Theta_Interaction$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM_Theta = list(Omnibus = Omnibus_Theta,
                   Dir_by_MotReg = Theta_Interaction)

rm()

# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

###############
# STEP 3: Alpha
###############

# We define the model

Model_Alpha = glmmTMB(PTE~Hemisphere*Direction*Motor_Region+(1+Hemisphere*Direction*Motor_Region||ID),
                      data = Alpha_PTE,
                      family = Gamma(link = "inverse"),
                      control = glmmTMBControl(optimizer=optimr,
                                               optArgs=list(method="L-BFGS-B"),
                                               profile = TRUE,
                                               collect = TRUE)
)

# We compute omnibus tests (main effects and interactions) and round the values

Omnibus_Alpha = joint_tests(Model_Alpha)
Omnibus_Alpha$p.value = round(Omnibus_Alpha$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

Alpha_pairs   =  pairs(emmeans(Model_Alpha,~ Direction|Motor_Region), adjust="bonferroni")
summary_Alpha_pairs   =   summary(Alpha_pairs)

# Correcting p values

Alpha_Interaction   =  adjust_pvalue(summary_Alpha_pairs, "p.value", "bonferroni", method = "bonferroni") 

Alpha_Interaction$p.value    = round(Alpha_Interaction$p.value,digits=3)
Alpha_Interaction$bonferroni = round(Alpha_Interaction$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM_Alpha = list(Omnibus = Omnibus_Alpha,
                  Dir_by_MotReg = Alpha_Interaction)

# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

##############
# STEP 4: Beta
##############

# Full model

Model_Beta = glmmTMB(PTE~Hemisphere*Direction*Motor_Region+(1+Hemisphere*Direction*Motor_Region||ID),
                      data = Beta_PTE,
                      family = Gamma(link = "inverse"),
                      control = glmmTMBControl(optimizer=optimr,
                                               optArgs=list(method="L-BFGS-B"),
                                               profile = TRUE,
                                               collect = TRUE)
)

# We compute omnibus tests (main effects and interactions) and round the values

Omnibus_Beta = joint_tests(Model_Beta)
Omnibus_Beta$p.value = round(Omnibus_Beta$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

Beta_pairs =  pairs(emmeans(Model_Beta,~ Direction|Motor_Region|Hemisphere), adjust="bonferroni")
summary_Beta_pairs  = summary(Beta_pairs)

# Correcting p values

Beta_Interaction   =  adjust_pvalue(summary_Beta_pairs, "p.value", "bonferroni", method = "bonferroni") 

Beta_Interaction$p.value    = round(Beta_Interaction$p.value,digits=3)
Beta_Interaction$bonferroni = round(Beta_Interaction$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM_Beta = list(Omnibus = Omnibus_Beta,
                  Hem_by_Dir_by_MotReg = Beta_Interaction)

GLMM_Beta

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

## NEW BANDS

Delta_PTE <-subset(Delta, Modality!="Visual")
Delta_PTE = subset(Delta_PTE, select = -c(Musicianship,Connection, Modality))

Gamma1_PTE <-subset(Gamma1, Modality!="Visual")
Gamma1_PTE = subset(Gamma1_PTE, select = -c(Musicianship,Connection, Modality))

Gamma2_PTE <-subset(Gamma2, Modality!="Visual")
Gamma2_PTE = subset(Gamma2_PTE, select = -c(Musicianship,Connection, Modality))

####################
#  STEP 4: Delta  ##
####################

# We define the model

Model_Delta = glmmTMB(PTE~Hemisphere*Direction*Motor_Region+(1+Hemisphere*Direction*Motor_Region||ID),
                      data = Delta_PTE,
                      family = Gamma(link = "inverse"),
                      control = glmmTMBControl(optimizer=optimr,
                                               optArgs=list(method="L-BFGS-B"),
                                               profile = TRUE,
                                               collect = TRUE)
)

# We compute omnibus tests (main effects and interactions) and round the values

Omnibus_Delta = joint_tests(Model_Delta)
Omnibus_Delta$p.value = round(Omnibus_Delta$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

Delta_pairs = pairs(emmeans(Model_Delta, ~ Motor_Region), adjust="bonferroni")
summary_Delta_pairs = summary(Delta_pairs)

# Correcting p values

Delta_Interaction   =  adjust_pvalue(summary_Delta_pairs, "p.value", "bonferroni", method = "bonferroni") 

Delta_Interaction$p.value    = round(Delta_Interaction$p.value,digits=3)
Delta_Interaction$bonferroni = round(Delta_Interaction$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM_Delta = list(Omnibus = Omnibus_Delta,
                  Dir_by_MotReg = Delta_Interaction)

###############
# STEP 5: Gamma1
###############

# We define the model

Model_Gamma1 = glmmTMB(PTE~Hemisphere*Direction*Motor_Region+(1+Hemisphere*Direction*Motor_Region||ID),
                      data = Gamma1_PTE,
                      family = Gamma(link = "inverse"),
                      control = glmmTMBControl(optimizer=optimr,
                                               optArgs=list(method="L-BFGS-B"),
                                               profile = TRUE,
                                               collect = TRUE)
)

# We compute omnibus tests (main effects and interactions) and round the values

Omnibus_Gamma1 = joint_tests(Model_Gamma1)
Omnibus_Gamma1$p.value = round(Omnibus_Gamma1$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

Gamma1_pairs            =   pairs(emmeans(Model_Gamma1,~ Direction|Motor_Region), adjust="bonferroni")
summary_Gamma1_pairs    =   summary(Gamma1_pairs)

# Correcting p values

Gamma1_Interaction   =  adjust_pvalue(summary_Gamma1_pairs, "p.value", "bonferroni", method = "bonferroni") 

Gamma1_Interaction$p.value    = round(Gamma1_Interaction$p.value,digits=3)
Gamma1_Interaction$bonferroni = round(Gamma1_Interaction$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM_Gamma1 = list(Omnibus = Omnibus_Gamma1,
                  Dir_by_MotReg = Gamma1_Interaction)

# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

################
# STEP 6: Gamma2
################

# Full model

Model_Gamma2 = glmmTMB(PTE~Hemisphere*Direction*Motor_Region+(1+Hemisphere*Direction*Motor_Region||ID),
                     data = Gamma2_PTE,
                     family = Gamma(link = "inverse"),
                     control = glmmTMBControl(optimizer=optimr,
                                              optArgs=list(method="L-BFGS-B"),
                                              profile = TRUE,
                                              collect = TRUE)
)

# We compute omnibus tests (main effects and interactions) and round the values

Omnibus_Gamma2 = joint_tests(Model_Gamma2)
Omnibus_Gamma2$p.value = round(Omnibus_Gamma2$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

Gamma2_pairs = pairs(emmeans(Model_Gamma2, ~ Motor_Region), adjust="bonferroni")
summary_Gamma2_pairs = summary(Gamma2_pairs)

Gamma2_pairs2 = pairs(emmeans(Model_Gamma2, ~ Direction), adjust="bonferroni")
summary_Gamma2_pairs2 = summary(Gamma2_pairs2)

# Correcting p values

Gamma2_Interaction   =  adjust_pvalue(summary_Gamma2_pairs, "p.value", "bonferroni", method = "bonferroni") 

Gamma2_Interaction$p.value    = round(Gamma2_Interaction$p.value,digits=3)
Gamma2_Interaction$bonferroni = round(Gamma2_Interaction$bonferroni,digits=3)

Gamma2_Interaction2   =  adjust_pvalue(summary_Gamma2_pairs2, "p.value", "bonferroni", method = "bonferroni") 

Gamma2_Interaction2$p.value    = round(Gamma2_Interaction2$p.value,digits=3)
Gamma2_Interaction2$bonferroni = round(Gamma2_Interaction2$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM_Gamma2 = list(Omnibus = Omnibus_Gamma2,
                 Hem_by_Dir_by_MotReg = Gamma2_Interaction)

GLMM_Gamma2

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

###############
# GENERATE PDFS
###############

Delta_Summary1 <- Delta %>%
  group_by(Hemisphere,Modality) %>%
  get_summary_stats(PTE, type = "mean_sd")

Delta_Boxplot_Interaction1 <- ggbarplot(
  Delta_Summary1, x = "Modality", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Delta: Barplot of 'Hemisphere*Modality' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

Delta_Summary2 <- Delta %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Delta_Boxplot_Interaction2 <- ggbarplot(
  Delta_Summary2, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Delta: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

# Theta

Theta_Summary1 <- Theta %>%
  group_by(Hemisphere,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Theta_Boxplot_Interaction1 <- ggbarplot(
  Theta_Summary1, x = "Direction", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Theta: Barplot of 'Hemisphere*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

Theta_Summary2 <- Theta %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Theta_Boxplot_Interaction2 <- ggbarplot(
  Theta_Summary2, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Theta: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)
# Alpha

Alpha_Summary1 <- Alpha %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Alpha_Boxplot_Interaction1 <- ggbarplot(
  Alpha_Summary1, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Alpha: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Beta

Beta_Summary1 <- Beta %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Beta_Summary2 <- Beta %>%
  group_by(Hemisphere) %>%
  get_summary_stats(PTE, type = "mean_sd")

Beta_Boxplot2 <- ggbarplot(
  Beta_Summary2, x = "Hemisphere", y = "mean",
  title= "Beta: Barplot of 'Hemisphere' (main effect)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  color = "black",
  fill = "white",
  label = TRUE, lab.vjust = -0.4
)

Beta_Boxplot_Interaction <- ggbarplot(
  Beta_Summary1, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Beta: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Gamma2 

Gamma2_Summary1 <- Gamma2 %>%
  group_by(Hemisphere,Modality) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Boxplot_Interaction1 <- ggbarplot(
  Gamma2_Summary1, x = "Modality", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Hemisphere*Modality' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

Gamma2_Summary2 <- Gamma2 %>%
  group_by(Hemisphere,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Boxplot_Interaction2 <- ggbarplot(
  Gamma2_Summary2, x = "Direction", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Hemisphere*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

Gamma2_Summary3 <- Gamma2 %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Boxplot_Interaction3 <- ggbarplot(
  Gamma2_Summary3, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Gamma2

Gamma2_Summary1 <- Gamma2 %>%
  group_by(Hemisphere,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Boxplot_Interaction1 <- ggbarplot(
  Gamma2_Summary1, x = "Direction", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Hemisphere*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

Gamma2_Summary2 <- Gamma2 %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Boxplot_Interaction2 <- ggbarplot(
  Gamma2_Summary2, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)


library(dplyr)



mean_S2M <- Theta %>%
  filter(Connection == "A1.dPMC", Hemisphere == "R") %>%
  summarise(mean_PTE = mean(PTE, na.rm = TRUE))

mean_M2S <- Theta %>%
  filter(Connection == "dPMC.A1", Hemisphere == "R") %>%
  summarise(mean_PTE = mean(PTE, na.rm = TRUE))