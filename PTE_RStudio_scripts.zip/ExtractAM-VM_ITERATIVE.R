## Extract AM & VM columns and create Subtraction column for each sub/hem/band

## Using sub0007/L as an example

AM_VM_LEFT = list()
AM_VM_RIGHT = list()
AM_VM = list () 

for (i in 1:89){
   
Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$LEFT$delta[4:6,c(1,3)]"))))
AM_VM_L_delta <- data.frame (Vector)
AM_VM_L_delta$Sub <- (AM_VM_L_delta$A1 - AM_VM_L_delta$V1)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$LEFT$theta[4:6,c(1,3)]"))))
AM_VM_L_theta <- data.frame (Vector)
AM_VM_L_theta$Sub <- (AM_VM_L_theta$A1 - AM_VM_L_theta$V1)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$LEFT$alpha[4:6,c(1,3)]"))))
AM_VM_L_alpha <- data.frame (Vector)
AM_VM_L_alpha$Sub <- (AM_VM_L_alpha$A1 - AM_VM_L_alpha$V1)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$LEFT$beta[4:6,c(1,3)]"))))
AM_VM_L_beta <- data.frame (Vector)
AM_VM_L_beta$Sub <- (AM_VM_L_beta$A1 - AM_VM_L_beta$V1)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$LEFT$gamma1[4:6,c(1,3)]"))))
AM_VM_L_gamma1 <- data.frame (Vector)
AM_VM_L_gamma1$Sub <- (AM_VM_L_gamma1$A1 - AM_VM_L_gamma1$V1)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$LEFT$gamma2[4:6,c(1,3)]"))))
AM_VM_L_gamma2 <- data.frame (Vector)
AM_VM_L_gamma2$Sub <- (AM_VM_L_gamma2$A1 - AM_VM_L_gamma2$V1)
rm(Vector)

## We do the same for the right hemisphere

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$RIGHT$delta[4:6,c(1,3)]"))))
AM_VM_R_delta <- data.frame (Vector)
AM_VM_R_delta$Sub <- (AM_VM_R_delta$A1 - AM_VM_R_delta$V1)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$RIGHT$theta[4:6,c(1,3)]"))))
AM_VM_R_theta <- data.frame (Vector)
AM_VM_R_theta$Sub <- (AM_VM_R_theta$A1 - AM_VM_R_theta$V1)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$RIGHT$alpha[4:6,c(1,3)]"))))
AM_VM_R_alpha <- data.frame (Vector)
AM_VM_R_alpha$Sub <- (AM_VM_R_alpha$A1 - AM_VM_R_alpha$V1)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$RIGHT$beta[4:6,c(1,3)]"))))
AM_VM_R_beta <- data.frame (Vector)
AM_VM_R_beta$Sub <- (AM_VM_R_beta$A1 - AM_VM_R_beta$V1)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$RIGHT$gamma1[4:6,c(1,3)]"))))
AM_VM_R_gamma1 <- data.frame (Vector)
AM_VM_R_gamma1$Sub <- (AM_VM_R_gamma1$A1 - AM_VM_R_gamma1$V1)
rm(Vector)

Vector <- eval(parse(text = (paste0("PLV$",SubjectNames[i],"$RIGHT$gamma2[4:6,c(1,3)]"))))
AM_VM_R_gamma2 <- data.frame (Vector)
AM_VM_R_gamma2$Sub <- (AM_VM_R_gamma2$A1 - AM_VM_R_gamma2$V1)
rm(Vector)

## We add ALL of it into a list

AM_VM_LEFT[[i]] <- list(delta = AM_VM_L_delta,
                           theta = AM_VM_L_theta,
                           alpha = AM_VM_L_alpha,
                           beta = AM_VM_L_beta,
                           gamma1 = AM_VM_L_gamma1,
                           gamma2 = AM_VM_L_gamma2)

rm (AM_VM_L_alpha,AM_VM_L_beta,AM_VM_L_delta,AM_VM_L_gamma1,AM_VM_L_gamma2,AM_VM_L_theta)

AM_VM_RIGHT[[i]] <- list(delta = AM_VM_R_delta,
                           theta = AM_VM_R_theta,
                           alpha = AM_VM_R_alpha,
                           beta = AM_VM_R_beta,
                           gamma1 = AM_VM_R_gamma1,
                           gamma2 = AM_VM_R_gamma2)

rm (AM_VM_R_alpha,AM_VM_R_beta,AM_VM_R_delta,AM_VM_R_gamma1,AM_VM_R_gamma2,AM_VM_R_theta)

AM_VM[[i]] <- list(LEFT = AM_VM_LEFT[[i]],
                      RIGHT = AM_VM_RIGHT[[i]])

}

rm (AM_VM_LEFT)
rm (AM_VM_RIGHT)
rm (i)

names(AM_VM) <- SubjectNames

## We create the ANOVA tables for the A1M1-V1M1 values

# First we will create a list that duplicates each element in SubjectNames

SubjectNames_Double = list()

for (i in 1:length(SubjectNames)){
   SubjectNames_Double[[i]] <- (rep(SubjectNames[i], 2))
}

# We need to flatten the resulting nested list into a single-layer list:

SubjectNames_Double <- lapply(rapply(SubjectNames_Double, enquote, how="unlist"), eval)

## We create the ANOVA tables for the AM-VM values

# First we will create a list that duplicates each element in SubjectNames

SubjectNames_Double = list()

for (i in 1:length(SubjectNames)){
SubjectNames_Double[[i]] <- (rep(SubjectNames[i], 2))
}

# We need to flatten the resulting nested list into a single-layer list:

SubjectNames_Double <- lapply(rapply(SubjectNames_Double, enquote, how="unlist"), eval)

# Now we need to create a list containing as many pairs of "L" & "R" as Subjects

Hemispheres <- list("L","R")
Hemispheres <- (rep(Hemispheres, length(SubjectNames)))

# Let's extract the Value of subtracting A1M1-V1M1 for each FreqBand:

Delta_SubValues <-   list()
Theta_SubValues <-   list()
Alpha_SubValues <-   list()
Beta_SubValues <-    list()
Gamma1_SubValues <-  list()
Gamma2_SubValues <-  list()

for (i in 1:length(SubjectNames)){
   Delta_SubValues[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$delta[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$delta[1,3]"))
   Theta_SubValues[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$theta[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$theta[1,3]"))
   Alpha_SubValues[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$alpha[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$alpha[1,3]"))
   Beta_SubValues[[i]] =   list(paste0("AM_VM$",SubjectNames[i],"$LEFT$beta[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$beta[1,3]"))  
   Gamma1_SubValues[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma1[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma1[1,3]"))
   Gamma2_SubValues[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma2[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma2[1,3]"))
}

Delta_SubValues <-   lapply(rapply(Delta_SubValues, enquote, how="unlist"), eval)
Theta_SubValues <-   lapply(rapply(Theta_SubValues, enquote, how="unlist"), eval)
Alpha_SubValues <-   lapply(rapply(Alpha_SubValues, enquote, how="unlist"), eval)
Beta_SubValues <-    lapply(rapply(Beta_SubValues, enquote, how="unlist"), eval)
Gamma1_SubValues <-  lapply(rapply(Gamma1_SubValues, enquote, how="unlist"), eval)
Gamma2_SubValues <-  lapply(rapply(Gamma2_SubValues, enquote, how="unlist"), eval)

for (i in 1:length(Delta_SubValues)){
   Delta_SubValues[[i]] <- (eval(parse(text=Delta_SubValues[[i]])))
   Theta_SubValues[[i]] <- (eval(parse(text=Theta_SubValues[[i]])))
   Alpha_SubValues[[i]] <- (eval(parse(text=Alpha_SubValues[[i]])))
   Beta_SubValues[[i]] <- (eval(parse(text=Beta_SubValues[[i]])))
   Gamma1_SubValues[[i]] <- (eval(parse(text=Gamma1_SubValues[[i]])))
   Gamma2_SubValues[[i]] <- (eval(parse(text=Gamma2_SubValues[[i]])))
}
   
AM_VM_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_SubValues))
AM_VM_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_SubValues))
AM_VM_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_SubValues))
AM_VM_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_SubValues))
AM_VM_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_SubValues))
AM_VM_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_SubValues))

rm (SubjectNames_Double,Hemispheres)
rm(Delta_SubValues,Theta_SubValues,Alpha_SubValues,Beta_SubValues,Gamma1_SubValues,Gamma2_SubValues)

A1M1_V1M1_Bands <- list(delta = AM_VM_Delta,
                    theta = AM_VM_Theta,
                    alpha = AM_VM_Alpha,
                    beta = AM_VM_Beta,
                    gamma1 = AM_VM_Gamma1,
                    gamma2 = AM_VM_Gamma2)

rm(AM_VM_Delta,AM_VM_Theta,AM_VM_Alpha,AM_VM_Beta,AM_VM_Gamma1,AM_VM_Gamma2)

## We create the ANOVA tables for the A1M1-A1vPMC values

# First we will create a list that duplicates each element in SubjectNames

SubjectNames_Double = list()

for (i in 1:length(SubjectNames)){
   SubjectNames_Double[[i]] <- (rep(SubjectNames[i], 2))
}

# We need to flatten the resulting nested list into a single-layer list:

SubjectNames_Double <- lapply(rapply(SubjectNames_Double, enquote, how="unlist"), eval)

# Now we need to create a list containing as many pairs of "L" & "R" as Subjects

Hemispheres <- list("L","R")
Hemispheres <- (rep(Hemispheres, length(SubjectNames)))

# Let's extract the Value of subtracting A1M1-V1M1 for each FreqBand:

Delta_SubValues <-   list()
Theta_SubValues <-   list()
Alpha_SubValues <-   list()
Beta_SubValues <-    list()
Gamma1_SubValues <-  list()
Gamma2_SubValues <-  list()

for (i in 1:length(SubjectNames)){
   Delta_SubValues[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$delta[2,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$delta[2,3]"))
   Theta_SubValues[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$theta[2,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$theta[2,3]"))
   Alpha_SubValues[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$alpha[2,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$alpha[2,3]"))
   Beta_SubValues[[i]] =   list(paste0("AM_VM$",SubjectNames[i],"$LEFT$beta[2,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$beta[2,3]"))  
   Gamma1_SubValues[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma1[2,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma1[2,3]"))
   Gamma2_SubValues[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma2[2,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma2[2,3]"))
}

Delta_SubValues <-   lapply(rapply(Delta_SubValues, enquote, how="unlist"), eval)
Theta_SubValues <-   lapply(rapply(Theta_SubValues, enquote, how="unlist"), eval)
Alpha_SubValues <-   lapply(rapply(Alpha_SubValues, enquote, how="unlist"), eval)
Beta_SubValues <-    lapply(rapply(Beta_SubValues, enquote, how="unlist"), eval)
Gamma1_SubValues <-  lapply(rapply(Gamma1_SubValues, enquote, how="unlist"), eval)
Gamma2_SubValues <-  lapply(rapply(Gamma2_SubValues, enquote, how="unlist"), eval)

for (i in 1:length(Delta_SubValues)){
   Delta_SubValues[[i]] <- (eval(parse(text=Delta_SubValues[[i]])))
   Theta_SubValues[[i]] <- (eval(parse(text=Theta_SubValues[[i]])))
   Alpha_SubValues[[i]] <- (eval(parse(text=Alpha_SubValues[[i]])))
   Beta_SubValues[[i]] <- (eval(parse(text=Beta_SubValues[[i]])))
   Gamma1_SubValues[[i]] <- (eval(parse(text=Gamma1_SubValues[[i]])))
   Gamma2_SubValues[[i]] <- (eval(parse(text=Gamma2_SubValues[[i]])))
}

AM_vPMC_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_SubValues))
AM_vPMC_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_SubValues))
AM_vPMC_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_SubValues))
AM_vPMC_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_SubValues))
AM_vPMC_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_SubValues))
AM_vPMC_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_SubValues))

rm (SubjectNames_Double,Hemispheres)
rm(Delta_SubValues,Theta_SubValues,Alpha_SubValues,Beta_SubValues,Gamma1_SubValues,Gamma2_SubValues)

A1M1_A1vPMC_Bands <- list(delta = AM_vPMC_Delta,
                        theta = AM_vPMC_Theta,
                        alpha = AM_vPMC_Alpha,
                        beta = AM_vPMC_Beta,
                        gamma1 = AM_vPMC_Gamma1,
                        gamma2 = AM_vPMC_Gamma2)

rm(AM_vPMC_Delta,AM_vPMC_Theta,AM_vPMC_Alpha,AM_vPMC_Beta,AM_vPMC_Gamma1,AM_vPMC_Gamma2)

## We create the ANOVA tables for the A1M1-A1dPMC values

SubjectNames_Double = list()

for (i in 1:length(SubjectNames)){
   SubjectNames_Double[[i]] <- (rep(SubjectNames[i], 2))
}

# We need to flatten the resulting nested list into a single-layer list:

SubjectNames_Double <- lapply(rapply(SubjectNames_Double, enquote, how="unlist"), eval)

# Now we need to create a list containing as many pairs of "L" & "R" as Subjects

Hemispheres <- list("L","R")
Hemispheres <- (rep(Hemispheres, length(SubjectNames)))

# Let's extract the Value of subtracting A1M1-V1M1 for each FreqBand:

Delta_SubValues <-   list()
Theta_SubValues <-   list()
Alpha_SubValues <-   list()
Beta_SubValues <-    list()
Gamma1_SubValues <-  list()
Gamma2_SubValues <-  list()

for (i in 1:length(SubjectNames)){
   Delta_SubValues[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$delta[3,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$delta[3,3]"))
   Theta_SubValues[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$theta[3,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$theta[3,3]"))
   Alpha_SubValues[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT$alpha[3,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$alpha[3,3]"))
   Beta_SubValues[[i]] =   list(paste0("AM_VM$",SubjectNames[i],"$LEFT$beta[3,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$beta[3,3]"))  
   Gamma1_SubValues[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma1[3,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma1[3,3]"))
   Gamma2_SubValues[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT$gamma2[3,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT$gamma2[3,3]"))
}

Delta_SubValues <-   lapply(rapply(Delta_SubValues, enquote, how="unlist"), eval)
Theta_SubValues <-   lapply(rapply(Theta_SubValues, enquote, how="unlist"), eval)
Alpha_SubValues <-   lapply(rapply(Alpha_SubValues, enquote, how="unlist"), eval)
Beta_SubValues <-    lapply(rapply(Beta_SubValues, enquote, how="unlist"), eval)
Gamma1_SubValues <-  lapply(rapply(Gamma1_SubValues, enquote, how="unlist"), eval)
Gamma2_SubValues <-  lapply(rapply(Gamma2_SubValues, enquote, how="unlist"), eval)

for (i in 1:length(Delta_SubValues)){
   Delta_SubValues[[i]] <- (eval(parse(text=Delta_SubValues[[i]])))
   Theta_SubValues[[i]] <- (eval(parse(text=Theta_SubValues[[i]])))
   Alpha_SubValues[[i]] <- (eval(parse(text=Alpha_SubValues[[i]])))
   Beta_SubValues[[i]] <- (eval(parse(text=Beta_SubValues[[i]])))
   Gamma1_SubValues[[i]] <- (eval(parse(text=Gamma1_SubValues[[i]])))
   Gamma2_SubValues[[i]] <- (eval(parse(text=Gamma2_SubValues[[i]])))
}

AM_dPMC_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_SubValues))
AM_dPMC_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_SubValues))
AM_dPMC_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_SubValues))
AM_dPMC_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_SubValues))
AM_dPMC_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_SubValues))
AM_dPMC_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_SubValues))

rm (SubjectNames_Double,Hemispheres)
rm(Delta_SubValues,Theta_SubValues,Alpha_SubValues,Beta_SubValues,Gamma1_SubValues,Gamma2_SubValues)

A1M1_A1dPMC_Bands <- list(delta = AM_dPMC_Delta,
                          theta = AM_dPMC_Theta,
                          alpha = AM_dPMC_Alpha,
                          beta = AM_dPMC_Beta,
                          gamma1 = AM_dPMC_Gamma1,
                          gamma2 = AM_dPMC_Gamma2)

rm(AM_dPMC_Delta,AM_dPMC_Theta,AM_dPMC_Alpha,AM_dPMC_Beta,AM_dPMC_Gamma1,AM_dPMC_Gamma2)

## We create the definitive ANOVA tables

ANOVA_Delta <- data.frame(A1M1_V1M1_Bands$delta,A1M1_A1vPMC_Bands$delta,A1M1_A1dPMC_Bands$delta)
ANOVA_Delta <- ANOVA_Delta[,c(1,2,3,6,9)] 
colnames(ANOVA_Delta) <- c("ID","Hemisphere","AM-VM","AM-vPMC","AM-dPMC")

ANOVA_Theta <- data.frame(A1M1_V1M1_Bands$theta,A1M1_A1vPMC_Bands$theta,A1M1_A1dPMC_Bands$theta)
ANOVA_Theta <- ANOVA_Theta[,c(1,2,3,6,9)] 
colnames(ANOVA_Theta) <- c("ID","Hemisphere","AM-VM","AM-vPMC","AM-dPMC")

ANOVA_Alpha <- data.frame(A1M1_V1M1_Bands$alpha,A1M1_A1vPMC_Bands$alpha,A1M1_A1dPMC_Bands$alpha)
ANOVA_Alpha <- ANOVA_Alpha[,c(1,2,3,6,9)] 
colnames(ANOVA_Alpha) <- c("ID","Hemisphere","AM-VM","AM-vPMC","AM-dPMC")

ANOVA_Beta <- data.frame(A1M1_V1M1_Bands$beta,A1M1_A1vPMC_Bands$beta,A1M1_A1dPMC_Bands$beta)
ANOVA_Beta <- ANOVA_Beta[,c(1,2,3,6,9)] 
colnames(ANOVA_Beta) <- c("ID","Hemisphere","AM-VM","AM-vPMC","AM-dPMC")

ANOVA_Gamma1 <- data.frame(A1M1_V1M1_Bands$gamma1,A1M1_A1vPMC_Bands$gamma1,A1M1_A1dPMC_Bands$gamma1)
ANOVA_Gamma1 <- ANOVA_Gamma1[,c(1,2,3,6,9)] 
colnames(ANOVA_Gamma1) <- c("ID","Hemisphere","AM-VM","AM-vPMC","AM-dPMC")

ANOVA_Gamma2 <- data.frame(A1M1_V1M1_Bands$gamma2,A1M1_A1vPMC_Bands$gamma2,A1M1_A1dPMC_Bands$gamma2)
ANOVA_Gamma2 <- ANOVA_Gamma2[,c(1,2,3,6,9)] 
colnames(ANOVA_Gamma2) <- c("ID","Hemisphere","AM-VM","AM-vPMC","AM-dPMC")

ANOVA_BANDS <- list(delta = ANOVA_Delta,
                    theta = ANOVA_Theta,
                    alpha = ANOVA_Alpha,
                    beta = ANOVA_Beta,
                    gamma1 = ANOVA_Gamma1,
                    gamma2 = ANOVA_Gamma2)

rm(ANOVA_Delta,
   ANOVA_Theta, 
   ANOVA_Alpha,
   ANOVA_Beta,
   ANOVA_Gamma1,
   ANOVA_Gamma2)

Musicianship <- list("Musician",
                     "Non-musician",
                     "Non-musician",
                     "Non-musician",
                     "Non-musician",
                     "Non-musician",
                     "Musician",
                     "Non-musician",
                     "N/A",
                     "Musician",
                     "N/A",
                     "N/A",
                     "Musician",
                     "N/A",
                     "Musician",
                     "Non-musician",
                     "Non-musician",
                     "Non-musician",
                     "Non-musician",
                     "N/A",
                     "Non-musician",
                     "Non-musician",
                     "Musician",
                     "N/A",
                     "Non-musician",
                     "N/A",
                     "Musician",
                     "Non-musician",
                     "N/A",
                     "Musician",
                     "Non-musician",
                     "Non-musician",
                     "Musician",
                     "Non-musician",
                     "Musician",
                     "Musician",
                     "N/A",
                     "Non-musician",
                     "Musician",
                     "Non-musician",
                     "Musician",
                     "Musician",
                     "Non-musician",
                     "Musician",
                     "Musician",
                     "Non-musician",
                     "Non-musician",
                     "Non-musician",
                     "N/A",
                     "Musician",
                     "Non-musician",
                     "Musician",
                     "Non-musician",
                     "Non-musician",
                     "Non-musician",
                     "Non-musician",
                     "Non-musician",
                     "Non-musician",
                     "Musician",
                     "Musician",
                     "Dancer",
                     "Non-musician",
                     "Musician",
                     "Dancer",
                     "Musician",
                     "Musician",
                     "Non-musician",
                     "Non-musician",
                     "Musician",
                     "Musician",
                     "Musician",
                     "Musician",
                     "Non-musician",
                     "Non-musician",
                     "N/A",
                     "N/A",
                     "Non-musician",
                     "Non-musician",
                     "Non-musician",
                     "Musician",
                     "Non-musician",
                     "Non-musician",
                     "Musician",
                     "Musician",
                     "Musician",
                     "Musician",
                     "Musician",
                     "Non-musician",
                     "Musician")

Musicianship_Double = list()

for (i in 1:length(SubjectNames)){
   Musicianship_Double[[i]] <- (rep(Musicianship[i], 2))
}

Musicianship_Double <- lapply(rapply(Musicianship_Double, enquote, how="unlist"), eval)

ANOVA_BANDS$delta$Musicianship <- Musicianship_Double
ANOVA_BANDS$theta$Musicianship <- Musicianship_Double
ANOVA_BANDS$alpha$Musicianship <- Musicianship_Double
ANOVA_BANDS$beta$Musicianship <- Musicianship_Double
ANOVA_BANDS$gamma1$Musicianship <- Musicianship_Double
ANOVA_BANDS$gamma2$Musicianship <- Musicianship_Double

rm(Musicianship, Musicianship_Double,i)
