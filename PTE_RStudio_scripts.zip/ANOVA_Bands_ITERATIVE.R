
########################################################################################
## CALCULATE AND PLOT ANOVAs BASED on ANOVA_BANDS variable created with 'ExtractAM-VM.R'
########################################################################################

###############################################
## First we extract the dataframe for each Band
###############################################

Delta <- data.frame(ANOVA_BANDS$delta)
Theta <- data.frame(ANOVA_BANDS$theta)
Alpha <- data.frame(ANOVA_BANDS$alpha)
Beta <- data.frame(ANOVA_BANDS$beta)
Gamma1 <- data.frame(ANOVA_BANDS$gamma1)
Gamma2 <- data.frame(ANOVA_BANDS$gamma2)

##################################################################################
## It's important that we transform the PLV columns from class 'list' to 'numeric'
##################################################################################

Delta$A1.M1 <- as.numeric(as.character(Delta$A1.M1))
Delta$A1.vPMC <- as.numeric(as.character(Delta$A1.vPMC))
Delta$A1.dPMC <- as.numeric(as.character(Delta$A1.dPMC))

Theta$A1.M1 <- as.numeric(as.character(Theta$A1.M1))
Theta$A1.vPMC <- as.numeric(as.character(Theta$A1.vPMC))
Theta$A1.dPMC <- as.numeric(as.character(Theta$A1.dPMC))

Alpha$A1.M1 <- as.numeric(as.character(Alpha$A1.M1))
Alpha$A1.vPMC <- as.numeric(as.character(Alpha$A1.vPMC))
Alpha$A1.dPMC <- as.numeric(as.character(Alpha$A1.dPMC))

Beta$A1.M1 <- as.numeric(as.character(Beta$A1.M1))
Beta$A1.vPMC <- as.numeric(as.character(Beta$A1.vPMC))
Beta$A1.dPMC <- as.numeric(as.character(Beta$A1.dPMC))

Gamma1$A1.M1 <- as.numeric(as.character(Gamma1$A1.M1))
Gamma1$A1.vPMC <- as.numeric(as.character(Gamma1$A1.vPMC))
Gamma1$A1.dPMC <- as.numeric(as.character(Gamma1$A1.dPMC))

Gamma2$A1.M1 <- as.numeric(as.character(Gamma2$A1.M1))
Gamma2$A1.vPMC <- as.numeric(as.character(Gamma2$A1.vPMC))
Gamma2$A1.dPMC <- as.numeric(as.character(Gamma2$A1.dPMC))

################################
## Same for the visual variables
################################

Delta$V1.M1 <- as.numeric(as.character(Delta$V1.M1))
Delta$V1.vPMC <- as.numeric(as.character(Delta$V1.vPMC))
Delta$V1.dPMC <- as.numeric(as.character(Delta$V1.dPMC))

Theta$V1.M1 <- as.numeric(as.character(Theta$V1.M1))
Theta$V1.vPMC <- as.numeric(as.character(Theta$V1.vPMC))
Theta$V1.dPMC <- as.numeric(as.character(Theta$V1.dPMC))

Alpha$V1.M1 <- as.numeric(as.character(Alpha$V1.M1))
Alpha$V1.vPMC <- as.numeric(as.character(Alpha$V1.vPMC))
Alpha$V1.dPMC <- as.numeric(as.character(Alpha$V1.dPMC))

Beta$V1.M1 <- as.numeric(as.character(Beta$V1.M1))
Beta$V1.vPMC <- as.numeric(as.character(Beta$V1.vPMC))
Beta$V1.dPMC <- as.numeric(as.character(Beta$V1.dPMC))

Gamma1$V1.M1 <- as.numeric(as.character(Gamma1$V1.M1))
Gamma1$V1.vPMC <- as.numeric(as.character(Gamma1$V1.vPMC))
Gamma1$V1.dPMC <- as.numeric(as.character(Gamma1$V1.dPMC))

Gamma2$V1.M1 <- as.numeric(as.character(Gamma2$V1.M1))
Gamma2$V1.vPMC <- as.numeric(as.character(Gamma2$V1.vPMC))
Gamma2$V1.dPMC <- as.numeric(as.character(Gamma2$V1.dPMC))

##################################################################################
## It's important that we transform the Anova factors from class 'list' to 'factor'
##################################################################################

Delta$ID <- as.factor(as.character(Delta$ID))
Delta$Hemisphere <- as.factor(as.character(Delta$Hemisphere))
Delta$Musicianship <- as.factor(as.character(Delta$Musicianship))

Theta$ID <- as.factor(as.character(Theta$ID))
Theta$Hemisphere <- as.factor(as.character(Theta$Hemisphere))
Theta$Musicianship <- as.factor(as.character(Theta$Musicianship))

Alpha$ID <- as.factor(as.character(Alpha$ID))
Alpha$Hemisphere <- as.factor(as.character(Alpha$Hemisphere))
Alpha$Musicianship <- as.factor(as.character(Alpha$Musicianship))

Beta$ID <- as.factor(as.character(Beta$ID))
Beta$Hemisphere <- as.factor(as.character(Beta$Hemisphere))
Beta$Musicianship <- as.factor(as.character(Beta$Musicianship))

Gamma1$ID <- as.factor(as.character(Gamma1$ID))
Gamma1$Hemisphere <- as.factor(as.character(Gamma1$Hemisphere))
Gamma1$Musicianship <- as.factor(as.character(Gamma1$Musicianship))

Gamma2$ID <- as.factor(as.character(Gamma2$ID))
Gamma2$Hemisphere <- as.factor(as.character(Gamma2$Hemisphere))
Gamma2$Musicianship <- as.factor(as.character(Gamma2$Musicianship))

###################################################
## We need to re-structure our tables using 'tidyr'
###################################################

# Uncomment this if you haven't installed 'tidyr' yet:
# install.packages("tidyr")

# First, we will stack all PLV rows into one column:

library(tidyr)

Delta <- pivot_longer(Delta, cols=3:8, names_to = "Motor_Region", values_to = "PLV")
Theta <- pivot_longer(Theta, cols=3:8, names_to = "Motor_Region", values_to = "PLV")
Alpha <- pivot_longer(Alpha, cols=3:8, names_to = "Motor_Region", values_to = "PLV")
Beta <- pivot_longer(Beta, cols=3:8, names_to = "Motor_Region", values_to = "PLV")
Gamma1 <- pivot_longer(Gamma1, cols=3:8, names_to = "Motor_Region", values_to = "PLV")
Gamma2 <- pivot_longer(Gamma2, cols=3:8, names_to = "Motor_Region", values_to = "PLV")

# Then we will create a new column called Modality and add it to our tables

Modality <- list("Auditory",
                 "Auditory",
                 "Auditory",
                 "Visual",
                 "Visual",
                 "Visual")

Modality <- (rep(Modality, 130))

Delta$Modality <- Modality
Theta$Modality <- Modality
Alpha$Modality <- Modality
Beta$Modality <- Modality
Gamma1$Modality <- Modality
Gamma2$Modality <- Modality

Delta$Modality <- as.factor(as.character(Delta$Modality))
Theta$Modality <- as.factor(as.character(Theta$Modality))
Alpha$Modality <- as.factor(as.character(Alpha$Modality))
Beta$Modality <- as.factor(as.character(Beta$Modality))
Gamma1$Modality <- as.factor(as.character(Gamma1$Modality))
Gamma2$Modality <- as.factor(as.character(Gamma2$Modality))

# We will re-order the columns:

Delta <- Delta[, c(1, 3, 2, 6, 4, 5)]
Theta <- Theta[, c(1, 3, 2, 6, 4, 5)]
Alpha <- Alpha[, c(1, 3, 2, 6, 4, 5)]
Beta <- Beta [, c(1, 3, 2, 6, 4, 5)]
Gamma1 <- Gamma1 [, c(1, 3, 2, 6, 4, 5)]
Gamma2 <- Gamma2 [, c(1, 3, 2, 6, 4, 5)]

# We will update the names in the Motor_Region column

Delta[Delta == 'A1.M1'] <- 'M1'
Delta[Delta == 'V1.M1'] <- 'M1'
Delta[Delta == 'A1.vPMC'] <- 'vPMC'
Delta[Delta == 'V1.vPMC'] <- 'vPMC'
Delta[Delta == 'A1.dPMC'] <- 'dPMC'
Delta[Delta == 'V1.dPMC'] <- 'dPMC'

Theta[Theta == 'A1.M1'] <- 'M1'
Theta[Theta == 'V1.M1'] <- 'M1'
Theta[Theta == 'A1.vPMC'] <- 'vPMC'
Theta[Theta == 'V1.vPMC'] <- 'vPMC'
Theta[Theta == 'A1.dPMC'] <- 'dPMC'
Theta[Theta == 'V1.dPMC'] <- 'dPMC'

Alpha[Alpha == 'A1.M1'] <- 'M1'
Alpha[Alpha == 'V1.M1'] <- 'M1'
Alpha[Alpha == 'A1.vPMC'] <- 'vPMC'
Alpha[Alpha == 'V1.vPMC'] <- 'vPMC'
Alpha[Alpha == 'A1.dPMC'] <- 'dPMC'
Alpha[Alpha == 'V1.dPMC'] <- 'dPMC'

Beta[Beta == 'A1.M1'] <- 'M1'
Beta[Beta == 'V1.M1'] <- 'M1'
Beta[Beta == 'A1.vPMC'] <- 'vPMC'
Beta[Beta == 'V1.vPMC'] <- 'vPMC'
Beta[Beta == 'A1.dPMC'] <- 'dPMC'
Beta[Beta == 'V1.dPMC'] <- 'dPMC'

Gamma1[Gamma1 == 'A1.M1'] <- 'M1'
Gamma1[Gamma1 == 'V1.M1'] <- 'M1'
Gamma1[Gamma1 == 'A1.vPMC'] <- 'vPMC'
Gamma1[Gamma1 == 'V1.vPMC'] <- 'vPMC'
Gamma1[Gamma1 == 'A1.dPMC'] <- 'dPMC'
Gamma1[Gamma1 == 'V1.dPMC'] <- 'dPMC'

Gamma2[Gamma2 == 'A1.M1'] <- 'M1'
Gamma2[Gamma2 == 'V1.M1'] <- 'M1'
Gamma2[Gamma2 == 'A1.vPMC'] <- 'vPMC'
Gamma2[Gamma2 == 'V1.vPMC'] <- 'vPMC'
Gamma2[Gamma2 == 'A1.dPMC'] <- 'dPMC'
Gamma2[Gamma2 == 'V1.dPMC'] <- 'dPMC'

# Convert Motor_Region into factor

Delta$Motor_Region <- as.factor(as.character(Delta$Motor_Region))
Theta$Motor_Region <- as.factor(as.character(Theta$Motor_Region))
Alpha$Motor_Region <- as.factor(as.character(Alpha$Motor_Region))
Beta$Motor_Region <- as.factor(as.character(Beta$Motor_Region))
Gamma1$Motor_Region <- as.factor(as.character(Gamma1$Motor_Region))
Gamma2$Motor_Region <- as.factor(as.character(Gamma2$Motor_Region))

###################################################################
## We're ready to create the aov variables, as an intermediate step
###################################################################

## NOTE: the formula is not correct yet

aov_Delta <- aov(PLV~Musicianship*Hemisphere*Modality*Motor_Region + Error(ID/(Hemisphere*Modality*Motor_Region)) + Musicianship,data=Delta)
aov_Theta <- aov(PLV~Musicianship*Hemisphere*Modality*Motor_Region,data=Theta)
aov_Alpha <- aov(PLV~Musicianship*Hemisphere*Modality*Motor_Region,data=Alpha)
aov_Beta <- aov(PLV~Musicianship*Hemisphere*Modality*Motor_Region,data=Beta)
aov_Gamma1 <- aov(PLV~Musicianship*Hemisphere*Modality*Motor_Region,data=Gamma1)
aov_Gamma2 <- aov(PLV~Musicianship*Hemisphere*Modality*Motor_Region,data=Gamma2)

Summary_Delta <- summary.aov(aov_Delta)
Summary_Theta <- summary.aov(aov_Theta)
Summary_Alpha <- summary.aov(aov_Delta)
Summary_Beta <- summary.aov(aov_Beta)
Summary_Gamma1 <- summary.aov(aov_Gamma1)
Summary_Gamma2 <- summary.aov(aov_Gamma2)

########################################################################
## Now we use the aov variables to create the definitive ANOVA variables
########################################################################

ANOVA_Delta <- anova(aov_Delta)
ANOVA_Theta <- anova(aov_Theta)
ANOVA_Alpha <- anova(aov_Alpha)
ANOVA_Beta <- anova(aov_Beta)
ANOVA_Gamma1 <- anova(aov_Gamma1)
ANOVA_Gamma2 <- anova(aov_Gamma2)

###############################
## We're finally ready to plot!
###############################

# But first we will create the pdf filename where we will save the plot:

pdf("ANOVA_6freqbands_PLV_MainEffects.pdf")

# Now we make the 18 plots (6bands*3connections) 

par(mar=c(6, 6, 6, 6))
plot(PLV~Musicianship,data=Delta, main = "Delta band: Musicianship", sub = sprintf ("p-value = %s",round(ANOVA_Delta$`Pr(>F)`[1],digits=4)))
plot(PLV~Hemisphere,data=Delta, main = "Delta band: Hemisphere", sub = sprintf ("p-value = %s",round(ANOVA_Delta$`Pr(>F)`[2],digits=4)))
plot(PLV~Modality,data=Delta, main = "Delta band: Modality", sub = sprintf ("p-value = %s",round(ANOVA_Delta$`Pr(>F)`[3],digits=4)))
plot(PLV~Motor_Region,data=Delta, main = "Delta band: Motor Region", sub = sprintf ("p-value = %s",round(ANOVA_Delta$`Pr(>F)`[4],digits=4)))

par(mar=c(6, 6, 6, 6))
plot(PLV~Musicianship,data=Theta, main = "Theta band: Musicianship", sub = sprintf ("p-value = %s",round(ANOVA_Theta$`Pr(>F)`[1],digits=4)))
plot(PLV~Hemisphere,data=Theta, main = "Theta band: Hemisphere", sub = sprintf ("p-value = %s",round(ANOVA_Theta$`Pr(>F)`[2],digits=4)))
plot(PLV~Modality,data=Theta, main = "Theta band: Modality", sub = sprintf ("p-value = %s",round(ANOVA_Theta$`Pr(>F)`[3],digits=4)))
plot(PLV~Motor_Region,data=Theta, main = "Theta band: Motor Region", sub = sprintf ("p-value = %s",round(ANOVA_Theta$`Pr(>F)`[4],digits=4)))

par(mar=c(6, 6, 6, 6))
plot(PLV~Musicianship,data=Alpha, main = "Alpha band: Musicianship", sub = sprintf ("p-value = %s",round(ANOVA_Alpha$`Pr(>F)`[1],digits=4)))
plot(PLV~Hemisphere,data=Alpha, main = "Alpha band: Hemisphere", sub = sprintf ("p-value = %s",round(ANOVA_Alpha$`Pr(>F)`[2],digits=4)))
plot(PLV~Modality,data=Alpha, main = "Alpha band: Modality", sub = sprintf ("p-value = %s",round(ANOVA_Alpha$`Pr(>F)`[3],digits=4)))
plot(PLV~Motor_Region,data=Alpha, main = "Alpha band: Motor Region", sub = sprintf ("p-value = %s",round(ANOVA_Alpha$`Pr(>F)`[4],digits=4)))

par(mar=c(6, 6, 6, 6))
plot(PLV~Musicianship,data=Beta, main = "Beta band: Musicianship", sub = sprintf ("p-value = %s",round(ANOVA_Beta$`Pr(>F)`[1],digits=4)))
plot(PLV~Hemisphere,data=Beta, main = "Beta band: Hemisphere", sub = sprintf ("p-value = %s",round(ANOVA_Beta$`Pr(>F)`[2],digits=4)))
plot(PLV~Modality,data=Beta, main = "Beta band: Modality", sub = sprintf ("p-value = %s",round(ANOVA_Beta$`Pr(>F)`[3],digits=4)))
plot(PLV~Motor_Region,data=Beta, main = "Beta band: Motor Region", sub = sprintf ("p-value = %s",round(ANOVA_Beta$`Pr(>F)`[4],digits=4)))

par(mar=c(6, 6, 6, 6))
plot(PLV~Musicianship,data=Gamma1, main = "Gamma1 band: Musicianship", sub = sprintf ("p-value = %s",round(ANOVA_Gamma1$`Pr(>F)`[1],digits=4)))
plot(PLV~Hemisphere,data=Gamma1, main = "Gamma1 band: Hemisphere", sub = sprintf ("p-value = %s",round(ANOVA_Gamma1$`Pr(>F)`[2],digits=4)))
plot(PLV~Modality,data=Gamma1, main = "Gamma1 band: Modality", sub = sprintf ("p-value = %s",round(ANOVA_Gamma1$`Pr(>F)`[3],digits=4)))
plot(PLV~Motor_Region,data=Gamma1, main = "Gamma1 band: Motor Region", sub = sprintf ("p-value = %s",round(ANOVA_Gamma1$`Pr(>F)`[4],digits=4)))

par(mar=c(6, 6, 6, 6))
plot(PLV~Musicianship,data=Gamma2, main = "Gamma2 band: Musicianship", sub = sprintf ("p-value = %s",round(ANOVA_Gamma2$`Pr(>F)`[1],digits=4)))
plot(PLV~Hemisphere,data=Gamma2, main = "Gamma2 band: Hemisphere", sub = sprintf ("p-value = %s",round(ANOVA_Gamma2$`Pr(>F)`[2],digits=4)))
plot(PLV~Modality,data=Gamma2, main = "Gamma2 band: Modality", sub = sprintf ("p-value = %s",round(ANOVA_Gamma2$`Pr(>F)`[3],digits=4)))
plot(PLV~Motor_Region,data=Gamma2, main = "Gamma2 band: Motor Region", sub = sprintf ("p-value = %s",round(ANOVA_Gamma2$`Pr(>F)`[4],digits=4)))


# To finish, we tell RStudio to save all plots in the pdf file we created earlier:

dev.off()