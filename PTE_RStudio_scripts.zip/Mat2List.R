## Transform: MATLAB matrix to RSTUDIO list

#################################
# Step 1: Importing the .mat file
#################################

# The first step is to import the raw .mat file as variable 'x' and 'y'

library(R.matlab)

  x <- readMat('/home/oscar/TEST/SCRIPTS/MATRIX/RStudioMAtrix_PLV_LEFT_sub0002.mat')
  y <- readMat('/home/oscar/TEST/SCRIPTS/MATRIX/RStudioMAtrix_PLV_RIGHT_sub0002.mat')

# We can verify that 'x' is not a matrix yet: 

     is.matrix(x) # should return value = FALSE

###########################################
# Step 2: Converting variable into a matrix
###########################################

# First we convert 'x' into a matrix called 'mat' with 6 rows and 36 columns:

matX = matrix(unlist(x),nrow = 6)
matY = matrix(unlist(y),nrow = 6)

# We can verify that 'mat' is indeed a matrix: 

     is.matrix(matX) # should return value = TRUE

# Now we need to segment 'mat' into 6 separate matrices

delta <- matX[1:6,1:6]
theta <- matX[1:6,7:12]
alpha <- matX[1:6,13:18]
beta <- matX[1:6,19:24]
gamma1 <- matX[1:6,25:30]
gamma2 <- matX[1:6,31:36]

######################################
# Step 3: Adding row and column labels
######################################

# Before we recombine these 6 matrices, let's first add the row and col labels

rownames(delta) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(theta) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(alpha) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(beta) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(gamma1) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(gamma2) <- c("A1","STG","V1","M1","vPMC","dPMC")

colnames(delta) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(theta) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(alpha) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(beta) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(gamma1) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(gamma2) <- c("A1","STG","V1","M1","vPMC","dPMC")

###############################################
# Step 4: Re-combining all matrices into a list
###############################################

PLV_LEFT_sub0002 <- list(delta = delta, # note that we're also adding names to each sub-matrix 
                          theta = theta,
                          alpha = alpha,
                          beta = beta,
                          gamma1 = gamma1,
                          gamma2 = gamma2)

# We can call any of the matrices by name using the $ sign, such as: 

    # PLV_RIGHT_sub0002$alpha

######################################
# Step 5: Deleting redundant variables
######################################

# We won't be needing x, mat, nor the individual matrices anymore 

rm(x,matX,delta,theta,alpha,beta,gamma1,gamma2)

##################################
# Step 6: Rinse and repeat for 'y'
##################################

delta <- matY[1:6,1:6]
theta <- matY[1:6,7:12]
alpha <- matY[1:6,13:18]
beta <- matY[1:6,19:24]
gamma1 <- matY[1:6,25:30]
gamma2 <- matY[1:6,31:36]

rownames(delta) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(theta) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(alpha) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(beta) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(gamma1) <- c("A1","STG","V1","M1","vPMC","dPMC")
rownames(gamma2) <- c("A1","STG","V1","M1","vPMC","dPMC")

colnames(delta) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(theta) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(alpha) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(beta) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(gamma1) <- c("A1","STG","V1","M1","vPMC","dPMC")
colnames(gamma2) <- c("A1","STG","V1","M1","vPMC","dPMC")

PLV_RIGHT_sub0002 <- list(delta = delta, # note that we're also adding names to each sub-matrix 
                         theta = theta,
                         alpha = alpha,
                         beta = beta,
                         gamma1 = gamma1,
                         gamma2 = gamma2)

rm(y,matY,delta,theta,alpha,beta,gamma1,gamma2)

################################################################  
# Step 7: Condense LEFT/RIGHT into one mega list for each subject
################################################################

# In the end we only want one variable (list) per subject, so we say:

PLV_sub0002 <- list (LEFT = PLV_LEFT_sub0002,
                     RIGHT = PLV_RIGHT_sub0002)

# Now that we have that list, we can delete the standalone LEFT and RIGHT lists:

rm(PLV_LEFT_sub0002,PLV_RIGHT_sub0002)

# Once you have one megalist for each subject, proceed to ExtractAM-VM.R
