library(emmeans)
library(glmmTMB)
library(rstatix)
library(optimx)

Theta_PTE <-subset(Theta, Modality!="Visual")
Theta_PTE_Right <-subset(Theta_PTE, Hemisphere!="L")
Theta_PTE_Left <-subset(Theta_PTE, Hemisphere!="R")
Theta_PTE_Right = subset(Theta_PTE_Right, select = -c(Musicianship,Connection, Modality,Hemisphere))
Theta_PTE_Left = subset(Theta_PTE_Left, select = -c(Musicianship,Connection, Modality,Hemisphere))

Alpha_PTE <-subset(Alpha, Modality!="Visual")
Alpha_PTE_Right <-subset(Alpha_PTE, Hemisphere!="L")
Alpha_PTE_Left <-subset(Alpha_PTE, Hemisphere!="R")
Alpha_PTE_Right = subset(Alpha_PTE_Right, select = -c(Musicianship,Connection, Modality,Hemisphere))
Alpha_PTE_Left = subset(Alpha_PTE_Left, select = -c(Musicianship,Connection, Modality,Hemisphere))

Beta_PTE <-subset(Beta, Modality!="Visual")
Beta_PTE_Right <-subset(Beta_PTE, Hemisphere!="L")
Beta_PTE_Left <-subset(Beta_PTE, Hemisphere!="R")
Beta_PTE_Right = subset(Beta_PTE_Right, select = -c(Musicianship,Connection, Modality,Hemisphere))
Beta_PTE_Left = subset(Beta_PTE_Left, select = -c(Musicianship,Connection, Modality,Hemisphere))

###############
# STEP 1: DELTA
###############

# Full model

GLMM_Delta= glmmTMB(PTE~Musicianship*Hemisphere*Modality*Direction+(1+Hemisphere*Modality*Direction||ID),
                    data = Delta,
                    family = Gamma(link = "inverse"))

# Repeated measures model

GLMM_Delta_2= glmmTMB(PTE~Hemisphere*Modality*Direction*Motor_Region+(1+Hemisphere*Modality*Direction*Motor_Region||ID),
                      data = Delta,
                      family = Gamma(link = "inverse"),
                      control = glmmTMBControl(optimizer=optim,
                                               optArgs=list(method="BFGS"))
)

# Create grid

ref <- emmeans(GLMM_Delta,specs = c("Hemisphere", "Modality", "Direction"))

# Compute omnibus test (main effects and interactions)

Omnibus_GLMM_Delta    = joint_tests(GLMM_Delta)
Omnibus_GLMM_Delta_2  = joint_tests(GLMM_Delta_2)
Omnibus_GLMM_Delta_2$p.value = round(Omnibus_GLMM_Delta_2$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

GLMM1_Delta_pairs_HM   =   pairs(emmeans(GLMM_Delta,~ Hemisphere|Modality), adjust="bonferroni")
summary_Delta_GLMM1_HM =   summary(GLMM1_Delta_pairs_HM)

GLMM1_Delta_pairs_MDir   =  pairs(emmeans(GLMM_Delta,~ Modality|Direction), adjust="bonferroni")
summary_Delta_GLMM1_MDir =  summary(GLMM1_Delta_pairs_MDir)

GLMM1_Delta_pairs_TRI   =   pairs(emmeans(GLMM_Delta,~ Hemisphere|Modality|Direction), adjust="bonferroni")
summary_Delta_GLMM1_TRI =   summary(GLMM1_Delta_pairs_TRI)

# Correcting p values

GLMM1_HM_Result   =  adjust_pvalue(summary_Delta_GLMM1_HM, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_MDir_Result  =  adjust_pvalue(summary_Delta_GLMM1_MDir, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_TRI_Result  =  adjust_pvalue(summary_Delta_GLMM1_TRI, "p.value", "bonferroni", method = "bonferroni")

GLMM1_HM_Result$p.value    = round(GLMM1_HM_Result$p.value,digits=3)
GLMM1_HM_Result$bonferroni = round(GLMM1_HM_Result$bonferroni,digits=3)

GLMM1_MDir_Result$p.value    = round(GLMM1_MDir_Result$p.value,digits=3)
GLMM1_MDir_Result$bonferroni = round(GLMM1_MDir_Result$bonferroni,digits=3)

GLMM1_TRI_Result$p.value    = round(GLMM1_TRI_Result$p.value,digits=3)
GLMM1_TRI_Result$bonferroni = round(GLMM1_TRI_Result$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM1_Delta = list(Omnibus = Omnibus_GLMM_Delta,
                   Hem_by_Mod = GLMM1_HM_Result,
                   Mod_by_Dir = GLMM1_MDir_Result,
                   Hem_by_Mod_by_Dir = GLMM1_TRI_Result)

rm(GLMM_Delta,Omnibus_GLMM_Delta,GLMM1_Delta_pairs_HM,
   summary_Delta_GLMM1_HM,GLMM1_Delta_pairs_MDir,summary_Delta_GLMM1_MDir,
   GLMM1_HM_Result,GLMM1_MDir_Result,GLMM1_Delta_pairs_TRI,summary_Delta_GLMM1_TRI,
   GLMM1_TRI_Result)

# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

###############
# STEP 2: THETA
###############

# We define the model

Model_Theta_Right = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                      data = Theta_PTE_Right,
                      family = Gamma(link = "inverse"),
                      control = glmmTMBControl(optimizer=optimr,
                                               optArgs=list(method="L-BFGS-B"),
                                               profile = TRUE,
                                               collect = TRUE)
                      )

Model_Theta_Left = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                            data = Theta_PTE_Left,
                            family = Gamma(link = "inverse"),
                            control = glmmTMBControl(optimizer=optimr,
                                                     optArgs=list(method="L-BFGS-B"),
                                                     profile = TRUE,
                                                     collect = TRUE)
)

# We compute omnibus tests (main effects and interactions) and round the values

Omnibus_Theta_Right = joint_tests(Model_Theta_Right)
Omnibus_Theta_Right$p.value = round(Omnibus_Theta_Right$p.value,digits=5)

Omnibus_Theta_Left = joint_tests(Model_Theta_Left)
Omnibus_Theta_Left$p.value = round(Omnibus_Theta_Left$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

Theta_Right_pairs   =  pairs(emmeans(Model_Theta_Right,~ Direction|Motor_Region), adjust="bonferroni")
summary_Theta_Right_pairs =   summary(Theta_Right_pairs)

# Correcting p values

Theta_Right_Interaction   =  adjust_pvalue(summary_Theta_Right_pairs, "p.value", "bonferroni", method = "bonferroni") 

Theta_Right_Interaction$p.value    = round(Theta_Right_Interaction$p.value,digits=3)
Theta_Right_Interaction$bonferroni = round(Theta_Right_Interaction$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM_Theta_Right = list(Omnibus = Omnibus_Theta_Right,
                   Dir_by_MotReg = Theta_Right_Interaction)

rm()

# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

###############
# STEP 3: Alpha
###############

# Full model

Model_Alpha_Right = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                            data = Alpha_PTE_Right,
                            family = Gamma(link = "inverse"),
                            control = glmmTMBControl(optimizer=optimr,
                                                     optArgs=list(method="L-BFGS-B", nIter = 1000 ),
                                                     profile = TRUE,
                                                     collect = TRUE)
)

Model_Alpha_Left = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                           data = Alpha_PTE_Left,
                           family = Gamma(link = "inverse"),
                           control = glmmTMBControl(optimizer=optimr,
                                                    optArgs=list(method="L-BFGS-B", nIter = 5000),
                                                    profile = TRUE,
                                                    collect = TRUE)
)

# We compute omnibus tests (main effects and interactions) and round the values

Omnibus_Alpha_Right = joint_tests(Model_Alpha_Right)
Omnibus_Alpha_Right$p.value = round(Omnibus_Alpha_Right$p.value,digits=5)

Omnibus_Alpha_Left = joint_tests(Model_Alpha_Left)
Omnibus_Alpha_Left$p.value = round(Omnibus_Alpha_Left$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

Alpha_Right_pairs   =  pairs(emmeans(Model_Alpha_Right,~ Direction|Motor_Region), adjust="bonferroni")
summary_Alpha_Right_pairs =   summary(Alpha_Right_pairs)

# Correcting p values

Alpha_Right_Interaction   =  adjust_pvalue(summary_Alpha_Right_pairs, "p.value", "bonferroni", method = "bonferroni") 

Alpha_Right_Interaction$p.value    = round(Alpha_Right_Interaction$p.value,digits=3)
Alpha_Right_Interaction$bonferroni = round(Alpha_Right_Interaction$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM_Alpha_Right = list(Omnibus = Omnibus_Alpha_Right,
                        Dir_by_MotReg = Alpha_Right_Interaction)

# Compute pairwise comparisons for significant interactions 

Alpha_Left_pairs   =  pairs(emmeans(Model_Alpha_Left,~ Direction|Motor_Region), adjust="bonferroni")
summary_Alpha_Left_pairs =   summary(Alpha_Left_pairs)

# Correcting p values

Alpha_Left_Interaction   =  adjust_pvalue(summary_Alpha_Left_pairs, "p.value", "bonferroni", method = "bonferroni") 

Alpha_Left_Interaction$p.value    = round(Alpha_Left_Interaction$p.value,digits=3)
Alpha_Left_Interaction$bonferroni = round(Alpha_Left_Interaction$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM_Alpha_Left = list(Omnibus = Omnibus_Alpha_Left,
                        Dir_by_MotReg = Alpha_Left_Interaction)

# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

##############
# STEP 4: Beta
##############

# Full model

Model_Beta_Right = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                            data = Beta_PTE_Right,
                            family = Gamma(link = "inverse"),
                            control = glmmTMBControl(optimizer=optimr,
                                                     optArgs=list(method="L-BFGS-B", nIter = 5000),
                                                     profile = TRUE,
                                                     collect = TRUE)
)

Model_Beta_Left = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                           data = Beta_PTE_Left,
                           family = Gamma(link = "inverse"),
                           control = glmmTMBControl(optimizer=optimr,
                                                    optArgs=list(method="L-BFGS-B", nIter = 5000),
                                                    profile = TRUE,
                                                    collect = TRUE)
)

# We compute omnibus tests (main effects and interactions) and round the values

Omnibus_Beta_Right = joint_tests(Model_Beta_Right)
Omnibus_Beta_Right$p.value = round(Omnibus_Beta_Right$p.value,digits=5)

Omnibus_Beta_Left = joint_tests(Model_Beta_Left)
Omnibus_Beta_Left$p.value = round(Omnibus_Beta_Left$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

Beta_Right_pairs   =  pairs(emmeans(Model_Beta_Right,~ Direction|Motor_Region), adjust="bonferroni")
summary_Beta_Right_pairs =   summary(Beta_Right_pairs)

# Correcting p values

Beta_Right_Interaction   =  adjust_pvalue(summary_Beta_Right_pairs, "p.value", "bonferroni", method = "bonferroni") 

Beta_Right_Interaction$p.value    = round(Beta_Right_Interaction$p.value,digits=3)
Beta_Right_Interaction$bonferroni = round(Beta_Right_Interaction$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM_Beta_Right = list(Omnibus = Omnibus_Beta_Right,
                        Dir_by_MotReg = Beta_Right_Interaction)

# Compute pairwise comparisons for significant interactions 

Beta_Left_pairs   =  pairs(emmeans(Model_Beta_Left,~ Direction|Motor_Region), adjust="bonferroni")
summary_Beta_Left_pairs =   summary(Beta_Left_pairs)

# Correcting p values

Beta_Left_Interaction   =  adjust_pvalue(summary_Beta_Left_pairs, "p.value", "bonferroni", method = "bonferroni") 

Beta_Left_Interaction$p.value    = round(Beta_Left_Interaction$p.value,digits=5)
Beta_Left_Interaction$bonferroni = round(Beta_Left_Interaction$bonferroni,digits=5)

# Add everything into one big list and remove extraneous variables

GLMM_Beta_Left = list(Omnibus = Omnibus_Beta_Left,
                       Dir_by_MotReg = Beta_Left_Interaction)

# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

################
# STEP 5: Gamma1
################

# Full model

GLMM_Gamma2= glmmTMB(PTE~Musicianship*Hemisphere*Modality*Direction+(1+Hemisphere*Modality*Direction||ID),
                    data = Gamma2,
                    family = Gamma(link = "inverse"))

# Repeated measures model

GLMM_Gamma1_2= glmmTMB(PTE~Hemisphere*Modality*Direction+(1+Hemisphere*Modality*Direction||ID),
                      data = Gamma1,
                      family = Gamma(link = "inverse"),
                      control = glmmTMBControl(optimizer=optim,
                                               optArgs=list(method="BFGS"))
)

# Create grid

ref <- emmeans(GLMM_Gamma2_2,specs = c("Hemisphere", "Modality", "Direction"))

# Compute omnibus test (main effects and interactions)

(Omnibus_GLMM_Gamma2 = joint_tests(GLMM_Gamma2))
Omnibus_GLMM_Gamma1_2 = joint_tests(GLMM_Gamma1_2)
Omnibus_GLMM_Gamma2_2$p.value = round(Omnibus_GLMM_Gamma2_2$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

GLMM1_Gamma2_pairs_HM   =   pairs(emmeans(GLMM_Gamma2,~ Hemisphere|Modality), adjust="bonferroni")
summary_Gamma2_GLMM1_HM =   summary(GLMM1_Gamma2_pairs_HM)

GLMM1_Gamma2_pairs_MDir   =  pairs(emmeans(GLMM_Gamma2,~ Modality|Direction), adjust="bonferroni")
summary_Gamma2_GLMM1_MDir =  summary(GLMM1_Gamma2_pairs_MDir)

GLMM1_Gamma2_pairs_TRI   =  pairs(emmeans(GLMM_Gamma2,~ Hemisphere|Modality|Direction), adjust="bonferroni")
summary_Gamma2_GLMM1_TRI =  summary(GLMM1_Gamma2_pairs_TRI)

# Correcting p values

GLMM1_HM_Result   =  adjust_pvalue(summary_Gamma2_GLMM1_HM, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_MDir_Result  =  adjust_pvalue(summary_Gamma2_GLMM1_MDir, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_TRI_Result  =  adjust_pvalue(summary_Gamma2_GLMM1_TRI, "p.value", "bonferroni", method = "bonferroni") 

GLMM1_HM_Result$p.value    = round(GLMM1_HM_Result$p.value,digits=3)
GLMM1_HM_Result$bonferroni = round(GLMM1_HM_Result$bonferroni,digits=3)

GLMM1_MDir_Result$p.value    = round(GLMM1_MDir_Result$p.value,digits=3)
GLMM1_MDir_Result$bonferroni = round(GLMM1_MDir_Result$bonferroni,digits=3)

GLMM1_TRI_Result$p.value    = round(GLMM1_TRI_Result$p.value,digits=3)
GLMM1_TRI_Result$bonferroni = round(GLMM1_TRI_Result$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM1_Gamma2 = list(Omnibus           = Omnibus_GLMM_Gamma2,
                    Hem_by_Mod        = GLMM1_HM_Result,
                    Mod_by_Dir         = GLMM1_MDir_Result,
                    Hem_by_Mod_by_Dir  = GLMM1_TRI_Result)

rm(GLMM_Gamma2,Omnibus_GLMM_Gamma2,GLMM1_Gamma2_pairs_HM,
   summary_Gamma2_GLMM1_HM,GLMM1_Gamma2_pairs_MDir,summary_Gamma2_GLMM1_MDir,
   GLMM1_HM_Result,GLMM1_MDir_Result, GLMM1_TRI_Result,summary_Gamma2_GLMM1_TRI,
   GLMM1_Gamma2_pairs_TRI)
# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

################
# STEP 6: GAMMA2
################

GLMM_Gamma2= glmmTMB(PTE~Musicianship*Hemisphere*Modality*Direction+(1+Hemisphere*Modality*Direction||ID),
                     data = Gamma2_no_outliers,
                     family = Gamma(link = "inverse"),
                     control=glmmTMBControl(optCtrl=list(iter.max=1e3,eval.max=1e3)))

# Full model


GLMM_Gamma2= glmmTMB(PTE~Musicianship*Hemisphere*Modality*Direction+(1|ID),
                     data = Gamma2,
                     family = Gamma(link = "inverse"),
                     control = glmmTMBControl(optimizer=nlminb,
                                              optArgs=list(method="BFGS"))
)

# Repeated measures model

GLMM_Gamma2_2= glmmTMB(PTE~Hemisphere*Modality*Direction+(1+Hemisphere*Modality*Direction||ID),
                       data = Gamma2,
                       family = Gamma(link = "inverse"),
                       control = glmmTMBControl(optimizer=optim,
                                                optArgs=list(method="BFGS"))
)

# Create grid

ref <- emmeans(GLMM_Gamma2,specs = c("Hemisphere", "Modality", "Direction"))

# Compute omnibus test (main effects and interactions)

(Omnibus_GLMM_Gamma2 = joint_tests(GLMM_Gamma2))
Omnibus_GLMM_Gamma2_2 = joint_tests(GLMM_Gamma2_2)
Omnibus_GLMM_Gamma2$p.value = round(Omnibus_GLMM_Gamma2$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

GLMM1_Gamma2_pairs_HDir   =   pairs(emmeans(GLMM_Gamma2,~ Hemisphere|Direction), adjust="bonferroni")
summary_Gamma2_GLMM1_HDir =   summary(GLMM1_Gamma2_pairs_HDir)

GLMM1_Gamma2_pairs_MDir   =  pairs(emmeans(GLMM_Gamma2,~ Modality|Direction), adjust="bonferroni")
summary_Gamma2_GLMM1_MDir =  summary(GLMM1_Gamma2_pairs_MDir)

GLMM1_Gamma2_pairs_TRI   =  pairs(emmeans(GLMM_Gamma2,~ Hemisphere|Modality|Direction), adjust="bonferroni")
summary_Gamma2_GLMM1_TRI =  summary(GLMM1_Gamma2_pairs_TRI)

# Correcting p values

GLMM1_HDir_Result   =  adjust_pvalue(summary_Gamma2_GLMM1_HDir, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_MDir_Result  =  adjust_pvalue(summary_Gamma2_GLMM1_MDir, "p.value", "bonferroni", method = "bonferroni") 
GLMM1_TRI_Result  =  adjust_pvalue(summary_Gamma2_GLMM1_TRI, "p.value", "bonferroni", method = "bonferroni") 

GLMM1_HDir_Result$p.value    = round(GLMM1_HDir_Result$p.value,digits=3)
GLMM1_HDir_Result$bonferroni = round(GLMM1_HDir_Result$bonferroni,digits=3)

GLMM1_MDir_Result$p.value    = round(GLMM1_MDir_Result$p.value,digits=3)
GLMM1_MDir_Result$bonferroni = round(GLMM1_MDir_Result$bonferroni,digits=3)

GLMM1_TRI_Result$p.value    = round(GLMM1_TRI_Result$p.value,digits=3)
GLMM1_TRI_Result$bonferroni = round(GLMM1_TRI_Result$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables
 
GLMM1_Gamma2 = list(Omnibus          = Omnibus_GLMM_Gamma2,
                    Hem_by_Dir        = GLMM1_HDir_Result,
                    Mod_by_Dir         = GLMM1_MDir_Result,
                    Hem_by_Mod_by_Dir  = GLMM1_TRI_Result)

rm(GLMM_Gamma2,Omnibus_GLMM_Gamma2,GLMM1_Gamma2_pairs_HM,
   summary_Gamma2_GLMM1_HM,GLMM1_Gamma2_pairs_MDir,summary_Gamma2_GLMM1_MDir,
   GLMM1_HM_Result,GLMM1_MDir_Result, GLMM1_TRI_Result,summary_Gamma2_GLMM1_TRI,
   GLMM1_Gamma2_pairs_TRI)

# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

# Plot main effects and post-hocs 

###############
# GENERATE PDFS
###############

Delta_Summary1 <- Delta %>%
  group_by(Hemisphere,Modality) %>%
  get_summary_stats(PTE, type = "mean_sd")

Delta_Boxplot_Interaction1 <- ggbarplot(
  Delta_Summary1, x = "Modality", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Delta: Barplot of 'Hemisphere*Modality' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

Delta_Summary2 <- Delta %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Delta_Boxplot_Interaction2 <- ggbarplot(
  Delta_Summary2, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Delta: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

# Theta

Theta_Summary1 <- Theta %>%
  group_by(Hemisphere,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Theta_Boxplot_Interaction1 <- ggbarplot(
  Theta_Summary1, x = "Direction", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Theta: Barplot of 'Hemisphere*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

Theta_Summary2 <- Theta %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Theta_Boxplot_Interaction2 <- ggbarplot(
  Theta_Summary2, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Theta: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)
# Alpha

Alpha_Summary1 <- Alpha %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Alpha_Boxplot_Interaction1 <- ggbarplot(
  Alpha_Summary1, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Alpha: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Beta

Beta_Summary1 <- Beta %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Beta_Summary2 <- Beta %>%
  group_by(Hemisphere) %>%
  get_summary_stats(PTE, type = "mean_sd")

Beta_Boxplot2 <- ggbarplot(
  Beta_Summary2, x = "Hemisphere", y = "mean",
  title= "Beta: Barplot of 'Hemisphere' (main effect)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  color = "black",
  fill = "white",
  label = TRUE, lab.vjust = -0.4
)

Beta_Boxplot_Interaction <- ggbarplot(
  Beta_Summary1, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Beta: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Gamma2 

Gamma2_Summary1 <- Gamma2 %>%
  group_by(Hemisphere,Modality) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Boxplot_Interaction1 <- ggbarplot(
  Gamma2_Summary1, x = "Modality", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Hemisphere*Modality' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

Gamma2_Summary2 <- Gamma2 %>%
  group_by(Hemisphere,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Boxplot_Interaction2 <- ggbarplot(
  Gamma2_Summary2, x = "Direction", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Hemisphere*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

Gamma2_Summary3 <- Gamma2 %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Boxplot_Interaction3 <- ggbarplot(
  Gamma2_Summary3, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Gamma2

Gamma2_Summary1 <- Gamma2 %>%
  group_by(Hemisphere,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Boxplot_Interaction1 <- ggbarplot(
  Gamma2_Summary1, x = "Direction", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Hemisphere*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

Gamma2_Summary2 <- Gamma2 %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Boxplot_Interaction2 <- ggbarplot(
  Gamma2_Summary2, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)
