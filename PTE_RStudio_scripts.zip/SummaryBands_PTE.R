# STEP 0: We load the required libraries

library(tidyverse)
library(rstatix)
library(ggpubr)

# STEP 1.1: We Identify the outliers

Delta_outliers <- Delta %>%
  identify_outliers(PTE)

Theta_outliers <- Theta %>%
  identify_outliers(PTE)

Alpha_outliers <- Alpha %>%
  identify_outliers(PTE)

Beta_outliers <- Beta %>%
  identify_outliers(PTE)

Gamma1_outliers <- Gamma1 %>%
  identify_outliers(PTE)

Gamma2_outliers <- Gamma2 %>%
  identify_outliers(PTE)

Outliers_Bands = list(Delta = Delta_outliers,
                      Theta = Theta_outliers,
                      Alpha = Alpha_outliers,
                      Beta = Beta_outliers,
                      Gamma1 = Gamma1_outliers,
                      Gamma2 = Gamma2_outliers)

rm(Delta_outliers, Theta_outliers, Alpha_outliers, Beta_outliers, Gamma1_outliers, Gamma2_outliers)

# Step 1.2: Removing outliers from the data

Q1 <- quantile(Delta$PTE, .25)
Q3 <- quantile(Delta$PTE, .75)
IQR <- IQR(Delta$PTE)
Delta_no_outliers = subset(Delta, Delta$PTE > (Q1 - 1.5*IQR) & Delta$PTE < (Q3 + 1.5*IQR))

Q1 <- quantile(Theta$PTE, .25)
Q3 <- quantile(Theta$PTE, .75)
IQR <- IQR(Theta$PTE)
Theta_no_outliers = subset(Theta, Theta$PTE > (Q1 - 1.5*IQR) & Theta$PTE < (Q3 + 1.5*IQR))

Q1 <- quantile(Alpha$PTE, .25)
Q3 <- quantile(Alpha$PTE, .75)
IQR <- IQR(Alpha$PTE)
Alpha_no_outliers = subset(Alpha, Alpha$PTE > (Q1 - 1.5*IQR) & Alpha$PTE < (Q3 + 1.5*IQR))

Q1 <- quantile(Beta$PTE, .25)
Q3 <- quantile(Beta$PTE, .75)
IQR <- IQR(Beta$PTE)
Beta_no_outliers = subset(Beta, Beta$PTE > (Q1 - 1.5*IQR) & Beta$PTE < (Q3 + 1.5*IQR))

Q1 <- quantile(Gamma1$PTE, .25)
Q3 <- quantile(Gamma1$PTE, .75)
IQR <- IQR(Gamma1$PTE)
Gamma1_no_outliers = subset(Gamma1, Gamma1$PTE > (Q1 - 1.5*IQR) & Gamma1$PTE < (Q3 + 1.5*IQR))

Q1 <- quantile(Gamma2$PTE, .25)
Q3 <- quantile(Gamma2$PTE, .75)
IQR <- IQR(Gamma2$PTE)
Gamma2_no_outliers = subset(Gamma2, Gamma2$PTE > (Q1 - 1.5*IQR) & Gamma2$PTE < (Q3 + 1.5*IQR))

# STEP 2: Summary statistics

Delta_Summary1 <- Delta %>%
  group_by(Musicianship,Hemisphere,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Delta_Summary1$n <- as.numeric(as.character(Delta_Summary1$n)) / 6

Delta_Summary2 <- Delta %>%
  group_by(Motor_Region,Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Delta_Summary2$n <- as.numeric(as.character(Delta_Summary2$n)) / 2

Delta_Summary = list(Musicianship = Delta_Summary1, Modality = Delta_Summary2)

rm(Delta_Summary2,Delta_Summary1)

Theta_Summary1 <- Theta %>%
  group_by(Musicianship,Hemisphere,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Theta_Summary1$n <- as.numeric(as.character(Theta_Summary1$n)) / 6

Theta_Summary2 <- Theta %>%
  group_by(Motor_Region,Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Theta_Summary2$n <- as.numeric(as.character(Theta_Summary2$n)) / 2

Theta_Summary = list(Musicianship = Theta_Summary1, Modality = Theta_Summary2)

rm(Theta_Summary2,Theta_Summary1)

Alpha_Summary1 <- Alpha %>%
  group_by(Musicianship,Hemisphere,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Alpha_Summary1$n <- as.numeric(as.character(Alpha_Summary1$n)) / 6

Alpha_Summary2 <- Alpha %>%
  group_by(Motor_Region,Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Alpha_Summary2$n <- as.numeric(as.character(Alpha_Summary2$n)) / 2

Alpha_Summary = list(Musicianship = Alpha_Summary1, Modality = Alpha_Summary2)

rm(Alpha_Summary2,Alpha_Summary1)

Beta_Summary1 <- Beta %>%
  group_by(Musicianship,Hemisphere,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Beta_Summary1$n <- as.numeric(as.character(Beta_Summary1$n)) / 6

Beta_Summary2 <- Beta %>%
  group_by(Motor_Region,Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Beta_Summary2$n <- as.numeric(as.character(Beta_Summary2$n)) / 2

Beta_Summary = list(Musicianship = Beta_Summary1, Modality = Beta_Summary2)

rm(Beta_Summary2,Beta_Summary1)

Gamma1_Summary1 <- Gamma1 %>%
  group_by(Musicianship,Hemisphere,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma1_Summary1$n <- as.numeric(as.character(Gamma1_Summary1$n)) / 6

Gamma1_Summary2 <- Gamma1 %>%
  group_by(Motor_Region,Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma1_Summary2$n <- as.numeric(as.character(Gamma1_Summary2$n)) / 2

Gamma1_Summary = list(Musicianship = Gamma1_Summary1, Modality = Gamma1_Summary2)

rm(Gamma1_Summary2,Gamma1_Summary1)

Gamma2_Summary1 <- Gamma2 %>%
  group_by(Musicianship,Hemisphere,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Summary1$n <- as.numeric(as.character(Gamma2_Summary1$n)) / 6

Gamma2_Summary2 <- Gamma2 %>%
  group_by(Motor_Region,Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Summary2$n <- as.numeric(as.character(Gamma2_Summary2$n)) / 2

Gamma2_Summary = list(Musicianship = Gamma2_Summary1, Modality = Gamma2_Summary2)

rm(Gamma2_Summary2,Gamma2_Summary1)

# STEP 3: Boxplots

Delta_Boxplot1 <- ggboxplot(
     Delta, x = "Musicianship", y = "PTE",
     color = "Hemisphere", palette = "jco",
     facet.by = "Modality", short.panel.labs = FALSE,
     title= "Delta: Boxplot of 'Musicianship/Hemisphere/Modality' BEFORE outlier removal",
     )

Delta_Boxplot2 <- ggboxplot(
     Delta, x = "Direction", y = "PTE",
     color = "Hemisphere", palette = "jco",
     facet.by = "Modality", short.panel.labs = FALSE,
     title= "Delta: Boxplot of 'Direction/Hemisphere/Modality' BEFORE outlier removal",
     )

Delta_Boxplot3 <- ggboxplot(
  Delta, x = "Direction", y = "PTE",
  color = "Modality", palette = "jco",
  facet.by = "Motor_Region", short.panel.labs = FALSE,
  title= "Delta: Boxplot of 'Modality/Direction/Motor_region' BEFORE outlier removal",
)

Delta_Clean_Boxplot1 <- ggboxplot(
  Delta_no_outliers, x = "Musicianship", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Delta: Boxplot of 'Musicianship/Hemisphere/Modality' AFTER outlier removal",
)

Delta_Clean_Boxplot2 <- ggboxplot(
  Delta_no_outliers, x = "Direction", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Delta: Boxplot of 'Direction/Hemisphere/Modality' AFTER outlier removal",
)

Delta_Clean_Boxplot3 <- ggboxplot(
  Delta_no_outliers, x = "Direction", y = "PTE",
  color = "Modality", palette = "jco",
  facet.by = "Motor_Region", short.panel.labs = FALSE,
  title= "Delta: Boxplot of 'Modality/Direction/Motor_region' AFTER outlier removal",
)

Delta_Boxplots = list(Musicianship_BEFORE = Delta_Boxplot1, 
                      Musicianship_AFTER = Delta_Clean_Boxplot1, 
                      Direction_BEFORE = Delta_Boxplot2,
                      Direction_AFTER = Delta_Clean_Boxplot2,
                      MotorRegion_BEFORE = Delta_Boxplot3,
                      MotorRegion_AFTER = Delta_Clean_Boxplot3)

rm (Delta_Boxplot1,Delta_Boxplot2,Delta_Boxplot3,
    Delta_Clean_Boxplot1,Delta_Clean_Boxplot2, Delta_Clean_Boxplot3)

Theta_Boxplot1 <- ggboxplot(
  Theta, x = "Musicianship", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Theta: Boxplot of 'Musicianship/Hemisphere/Modality' BEFORE outlier removal",
)

Theta_Boxplot2 <- ggboxplot(
  Theta, x = "Direction", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Theta: Boxplot of 'Direction/Hemisphere/Modality' BEFORE outlier removal",
)

Theta_Boxplot3 <- ggboxplot(
  Theta, x = "Direction", y = "PTE",
  color = "Modality", palette = "jco",
  facet.by = "Motor_Region", short.panel.labs = FALSE,
  title= "Theta: Boxplot of 'Modality/Direction/Motor_region' BEFORE outlier removal",
)

Theta_Clean_Boxplot1 <- ggboxplot(
  Theta_no_outliers, x = "Musicianship", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Theta: Boxplot of 'Musicianship/Hemisphere/Modality' AFTER outlier removal",
)

Theta_Clean_Boxplot2 <- ggboxplot(
  Theta_no_outliers, x = "Direction", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Theta: Boxplot of 'Direction/Hemisphere/Modality' AFTER outlier removal",
)

Theta_Clean_Boxplot3 <- ggboxplot(
  Theta_no_outliers, x = "Direction", y = "PTE",
  color = "Modality", palette = "jco",
  facet.by = "Motor_Region", short.panel.labs = FALSE,
  title= "Theta: Boxplot of 'Modality/Direction/Motor_region' AFTER outlier removal",
)

Theta_Boxplots = list(Musicianship_BEFORE = Theta_Boxplot1, 
                      Musicianship_AFTER = Theta_Clean_Boxplot1, 
                      Direction_BEFORE = Theta_Boxplot2,
                      Direction_AFTER = Theta_Clean_Boxplot2,
                      MotorRegion_BEFORE = Theta_Boxplot3,
                      MotorRegion_AFTER = Theta_Clean_Boxplot3)

rm (Theta_Boxplot1,Theta_Boxplot2,Theta_Boxplot3,
    Theta_Clean_Boxplot1,Theta_Clean_Boxplot2, Theta_Clean_Boxplot3)

Alpha_Boxplot1 <- ggboxplot(
  Alpha, x = "Musicianship", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Alpha: Boxplot of 'Musicianship/Hemisphere/Modality' BEFORE outlier removal",
)

Alpha_Boxplot2 <- ggboxplot(
  Alpha, x = "Direction", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Alpha: Boxplot of 'Direction/Hemisphere/Modality' BEFORE outlier removal",
)

Alpha_Boxplot3 <- ggboxplot(
  Alpha, x = "Direction", y = "PTE",
  color = "Modality", palette = "jco",
  facet.by = "Motor_Region", short.panel.labs = FALSE,
  title= "Alpha: Boxplot of 'Modality/Direction/Motor_region' BEFORE outlier removal",
)

Alpha_Clean_Boxplot1 <- ggboxplot(
  Alpha_no_outliers, x = "Musicianship", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Alpha: Boxplot of 'Musicianship/Hemisphere/Modality' AFTER outlier removal",
)

Alpha_Clean_Boxplot2 <- ggboxplot(
  Alpha_no_outliers, x = "Direction", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Alpha: Boxplot of 'Direction/Hemisphere/Modality' AFTER outlier removal",
)

Alpha_Clean_Boxplot3 <- ggboxplot(
  Alpha_no_outliers, x = "Direction", y = "PTE",
  color = "Modality", palette = "jco",
  facet.by = "Motor_Region", short.panel.labs = FALSE,
  title= "Alpha: Boxplot of 'Modality/Direction/Motor_region' AFTER outlier removal",
)

Alpha_Boxplots = list(Musicianship_BEFORE = Alpha_Boxplot1, 
                      Musicianship_AFTER = Alpha_Clean_Boxplot1, 
                      Direction_BEFORE = Alpha_Boxplot2,
                      Direction_AFTER = Alpha_Clean_Boxplot2,
                      MotorRegion_BEFORE = Alpha_Boxplot3,
                      MotorRegion_AFTER = Alpha_Clean_Boxplot3)

rm (Alpha_Boxplot1,Alpha_Boxplot2,Alpha_Boxplot3,
    Alpha_Clean_Boxplot1,Alpha_Clean_Boxplot2, Alpha_Clean_Boxplot3)

Beta_Boxplot1 <- ggboxplot(
  Beta, x = "Musicianship", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Beta: Boxplot of 'Musicianship/Hemisphere/Modality' BEFORE outlier removal",
)

Beta_Boxplot2 <- ggboxplot(
  Beta, x = "Direction", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Beta: Boxplot of 'Direction/Hemisphere/Modality' BEFORE outlier removal",
)

Beta_Boxplot3 <- ggboxplot(
  Beta, x = "Direction", y = "PTE",
  color = "Modality", palette = "jco",
  facet.by = "Motor_Region", short.panel.labs = FALSE,
  title= "Beta: Boxplot of 'Modality/Direction/Motor_region' BEFORE outlier removal",
)

Beta_Clean_Boxplot1 <- ggboxplot(
  Beta_no_outliers, x = "Musicianship", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Beta: Boxplot of 'Musicianship/Hemisphere/Modality' AFTER outlier removal",
)

Beta_Clean_Boxplot2 <- ggboxplot(
  Beta_no_outliers, x = "Direction", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Beta: Boxplot of 'Direction/Hemisphere/Modality' AFTER outlier removal",
)

Beta_Clean_Boxplot3 <- ggboxplot(
  Beta_no_outliers, x = "Direction", y = "PTE",
  color = "Modality", palette = "jco",
  facet.by = "Motor_Region", short.panel.labs = FALSE,
  title= "Beta: Boxplot of 'Modality/Direction/Motor_region' AFTER outlier removal",
)

Beta_Boxplots = list(Musicianship_BEFORE = Beta_Boxplot1, 
                      Musicianship_AFTER = Beta_Clean_Boxplot1, 
                      Direction_BEFORE = Beta_Boxplot2,
                      Direction_AFTER = Beta_Clean_Boxplot2,
                      MotorRegion_BEFORE = Beta_Boxplot3,
                      MotorRegion_AFTER = Beta_Clean_Boxplot3)

rm (Beta_Boxplot1,Beta_Boxplot2,Beta_Boxplot3,
    Beta_Clean_Boxplot1,Beta_Clean_Boxplot2, Beta_Clean_Boxplot3)

Gamma1_Boxplot1 <- ggboxplot(
  Gamma1, x = "Musicianship", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma1: Boxplot of 'Musicianship/Hemisphere/Modality' BEFORE outlier removal",
)

Gamma1_Boxplot2 <- ggboxplot(
  Gamma1, x = "Direction", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma1: Boxplot of 'Direction/Hemisphere/Modality' BEFORE outlier removal",
)

Gamma1_Boxplot3 <- ggboxplot(
  Gamma1, x = "Direction", y = "PTE",
  color = "Modality", palette = "jco",
  facet.by = "Motor_Region", short.panel.labs = FALSE,
  title= "Gamma1: Boxplot of 'Modality/Direction/Motor_region' BEFORE outlier removal",
)

Gamma1_Clean_Boxplot1 <- ggboxplot(
  Gamma1_no_outliers, x = "Musicianship", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma1: Boxplot of 'Musicianship/Hemisphere/Modality' AFTER outlier removal",
)

Gamma1_Clean_Boxplot2 <- ggboxplot(
  Gamma1_no_outliers, x = "Direction", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma1: Boxplot of 'Direction/Hemisphere/Modality' AFTER outlier removal",
)

Gamma1_Clean_Boxplot3 <- ggboxplot(
  Gamma1_no_outliers, x = "Direction", y = "PTE",
  color = "Modality", palette = "jco",
  facet.by = "Motor_Region", short.panel.labs = FALSE,
  title= "Gamma1: Boxplot of 'Modality/Direction/Motor_region' AFTER outlier removal",
)

Gamma1_Boxplots = list(Musicianship_BEFORE = Gamma1_Boxplot1, 
                      Musicianship_AFTER = Gamma1_Clean_Boxplot1, 
                      Direction_BEFORE = Gamma1_Boxplot2,
                      Direction_AFTER = Gamma1_Clean_Boxplot2,
                      MotorRegion_BEFORE = Gamma1_Boxplot3,
                      MotorRegion_AFTER = Gamma1_Clean_Boxplot3)

rm (Gamma1_Boxplot1,Gamma1_Boxplot2,Gamma1_Boxplot3,
    Gamma1_Clean_Boxplot1,Gamma1_Clean_Boxplot2, Gamma1_Clean_Boxplot3)

Gamma2_Boxplot1 <- ggboxplot(
  Gamma2, x = "Musicianship", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma2: Boxplot of 'Musicianship/Hemisphere/Modality' BEFORE outlier removal",
)

Gamma2_Boxplot2 <- ggboxplot(
  Gamma2, x = "Direction", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma2: Boxplot of 'Direction/Hemisphere/Modality' BEFORE outlier removal",
)

Gamma2_Boxplot3 <- ggboxplot(
  Gamma2, x = "Direction", y = "PTE",
  color = "Modality", palette = "jco",
  facet.by = "Motor_Region", short.panel.labs = FALSE,
  title= "Gamma2: Boxplot of 'Modality/Direction/Motor_region' BEFORE outlier removal",
)

Gamma2_Clean_Boxplot1 <- ggboxplot(
  Gamma2_no_outliers, x = "Musicianship", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma2: Boxplot of 'Musicianship/Hemisphere/Modality' AFTER outlier removal",
)

Gamma2_Clean_Boxplot2 <- ggboxplot(
  Gamma2_no_outliers, x = "Direction", y = "PTE",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma2: Boxplot of 'Direction/Hemisphere/Modality' AFTER outlier removal",
)

Gamma2_Clean_Boxplot3 <- ggboxplot(
  Gamma2_no_outliers, x = "Direction", y = "PTE",
  color = "Modality", palette = "jco",
  facet.by = "Motor_Region", short.panel.labs = FALSE,
  title= "Gamma2: Boxplot of 'Modality/Direction/Motor_region' AFTER outlier removal",
)

Gamma2_Boxplots = list(Musicianship_BEFORE = Gamma2_Boxplot1, 
                      Musicianship_AFTER = Gamma2_Clean_Boxplot1, 
                      Direction_BEFORE = Gamma2_Boxplot2,
                      Direction_AFTER = Gamma2_Clean_Boxplot2,
                      MotorRegion_BEFORE = Gamma2_Boxplot3,
                      MotorRegion_AFTER = Gamma2_Clean_Boxplot3)

rm (Gamma2_Boxplot1,Gamma2_Boxplot2,Gamma2_Boxplot3,
    Gamma2_Clean_Boxplot1,Gamma2_Clean_Boxplot2, Gamma2_Clean_Boxplot3)

# Step 4: We funnel everything into one mega-list

Delta_Info = list(Stats = Delta_Summary, Plots = Delta_Boxplots)
rm (Delta_Summary,Delta_Boxplots)

Theta_Info = list(Stats = Theta_Summary, Plots = Theta_Boxplots)
rm (Theta_Summary,Theta_Boxplots)

Alpha_Info = list(Stats = Alpha_Summary, Plots = Alpha_Boxplots)
rm (Alpha_Summary,Alpha_Boxplots)

Beta_Info = list(Stats = Beta_Summary, Plots = Beta_Boxplots)
rm (Beta_Summary,Beta_Boxplots)

Gamma1_Info = list(Stats = Gamma1_Summary, Plots = Gamma1_Boxplots)
rm (Gamma1_Summary,Gamma1_Boxplots)

Gamma2_Info = list(Stats = Gamma2_Summary, Plots = Gamma2_Boxplots)
rm (Gamma2_Summary,Gamma2_Boxplots)

Summary_Bands = list (Delta = Delta_Info,
                      Theta = Theta_Info,
                      Alpha = Alpha_Info,
                      Beta = Beta_Info,
                      Gamma1 = Gamma1_Info,
                      Gamma2 = Gamma2_Info)

rm (Delta_Info,Theta_Info,Alpha_Info,Beta_Info,Gamma1_Info,Gamma2_Info)

# Step 7: Normality assumptions: Shapiro-Wilk

Delta_normality <- Delta %>%
  group_by(Hemisphere,Modality,Direction) %>%
  shapiro_test(PTE)

Theta_normality <- Theta %>%
  group_by(Hemisphere,Modality,Direction) %>%
  shapiro_test(PTE)

Alpha_normality <- Alpha %>%
  group_by(Hemisphere,Modality,Direction) %>%
  shapiro_test(PTE)

Beta_normality <- Beta %>%
  group_by(Hemisphere,Modality,Direction) %>%
  shapiro_test(PTE)

Gamma1_normality <- Gamma1 %>%
  group_by(Hemisphere,Modality,Direction) %>%
  shapiro_test(PTE)

Gamma2_normality <- Gamma2 %>%
  group_by(Hemisphere,Modality,Direction) %>%
  shapiro_test(PTE)

Normality_Bands = list(Delta = Delta_normality,
                       Theta = Theta_normality,
                       Alpha = Alpha_normality,
                       Beta = Beta_normality,
                       Gamma1 = Gamma1_normality,
                       Gamma2 = Gamma2_normality)

rm(Delta_normality,Theta_normality,Alpha_normality,Beta_normality,Gamma1_normality,Gamma2_normality)

# Step 8: QQ plots and Density plots

Delta_QQ <- ggqqplot(Delta, "PTE", ggtheme = theme_bw(), 
            title= "Delta: QQ plot of 'Hemisphere/Modality/Direction' BEFORE outlier removal") +
            facet_grid(Hemisphere ~ Modality + Direction, labeller = "label_both")

Theta_QQ <- ggqqplot(Theta, "PTE", ggtheme = theme_bw(), 
            title= "Theta: QQ plot of 'Hemisphere/Modality/Direction' BEFORE outlier removal") +
            facet_grid(Hemisphere ~ Modality + Direction, labeller = "label_both")

Alpha_QQ <- ggqqplot(Alpha, "PTE", ggtheme = theme_bw(), 
            title= "Alpha: QQ plot of 'Hemisphere/Modality/Direction' BEFORE outlier removal") +
            facet_grid(Hemisphere ~ Modality + Direction, labeller = "label_both")

Beta_QQ <-  ggqqplot(Beta, "PTE", ggtheme = theme_bw(), 
            title= "Beta: QQ plot of 'Hemisphere/Modality/Direction' BEFORE outlier removal") +
            facet_grid(Hemisphere ~ Modality + Direction, labeller = "label_both")

Gamma1_QQ <- ggqqplot(Gamma1, "PTE", ggtheme = theme_bw(), 
            title= "Gamma1: QQ plot of 'Hemisphere/Modality/Direction' BEFORE outlier removal") +
            facet_grid(Hemisphere ~ Modality + Direction, labeller = "label_both")

Gamma2_QQ <- ggqqplot(Gamma2, "PTE", ggtheme = theme_bw(), 
            title= "Gamma2: QQ plot of 'Hemisphere/Modality/Direction' BEFORE outlier removal") +
            facet_grid(Hemisphere ~ Modality + Direction, labeller = "label_both")

QQ_Bands = list(Delta = Delta_QQ,
                     Theta = Theta_QQ,
                     Alpha = Alpha_QQ,
                     Beta = Beta_QQ,
                     Gamma1 = Gamma1_QQ,
                     Gamma2 = Gamma2_QQ)

rm(Delta_QQ,Theta_QQ,Alpha_QQ,Beta_QQ,Gamma1_QQ,Gamma2_QQ)

Delta_density <- ggdensity(Delta$PTE, fill = "lightgray",title="Delta: density plot BEFORE outlier removal")
Theta_density <- ggdensity(Theta$PTE, fill = "lightgray",title="Theta: density plot BEFORE outlier removal")
Alpha_density <- ggdensity(Alpha$PTE, fill = "lightgray",title="Alpha: density plot BEFORE outlier removal")
Beta_density <- ggdensity(Beta$PTE, fill = "lightgray",title="Beta: density plot BEFORE outlier removal")
Gamma1_density <- ggdensity(Gamma1$PTE, fill = "lightgray",title="Gamam1:: density plot BEFORE outlier removal")
Gamma2_density <- ggdensity(Gamma2$PTE, fill = "lightgray",title="Gamma2: density plot BEFORE outlier removal")

Density_Bands = list(Delta = Delta_density,
                   Theta = Theta_density,
                   Alpha = Alpha_density,
                   Beta = Beta_density,
                   Gamma1 = Gamma1_density,
                   Gamma2 = Gamma2_density)

rm(Delta_density,Theta_density,Alpha_density,Beta_density,Gamma1_density,Gamma2_density)

# Step 8: Homogeneity

Delta_homogeneity = Delta %>%
  group_by(Hemisphere, Modality, Direction) %>%
  levene_test(PTE ~ Musicianship)

Theta_homogeneity = Theta %>%
  group_by(Hemisphere, Modality, Direction) %>%
  levene_test(PTE ~ Musicianship)

Alpha_homogeneity = Alpha %>%
  group_by(Hemisphere, Modality, Direction) %>%
  levene_test(PTE ~ Musicianship)

Beta_homogeneity = Beta %>%
  group_by(Hemisphere, Modality, Direction) %>%
  levene_test(PTE ~ Musicianship)

Gamma1_homogeneity = Gamma1 %>%
  group_by(Hemisphere, Modality, Direction) %>%
  levene_test(PTE ~ Musicianship)

Gamma2_homogeneity = Gamma2 %>%
  group_by(Hemisphere, Modality, Direction) %>%
  levene_test(PTE ~ Musicianship)

Homogeneity_Bands = list(Delta = Delta_homogeneity,
                         Theta = Theta_homogeneity,
                         Alpha = Alpha_homogeneity,
                         Beta = Beta_homogeneity,
                         Gamma1 = Gamma1_homogeneity,
                         Gamma2 = Gamma2_homogeneity)

rm(Delta_homogeneity,Theta_homogeneity,Alpha_homogeneity,Beta_homogeneity,Gamma1_homogeneity,Gamma2_homogeneity)