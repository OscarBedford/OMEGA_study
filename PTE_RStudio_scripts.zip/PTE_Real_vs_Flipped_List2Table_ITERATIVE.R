## NOTE: This example will use Oscar's data! 

########################################
## STEP 1: Extract the MA and MV columns 
########################################

## Let us begin by pre-allocating some variables and computing some initial Vectors for the Left_Real data

MA_MV_LEFT_Real = list()
MA_MV_LEFT_Flipped = list()
MA_MV_RIGHT_Real = list()
MA_MV_RIGHT_Flipped = list()
MA_MV = list () 

for (i in 1:length(SubjectNames)){
   
Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Real$delta[1:3,c(4,6)]"))))
MA_MV_L_Real_delta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Real$theta[1:3,c(4,6)]"))))
MA_MV_L_Real_theta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Real$alpha[1:3,c(4,6)]"))))
MA_MV_L_Real_alpha <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Real$beta[1:3,c(4,6)]"))))
MA_MV_L_Real_beta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Real$gamma1[1:3,c(4,6)]"))))
MA_MV_L_Real_gamma1 <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Real$gamma2[1:3,c(4,6)]"))))
MA_MV_L_Real_gamma2 <- data.frame (Vector)
rm(Vector)

## Same for Left_Flipped data

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Flipped$delta[1:3,c(4,6)]"))))
MA_MV_L_Flipped_delta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Flipped$theta[1:3,c(4,6)]"))))
MA_MV_L_Flipped_theta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Flipped$alpha[1:3,c(4,6)]"))))
MA_MV_L_Flipped_alpha <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Flipped$beta[1:3,c(4,6)]"))))
MA_MV_L_Flipped_beta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Flipped$gamma1[1:3,c(4,6)]"))))
MA_MV_L_Flipped_gamma1 <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Flipped$gamma2[1:3,c(4,6)]"))))
MA_MV_L_Flipped_gamma2 <- data.frame (Vector)
rm(Vector)
  

## We do the same for the Right_Real data

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Real$delta[1:3,c(4,6)]"))))
MA_MV_R_Real_delta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Real$theta[1:3,c(4,6)]"))))
MA_MV_R_Real_theta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Real$alpha[1:3,c(4,6)]"))))
MA_MV_R_Real_alpha <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Real$beta[1:3,c(4,6)]"))))
MA_MV_R_Real_beta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Real$gamma1[1:3,c(4,6)]"))))
MA_MV_R_Real_gamma1 <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Real$gamma2[1:3,c(4,6)]"))))
MA_MV_R_Real_gamma2 <- data.frame (Vector)
rm(Vector)

## Same for the Right_Flipped data 

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Flipped$delta[1:3,c(4,6)]"))))
MA_MV_R_Flipped_delta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Flipped$theta[1:3,c(4,6)]"))))
MA_MV_R_Flipped_theta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Flipped$alpha[1:3,c(4,6)]"))))
MA_MV_R_Flipped_alpha <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Flipped$beta[1:3,c(4,6)]"))))
MA_MV_R_Flipped_beta <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Flipped$gamma1[1:3,c(4,6)]"))))
MA_MV_R_Flipped_gamma1 <- data.frame (Vector)
rm(Vector)

Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Flipped$gamma2[1:3,c(4,6)]"))))
MA_MV_R_Flipped_gamma2 <- data.frame (Vector)
rm(Vector)

## We now add ALL of it into a list

MA_MV_LEFT_Real[[i]] <- list(delta = MA_MV_L_Real_delta,
                           theta = MA_MV_L_Real_theta,
                           alpha = MA_MV_L_Real_alpha,
                           beta = MA_MV_L_Real_beta,
                           gamma1 = MA_MV_L_Real_gamma1,
                           gamma2 = MA_MV_L_Real_gamma2)

rm (MA_MV_L_Real_alpha,MA_MV_L_Real_beta,MA_MV_L_Real_delta,MA_MV_L_Real_gamma1,MA_MV_L_Real_gamma2,MA_MV_L_Real_theta)

MA_MV_RIGHT_Real[[i]] <- list(delta = MA_MV_R_Real_delta,
                           theta = MA_MV_R_Real_theta,
                           alpha = MA_MV_R_Real_alpha,
                           beta = MA_MV_R_Real_beta,
                           gamma1 = MA_MV_R_Real_gamma1,
                           gamma2 = MA_MV_R_Real_gamma2)

rm (MA_MV_R_Real_alpha,MA_MV_R_Real_beta,MA_MV_R_Real_delta,MA_MV_R_Real_gamma1,MA_MV_R_Real_gamma2,MA_MV_R_Real_theta)

MA_MV_LEFT_Flipped[[i]] <- list(delta = MA_MV_L_Flipped_delta,
                             theta = MA_MV_L_Flipped_theta,
                             alpha = MA_MV_L_Flipped_alpha,
                             beta = MA_MV_L_Flipped_beta,
                             gamma1 = MA_MV_L_Flipped_gamma1,
                             gamma2 = MA_MV_L_Flipped_gamma2)

rm (MA_MV_L_Flipped_alpha,MA_MV_L_Flipped_beta,MA_MV_L_Flipped_delta,MA_MV_L_Flipped_gamma1,MA_MV_L_Flipped_gamma2,MA_MV_L_Flipped_theta)

MA_MV_RIGHT_Flipped[[i]] <- list(delta = MA_MV_R_Flipped_delta,
                              theta = MA_MV_R_Flipped_theta,
                              alpha = MA_MV_R_Flipped_alpha,
                              beta = MA_MV_R_Flipped_beta,
                              gamma1 = MA_MV_R_Flipped_gamma1,
                              gamma2 = MA_MV_R_Flipped_gamma2)

rm (MA_MV_R_Flipped_alpha,MA_MV_R_Flipped_beta,MA_MV_R_Flipped_delta,MA_MV_R_Flipped_gamma1,MA_MV_R_Flipped_gamma2,MA_MV_R_Flipped_theta)

MA_MV[[i]] <- list(LEFT_Real = MA_MV_LEFT_Real[[i]],
                  RIGHT_Real = MA_MV_RIGHT_Real[[i]],
                  LEFT_Flipped = MA_MV_LEFT_Flipped[[i]],
                  RIGHT_Flipped = MA_MV_RIGHT_Flipped[[i]])  

}

rm (MA_MV_LEFT_Real, MA_MV_LEFT_Flipped, MA_MV_RIGHT_Real, MA_MV_LEFT_Flipped, MA_MV_RIGHT_Flipped)
rm (i)

names(MA_MV) <- SubjectNames

########################################
## STEP 2: Extract the AM and VM columns 
########################################

## Let us begin by pre-allocating some variables and computing some initial Vectors for the Left hemisphere

AM_VM_LEFT_Real = list()
AM_VM_LEFT_Flipped = list()
AM_VM_RIGHT_Real = list()
AM_VM_RIGHT_Flipped = list()
AM_VM = list () 

for (i in 1:length(SubjectNames)){
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Real$delta[c(4,6),(1:3)]"))))
  AM_VM_L_Real_delta <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Real$theta[c(4,6),(1:3)]"))))
  AM_VM_L_Real_theta <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Real$alpha[c(4,6),(1:3)]"))))
  AM_VM_L_Real_alpha <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Real$beta[c(4,6),(1:3)]"))))
  AM_VM_L_Real_beta <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Real$gamma1[c(4,6),(1:3)]"))))
  AM_VM_L_Real_gamma1 <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Real$gamma2[c(4,6),(1:3)]"))))
  AM_VM_L_Real_gamma2 <- data.frame (Vector)
  rm(Vector)
  
  ## Same for left flipped 
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Flipped$delta[c(4,6),(1:3)]"))))
  AM_VM_L_Flipped_delta <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Flipped$theta[c(4,6),(1:3)]"))))
  AM_VM_L_Flipped_theta <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Flipped$alpha[c(4,6),(1:3)]"))))
  AM_VM_L_Flipped_alpha <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Flipped$beta[c(4,6),(1:3)]"))))
  AM_VM_L_Flipped_beta <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Flipped$gamma1[c(4,6),(1:3)]"))))
  AM_VM_L_Flipped_gamma1 <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$LEFT_Flipped$gamma2[c(4,6),(1:3)]"))))
  AM_VM_L_Flipped_gamma2 <- data.frame (Vector)
  rm(Vector)
  
  ## We do the same for the right Real data
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Real$delta[c(4,6),(1:3)]"))))
  AM_VM_R_Real_delta <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Real$theta[c(4,6),(1:3)]"))))
  AM_VM_R_Real_theta <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Real$alpha[c(4,6),(1:3)]"))))
  AM_VM_R_Real_alpha <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Real$beta[c(4,6),(1:3)]"))))
  AM_VM_R_Real_beta <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Real$gamma1[c(4,6),(1:3)]"))))
  AM_VM_R_Real_gamma1 <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Real$gamma2[c(4,6),(1:3)]"))))
  AM_VM_R_Real_gamma2 <- data.frame (Vector)
  rm(Vector)
  
  ## We do the same for the right flipped
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Flipped$delta[c(4,6),(1:3)]"))))
  AM_VM_R_Flipped_delta <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Flipped$theta[c(4,6),(1:3)]"))))
  AM_VM_R_Flipped_theta <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Flipped$alpha[c(4,6),(1:3)]"))))
  AM_VM_R_Flipped_alpha <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Flipped$beta[c(4,6),(1:3)]"))))
  AM_VM_R_Flipped_beta <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Flipped$gamma1[c(4,6),(1:3)]"))))
  AM_VM_R_Flipped_gamma1 <- data.frame (Vector)
  rm(Vector)
  
  Vector <- eval(parse(text = (paste0("PTE$",SubjectNames[i],"$RIGHT_Flipped$gamma2[c(4,6),(1:3)]"))))
  AM_VM_R_Flipped_gamma2 <- data.frame (Vector)
  rm(Vector)
  
  ## We now add ALL of it into a list
  
  AM_VM_LEFT_Real[[i]] <- list(delta = AM_VM_L_Real_delta,
                          theta = AM_VM_L_Real_theta,
                          alpha = AM_VM_L_Real_alpha,
                          beta = AM_VM_L_Real_beta,
                          gamma1 = AM_VM_L_Real_gamma1,
                          gamma2 = AM_VM_L_Real_gamma2)
  
  rm (AM_VM_L_Real_alpha,AM_VM_L_Real_beta,AM_VM_L_Real_delta,AM_VM_L_Real_gamma1,AM_VM_L_Real_gamma2,AM_VM_L_Real_theta)
  
  AM_VM_LEFT_Flipped[[i]] <- list(delta = AM_VM_L_Flipped_delta,
                          theta = AM_VM_L_Flipped_theta,
                          alpha = AM_VM_L_Flipped_alpha,
                          beta = AM_VM_L_Flipped_beta,
                          gamma1 = AM_VM_L_Flipped_gamma1,
                          gamma2 = AM_VM_L_Flipped_gamma2)
  
  rm (AM_VM_L_Flipped_alpha,AM_VM_L_Flipped_beta,AM_VM_L_Flipped_delta,AM_VM_L_Flipped_gamma1,AM_VM_L_Flipped_gamma2,AM_VM_L_Flipped_theta)
  
  AM_VM_RIGHT_Real[[i]] <- list(delta = AM_VM_R_Real_delta,
                               theta = AM_VM_R_Real_theta,
                               alpha = AM_VM_R_Real_alpha,
                               beta = AM_VM_R_Real_beta,
                               gamma1 = AM_VM_R_Real_gamma1,
                               gamma2 = AM_VM_R_Real_gamma2)
  
  rm (AM_VM_R_Real_alpha,AM_VM_R_Real_beta,AM_VM_R_Real_delta,AM_VM_R_Real_gamma1,AM_VM_R_Real_gamma2,AM_VM_R_Real_theta)
  
  AM_VM_RIGHT_Flipped[[i]] <- list(delta = AM_VM_R_Flipped_delta,
                                  theta = AM_VM_R_Flipped_theta,
                                  alpha = AM_VM_R_Flipped_alpha,
                                  beta = AM_VM_R_Flipped_beta,
                                  gamma1 = AM_VM_R_Flipped_gamma1,
                                  gamma2 = AM_VM_R_Flipped_gamma2)
  
  rm (AM_VM_R_Flipped_alpha,AM_VM_R_Flipped_beta,AM_VM_R_Flipped_delta,AM_VM_R_Flipped_gamma1,AM_VM_R_Flipped_gamma2,AM_VM_R_Flipped_theta)
  
  AM_VM[[i]] <- list(LEFT_Real = AM_VM_LEFT_Real[[i]],
                     LEFT_Flipped = AM_VM_LEFT_Flipped[[i]],
                     RIGHT_Real = AM_VM_RIGHT_Real[[i]],
                     RIGHT_Flipped = AM_VM_RIGHT_Flipped[[i]])
  
}

rm (AM_VM_LEFT_Real, AM_VM_LEFT_Flipped, AM_VM_RIGHT_Real, AM_VM_RIGHT_Flipped)
rm (i)

names(AM_VM) <- SubjectNames

################################################
## STEP 3.1.1: We isolate the M1-A1 Real values
################################################

# First we will create a list that duplicates each element in SubjectNames

SubjectNames_Double = list()

for (i in 1:length(SubjectNames)){
SubjectNames_Double[[i]] <- (rep(SubjectNames[i], 2))
}

# We need to flatten the resulting nested list into a single-layer list:

SubjectNames_Double <- lapply(rapply(SubjectNames_Double, enquote, how="unlist"), eval)

# Now we need to create a list containing as many pairs of "L" & "R" as Subjects

Hemispheres <- list("L","R")
Hemispheres <- (rep(Hemispheres, length(SubjectNames)))

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the A1-M1 values from MA_MV and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
   Delta_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$delta[1,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$delta[1,1]"))
   Theta_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$theta[1,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$theta[1,1]"))
   Alpha_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$alpha[1,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$alpha[1,1]"))
   Beta_Values[[i]] =   list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$beta[1,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$beta[1,1]"))  
   Gamma1_Values[[i]] = list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$gamma1[1,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$gamma1[1,1]"))
   Gamma2_Values[[i]] = list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$gamma2[1,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$gamma2[1,1]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
   Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
   Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
   Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
   Beta_Values [[i]] <- (eval(parse(text=Beta_Values[[i]])))
   Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
   Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PTE values per freq band

M1_A1_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
M1_A1_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
M1_A1_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
M1_A1_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
M1_A1_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
M1_A1_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm(Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all M1_A1 values

M1_A1_Real_Bands <- list(delta = M1_A1_Delta,
                    theta = M1_A1_Theta,
                    alpha = M1_A1_Alpha,
                    beta = M1_A1_Beta,
                    gamma1 = M1_A1_Gamma1,
                    gamma2 = M1_A1_Gamma2)

# We delete the last miscellaneous variables

rm(M1_A1_Delta,M1_A1_Theta,M1_A1_Alpha,M1_A1_Beta,M1_A1_Gamma1,M1_A1_Gamma2)


###################################################
## STEP 3.1.2: We isolate the M1-A1 Flipped values
###################################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the A1-M1 values from MA_MV and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
  Delta_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$delta[1,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$delta[1,1]"))
  Theta_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$theta[1,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$theta[1,1]"))
  Alpha_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$alpha[1,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$alpha[1,1]"))
  Beta_Values[[i]] =   list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$beta[1,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$beta[1,1]"))  
  Gamma1_Values[[i]] = list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$gamma1[1,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$gamma1[1,1]"))
  Gamma2_Values[[i]] = list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$gamma2[1,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$gamma2[1,1]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
  Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
  Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
  Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
  Beta_Values [[i]] <- (eval(parse(text=Beta_Values[[i]])))
  Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
  Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PTE values per freq band

M1_A1_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
M1_A1_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
M1_A1_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
M1_A1_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
M1_A1_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
M1_A1_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm(Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all M1_A1 values

M1_A1_Flipped_Bands <- list(delta = M1_A1_Delta,
                         theta = M1_A1_Theta,
                         alpha = M1_A1_Alpha,
                         beta = M1_A1_Beta,
                         gamma1 = M1_A1_Gamma1,
                         gamma2 = M1_A1_Gamma2)

# We delete the last miscellaneous variables

rm(M1_A1_Delta,M1_A1_Theta,M1_A1_Alpha,M1_A1_Beta,M1_A1_Gamma1,M1_A1_Gamma2)













############################################
## STEP 3.2.1: We isolate the vPMC-A1 values
############################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the vPMC-A1 values from MA_MV and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
   Delta_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$delta[3,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$delta[3,1]"))
   Theta_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$theta[3,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$theta[3,1]"))
   Alpha_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$alpha[3,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$alpha[3,1]"))
   Beta_Values[[i]] =   list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$beta[3,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$beta[3,1]"))  
   Gamma1_Values[[i]] = list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$gamma1[3,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$gamma1[3,1]"))
   Gamma2_Values[[i]] = list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$gamma2[3,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$gamma2[3,1]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
  Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
  Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
  Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
  Beta_Values [[i]] <- (eval(parse(text=Beta_Values[[i]])))
  Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
  Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PTE values per freq band

vPMC_A1_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
vPMC_A1_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
vPMC_A1_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
vPMC_A1_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
vPMC_A1_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
vPMC_A1_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm (Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all A1_vPMC values

vPMC_A1_Real_Bands <- list(delta = vPMC_A1_Delta,
                        theta = vPMC_A1_Theta,
                        alpha = vPMC_A1_Alpha,
                        beta = vPMC_A1_Beta,
                        gamma1 = vPMC_A1_Gamma1,
                        gamma2 = vPMC_A1_Gamma2)

# We delete the last miscellaneous variables

rm(vPMC_A1_Delta,vPMC_A1_Theta,vPMC_A1_Alpha,vPMC_A1_Beta,vPMC_A1_Gamma1,vPMC_A1_Gamma2)


############################################
## STEP 3.2.2: We isolate the vPMC-A1 values
############################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the vPMC-A1 values from MA_MV and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
  Delta_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$delta[3,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$delta[3,1]"))
  Theta_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$theta[3,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$theta[3,1]"))
  Alpha_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$alpha[3,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$alpha[3,1]"))
  Beta_Values[[i]] =   list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$beta[3,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$beta[3,1]"))  
  Gamma1_Values[[i]] = list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$gamma1[3,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$gamma1[3,1]"))
  Gamma2_Values[[i]] = list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$gamma2[3,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$gamma2[3,1]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
  Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
  Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
  Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
  Beta_Values [[i]] <- (eval(parse(text=Beta_Values[[i]])))
  Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
  Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PTE values per freq band

vPMC_A1_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
vPMC_A1_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
vPMC_A1_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
vPMC_A1_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
vPMC_A1_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
vPMC_A1_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm (Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all A1_vPMC values

vPMC_A1_Flipped_Bands <- list(delta = vPMC_A1_Delta,
                      theta = vPMC_A1_Theta,
                      alpha = vPMC_A1_Alpha,
                      beta = vPMC_A1_Beta,
                      gamma1 = vPMC_A1_Gamma1,
                      gamma2 = vPMC_A1_Gamma2)

# We delete the last miscellaneous variables

rm(vPMC_A1_Delta,vPMC_A1_Theta,vPMC_A1_Alpha,vPMC_A1_Beta,vPMC_A1_Gamma1,vPMC_A1_Gamma2)

#################################################
## STEP 3.3.1: We isolate the dPMC-A1 Real values
#################################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the dPMC-A1 values from MA_MV and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
   Delta_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$delta[2,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$delta[2,1]"))
   Theta_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$theta[2,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$theta[2,1]"))
   Alpha_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$alpha[2,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$alpha[2,1]"))
   Beta_Values[[i]] =   list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$beta[2,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$beta[2,1]"))  
   Gamma1_Values[[i]] = list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$gamma1[2,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$gamma1[2,1]"))
   Gamma2_Values[[i]] = list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Real$gamma2[2,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Real$gamma2[2,1]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
   Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
   Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
   Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
   Beta_Values[[i]] <- (eval(parse(text=Beta_Values[[i]])))
   Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
   Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PTE values per freq band

A1_dPMC_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
A1_dPMC_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
A1_dPMC_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
A1_dPMC_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
A1_dPMC_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
A1_dPMC_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm(Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all A1_dPMC values

dPMC_A1_Real_Bands <- list(delta = A1_dPMC_Delta,
                          theta = A1_dPMC_Theta,
                          alpha = A1_dPMC_Alpha,
                          beta = A1_dPMC_Beta,
                          gamma1 = A1_dPMC_Gamma1,
                          gamma2 = A1_dPMC_Gamma2)

# We delete the last miscellaneous variables

rm(A1_dPMC_Delta,A1_dPMC_Theta,A1_dPMC_Alpha,A1_dPMC_Beta,A1_dPMC_Gamma1,A1_dPMC_Gamma2)

####################################################
## STEP 3.3.2: We isolate the dPMC-A1 Flipped values
####################################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the dPMC-A1 values from MA_MV and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
  Delta_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$delta[2,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$delta[2,1]"))
  Theta_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$theta[2,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$theta[2,1]"))
  Alpha_Values[[i]] =  list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$alpha[2,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$alpha[2,1]"))
  Beta_Values[[i]] =   list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$beta[2,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$beta[2,1]"))  
  Gamma1_Values[[i]] = list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$gamma1[2,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$gamma1[2,1]"))
  Gamma2_Values[[i]] = list(paste0("MA_MV$",SubjectNames[i],"$LEFT_Flipped$gamma2[2,1]"),paste0("MA_MV$",SubjectNames[i],"$RIGHT_Flipped$gamma2[2,1]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
  Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
  Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
  Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
  Beta_Values[[i]] <- (eval(parse(text=Beta_Values[[i]])))
  Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
  Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PTE values per freq band

A1_dPMC_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
A1_dPMC_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
A1_dPMC_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
A1_dPMC_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
A1_dPMC_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
A1_dPMC_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm(Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all A1_dPMC values

dPMC_A1_Flipped_Bands <- list(delta = A1_dPMC_Delta,
                           theta = A1_dPMC_Theta,
                           alpha = A1_dPMC_Alpha,
                           beta = A1_dPMC_Beta,
                           gamma1 = A1_dPMC_Gamma1,
                           gamma2 = A1_dPMC_Gamma2)

# We delete the last miscellaneous variables

rm(A1_dPMC_Delta,A1_dPMC_Theta,A1_dPMC_Alpha,A1_dPMC_Beta,A1_dPMC_Gamma1,A1_dPMC_Gamma2)

###############################################
## STEP 4.1.1: We isolate the Real A1-M1 values
###############################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the A1-M1 values from AM_VM and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
  Delta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$delta[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$delta[1,1]"))
  Theta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$theta[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$theta[1,1]"))
  Alpha_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$alpha[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$alpha[1,1]"))
  Beta_Values[[i]] =   list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$beta[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$beta[1,1]"))  
  Gamma1_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$gamma1[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$gamma1[1,1]"))
  Gamma2_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$gamma2[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$gamma2[1,1]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
  Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
  Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
  Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
  Beta_Values [[i]] <- (eval(parse(text=Beta_Values[[i]])))
  Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
  Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PTE values per freq band

A1_V1_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
A1_V1_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
A1_V1_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
A1_V1_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
A1_V1_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
A1_V1_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm(Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all A1_M1 values

A1_M1_Real_Bands <- list(delta = A1_V1_Delta,
                    theta = A1_V1_Theta,
                    alpha = A1_V1_Alpha,
                    beta = A1_V1_Beta,
                    gamma1 = A1_V1_Gamma1,
                    gamma2 = A1_V1_Gamma2)

# We delete the last miscellaneous variables

rm(A1_V1_Delta,A1_V1_Theta,A1_V1_Alpha,A1_V1_Beta,A1_V1_Gamma1,A1_V1_Gamma2)

###################################################
## STEP 4.1.2: We isolate the Flipped A1-M1 values
###################################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the A1-M1 values from AM_VM and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
  Delta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$delta[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$delta[1,1]"))
  Theta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$theta[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$theta[1,1]"))
  Alpha_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$alpha[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$alpha[1,1]"))
  Beta_Values[[i]] =   list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$beta[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$beta[1,1]"))  
  Gamma1_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$gamma1[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$gamma1[1,1]"))
  Gamma2_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$gamma2[1,1]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$gamma2[1,1]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
  Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
  Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
  Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
  Beta_Values [[i]] <- (eval(parse(text=Beta_Values[[i]])))
  Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
  Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PTE values per freq band

A1_V1_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
A1_V1_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
A1_V1_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
A1_V1_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
A1_V1_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
A1_V1_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm(Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all A1_M1 values

A1_M1_Flipped_Bands <- list(delta = A1_V1_Delta,
                         theta = A1_V1_Theta,
                         alpha = A1_V1_Alpha,
                         beta = A1_V1_Beta,
                         gamma1 = A1_V1_Gamma1,
                         gamma2 = A1_V1_Gamma2)

# We delete the last miscellaneous variables

rm(A1_V1_Delta,A1_V1_Theta,A1_V1_Alpha,A1_V1_Beta,A1_V1_Gamma1,A1_V1_Gamma2)

#################################################
## STEP 5.2.1: We isolate the Real A1-vPMC values
#################################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the A1-vPMC values from AM_VM and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
  Delta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$delta[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$delta[1,3]"))
  Theta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$theta[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$theta[1,3]"))
  Alpha_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$alpha[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$alpha[1,3]"))
  Beta_Values[[i]] =   list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$beta[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$beta[1,3]"))  
  Gamma1_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$gamma1[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$gamma1[1,3]"))
  Gamma2_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$gamma2[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$gamma2[1,3]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
  Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
  Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
  Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
  Beta_Values[[i]] <- (eval(parse(text=Beta_Values[[i]])))
  Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
  Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PTE values per freq band

A1_vPMC_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
A1_vPMC_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
A1_vPMC_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
A1_vPMC_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
A1_vPMC_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
A1_vPMC_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm (Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all A1_vPMC values

A1_vPMC_Real_Bands <- list(delta = A1_vPMC_Delta,
                      theta = A1_vPMC_Theta,
                      alpha = A1_vPMC_Alpha,
                      beta = A1_vPMC_Beta,
                      gamma1 = A1_vPMC_Gamma1,
                      gamma2 = A1_vPMC_Gamma2)

# We delete the last miscellaneous variables

rm(A1_vPMC_Delta,A1_vPMC_Theta,A1_vPMC_Alpha,A1_vPMC_Beta,A1_vPMC_Gamma1,A1_vPMC_Gamma2)

####################################################
## STEP 5.2.2: We isolate the Flipped A1-vPMC values
####################################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the A1-vPMC values from AM_VM and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
  Delta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$delta[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$delta[1,3]"))
  Theta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$theta[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$theta[1,3]"))
  Alpha_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$alpha[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$alpha[1,3]"))
  Beta_Values[[i]] =   list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$beta[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$beta[1,3]"))  
  Gamma1_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$gamma1[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$gamma1[1,3]"))
  Gamma2_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$gamma2[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$gamma2[1,3]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
  Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
  Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
  Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
  Beta_Values[[i]] <- (eval(parse(text=Beta_Values[[i]])))
  Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
  Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PTE values per freq band

A1_vPMC_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
A1_vPMC_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
A1_vPMC_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
A1_vPMC_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
A1_vPMC_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
A1_vPMC_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm (Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all A1_vPMC values

A1_vPMC_Flipped_Bands <- list(delta = A1_vPMC_Delta,
                           theta = A1_vPMC_Theta,
                           alpha = A1_vPMC_Alpha,
                           beta = A1_vPMC_Beta,
                           gamma1 = A1_vPMC_Gamma1,
                           gamma2 = A1_vPMC_Gamma2)

# We delete the last miscellaneous variables

rm(A1_vPMC_Delta,A1_vPMC_Theta,A1_vPMC_Alpha,A1_vPMC_Beta,A1_vPMC_Gamma1,A1_vPMC_Gamma2)

#################################################
## STEP 5.3.1: We isolate the Real A1-dPMC values
#################################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the dPMC-A1 values from AM_VM and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
  Delta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$delta[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$delta[1,3]"))
  Theta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$theta[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$theta[1,3]"))
  Alpha_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$alpha[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$alpha[1,3]"))
  Beta_Values[[i]] =   list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$beta[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$beta[1,3]"))  
  Gamma1_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$gamma1[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$gamma1[1,3]"))
  Gamma2_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Real$gamma2[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Real$gamma2[1,3]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
  Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
  Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
  Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
  Beta_Values[[i]] <- (eval(parse(text=Beta_Values[[i]])))
  Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
  Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PTE values per freq band

A1_dPMC_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
A1_dPMC_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
A1_dPMC_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
A1_dPMC_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
A1_dPMC_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
A1_dPMC_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm(Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all A1_dPMC values

A1_dPMC_Real_Bands <- list(delta = A1_dPMC_Delta,
                      theta = A1_dPMC_Theta,
                      alpha = A1_dPMC_Alpha,
                      beta = A1_dPMC_Beta,
                      gamma1 = A1_dPMC_Gamma1,
                      gamma2 = A1_dPMC_Gamma2)

# We delete the last miscellaneous variables

rm(A1_dPMC_Delta,A1_dPMC_Theta,A1_dPMC_Alpha,A1_dPMC_Beta,A1_dPMC_Gamma1,A1_dPMC_Gamma2)

#################################################
## STEP 5.3.2: We isolate the Flipped A1-dPMC values
#################################################

# First we create an empty list for each frequency band:

Delta_Values <-   list()
Theta_Values <-   list()
Alpha_Values <-   list()
Beta_Values <-    list()
Gamma1_Values <-  list()
Gamma2_Values <-  list()

# Then we extract the dPMC-A1 values from AM_VM and we assign them to the corresponding freq band

for (i in 1:length(SubjectNames)){
  Delta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$delta[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$delta[1,3]"))
  Theta_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$theta[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$theta[1,3]"))
  Alpha_Values[[i]] =  list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$alpha[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$alpha[1,3]"))
  Beta_Values[[i]] =   list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$beta[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$beta[1,3]"))  
  Gamma1_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$gamma1[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$gamma1[1,3]"))
  Gamma2_Values[[i]] = list(paste0("AM_VM$",SubjectNames[i],"$LEFT_Flipped$gamma2[1,3]"),paste0("AM_VM$",SubjectNames[i],"$RIGHT_Flipped$gamma2[1,3]"))
}

# We now need to "unlist" the freq band lists so that they become vectors

Delta_Values <-   lapply(rapply(Delta_Values, enquote, how="unlist"), eval)
Theta_Values <-   lapply(rapply(Theta_Values, enquote, how="unlist"), eval)
Alpha_Values <-   lapply(rapply(Alpha_Values, enquote, how="unlist"), eval)
Beta_Values <-    lapply(rapply(Beta_Values, enquote, how="unlist"), eval)
Gamma1_Values <-  lapply(rapply(Gamma1_Values, enquote, how="unlist"), eval)
Gamma2_Values <-  lapply(rapply(Gamma2_Values, enquote, how="unlist"), eval)

# We give names to each row

for (i in 1:length(Delta_Values)){
  Delta_Values[[i]] <- (eval(parse(text=Delta_Values[[i]])))
  Theta_Values[[i]] <- (eval(parse(text=Theta_Values[[i]])))
  Alpha_Values[[i]] <- (eval(parse(text=Alpha_Values[[i]])))
  Beta_Values[[i]] <- (eval(parse(text=Beta_Values[[i]])))
  Gamma1_Values[[i]] <- (eval(parse(text=Gamma1_Values[[i]])))
  Gamma2_Values[[i]] <- (eval(parse(text=Gamma2_Values[[i]])))
}

# We create a dataframe containing SubjectNames, Hemispheres, and PTE values per freq band

A1_dPMC_Delta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Delta_Values))
A1_dPMC_Theta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Theta_Values))
A1_dPMC_Alpha <- data.frame(cbind(SubjectNames_Double,Hemispheres,Alpha_Values))
A1_dPMC_Beta <- data.frame(cbind(SubjectNames_Double,Hemispheres,Beta_Values))
A1_dPMC_Gamma1 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma1_Values))
A1_dPMC_Gamma2 <- data.frame(cbind(SubjectNames_Double,Hemispheres,Gamma2_Values))

# We delete some miscellaneous variables

rm(Delta_Values,Theta_Values,Alpha_Values,Beta_Values,Gamma1_Values,Gamma2_Values)

# We add the 6 dataframes into one large list including all A1_dPMC values

A1_dPMC_Flipped_Bands <- list(delta = A1_dPMC_Delta,
                      theta = A1_dPMC_Theta,
                      alpha = A1_dPMC_Alpha,
                      beta = A1_dPMC_Beta,
                      gamma1 = A1_dPMC_Gamma1,
                      gamma2 = A1_dPMC_Gamma2)

# We delete the last miscellaneous variables

rm(A1_dPMC_Delta,A1_dPMC_Theta,A1_dPMC_Alpha,A1_dPMC_Beta,A1_dPMC_Gamma1,A1_dPMC_Gamma2)


## We have now isolated all PTEs and can proceed to "Compute_null_PTE_test.R

