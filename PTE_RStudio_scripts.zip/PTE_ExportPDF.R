# WITHOUT Stats

pdf("Delta_Summary_PTE.pdf",width=10,height=7)

library(grid)
library(gridExtra)

options(digits=3)

grid.arrange(nrow=1,top="Delta: 'Musicianship/Hemisphere/Direction' summary", tableGrob(Summary_Bands$Delta$Stats$Musicianship))
grid.arrange(nrow=1,top="Delta: 'Motor_Region/Modality/Direction' summary", tableGrob(Summary_Bands$Delta$Stats$Modality))

plot(Summary_Bands$Delta$Plots$Musicianship_BEFORE, main = "Delta band: Musicianship")
plot(Summary_Bands$Delta$Plots$Direction_BEFORE, main = "Delta band: Modality")
plot(Summary_Bands$Delta$Plots$MotorRegion_BEFORE, main = "Delta band: Motor region")

grid.arrange(nrow=1,top="Delta: Number of outliers removed out of 2160 PTEs", tableGrob(summary(Outliers_Bands$Delta$is.outlier)))

plot(Summary_Bands$Delta$Plots$Musicianship_AFTER, main = "Delta band: Musicianship")
plot(Summary_Bands$Delta$Plots$Direction_AFTER, main = "Delta band: Modality")
plot(Summary_Bands$Delta$Plots$MotorRegion_AFTER, main = "Delta band: Motor region")

plot(QQ_Bands$Delta)

grid.arrange(nrow=1,top="Delta: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Delta))

plot(Density_Bands$Delta)
grid.arrange(nrow=1,top="Delta: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Delta))

dev.off()

pdf("Theta_Summary_PTE.pdf",width=10,height=7)

library(grid)
library(gridExtra)

options(digits=3)

grid.arrange(nrow=1,top="Theta: 'Musicianship/Hemisphere/Direction' summary", tableGrob(Summary_Bands$Theta$Stats$Musicianship))
grid.arrange(nrow=1,top="Theta: 'Motor_Region/Modality/Direction' summary", tableGrob(Summary_Bands$Theta$Stats$Modality))

plot(Summary_Bands$Theta$Plots$Musicianship_BEFORE, main = "Theta band: Musicianship")
plot(Summary_Bands$Theta$Plots$Direction_BEFORE, main = "Theta band: Modality")
plot(Summary_Bands$Theta$Plots$MotorRegion_BEFORE, main = "Theta band: Motor region")

grid.arrange(nrow=1,top="Theta: Number of outliers removed out of 2160 PTEs", tableGrob(summary(Outliers_Bands$Theta$is.outlier)))

plot(Summary_Bands$Theta$Plots$Musicianship_AFTER, main = "Theta band: Musicianship")
plot(Summary_Bands$Theta$Plots$Direction_AFTER, main = "Theta band: Modality")
plot(Summary_Bands$Theta$Plots$MotorRegion_AFTER, main = "Theta band: Motor region")

plot(QQ_Bands$Theta)

grid.arrange(nrow=1,top="Theta: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Theta))

plot(Density_Bands$Theta)
grid.arrange(nrow=1,top="Theta: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Theta))

dev.off()

pdf("Alpha_Summary_PTE.pdf",width=10,height=7)

library(grid)
library(gridExtra)

options(digits=3)

grid.arrange(nrow=1,top="Alpha: 'Musicianship/Hemisphere/Direction' summary", tableGrob(Summary_Bands$Alpha$Stats$Musicianship))
grid.arrange(nrow=1,top="Alpha: 'Motor_Region/Modality/Direction' summary", tableGrob(Summary_Bands$Alpha$Stats$Modality))

plot(Summary_Bands$Alpha$Plots$Musicianship_BEFORE, main = "Alpha band: Musicianship")
plot(Summary_Bands$Alpha$Plots$Direction_BEFORE, main = "Alpha band: Modality")
plot(Summary_Bands$Alpha$Plots$MotorRegion_BEFORE, main = "Alpha band: Motor region")

grid.arrange(nrow=1,top="Alpha: Number of outliers removed out of 2160 PTEs", tableGrob(summary(Outliers_Bands$Alpha$is.outlier)))

plot(Summary_Bands$Alpha$Plots$Musicianship_AFTER, main = "Alpha band: Musicianship")
plot(Summary_Bands$Alpha$Plots$Direction_AFTER, main = "Alpha band: Modality")
plot(Summary_Bands$Alpha$Plots$MotorRegion_AFTER, main = "Alpha band: Motor region")

plot(QQ_Bands$Alpha)

grid.arrange(nrow=1,top="Alpha: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Alpha))

plot(Density_Bands$Alpha)
grid.arrange(nrow=1,top="Alpha: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Alpha))

dev.off()

pdf("Beta_Summary_PTE.pdf",width=10,height=7)

library(grid)
library(gridExtra)

options(digits=3)

grid.arrange(nrow=1,top="Beta: 'Musicianship/Hemisphere/Direction' summary", tableGrob(Summary_Bands$Beta$Stats$Musicianship))
grid.arrange(nrow=1,top="Beta: 'Motor_Region/Modality/Direction' summary", tableGrob(Summary_Bands$Beta$Stats$Modality))

plot(Summary_Bands$Beta$Plots$Musicianship_BEFORE, main = "Beta band: Musicianship")
plot(Summary_Bands$Beta$Plots$Direction_BEFORE, main = "Beta band: Modality")
plot(Summary_Bands$Beta$Plots$MotorRegion_BEFORE, main = "Beta band: Motor region")

grid.arrange(nrow=1,top="Beta: Number of outliers removed out of 2160 PTEs", tableGrob(summary(Outliers_Bands$Beta$is.outlier)))

plot(Summary_Bands$Beta$Plots$Musicianship_AFTER, main = "Beta band: Musicianship")
plot(Summary_Bands$Beta$Plots$Direction_AFTER, main = "Beta band: Modality")
plot(Summary_Bands$Beta$Plots$MotorRegion_AFTER, main = "Beta band: Motor region")

plot(QQ_Bands$Beta)

grid.arrange(nrow=1,top="Beta: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Beta))

plot(Density_Bands$Beta)
grid.arrange(nrow=1,top="Beta: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Beta))

dev.off()

options(digits=3)

pdf("Gamma1_Summary_PTE.pdf",width=10,height=7)

library(grid)
library(gridExtra)

options(digits=3)

grid.arrange(nrow=1,top="Gamma1: 'Musicianship/Hemisphere/Direction' summary", tableGrob(Summary_Bands$Gamma1$Stats$Musicianship))
grid.arrange(nrow=1,top="Gamma1: 'Motor_Region/Modality/Direction' summary", tableGrob(Summary_Bands$Gamma1$Stats$Modality))

plot(Summary_Bands$Gamma1$Plots$Musicianship_BEFORE, main = "Gamma1 band: Musicianship")
plot(Summary_Bands$Gamma1$Plots$Direction_BEFORE, main = "Gamma1 band: Modality")
plot(Summary_Bands$Gamma1$Plots$MotorRegion_BEFORE, main = "Gamma1 band: Motor region")

grid.arrange(nrow=1,top="Gamma1: Number of outliers removed out of 2160 PTEs", tableGrob(summary(Outliers_Bands$Gamma1$is.outlier)))

plot(Summary_Bands$Gamma1$Plots$Musicianship_AFTER, main = "Gamma1 band: Musicianship")
plot(Summary_Bands$Gamma1$Plots$Direction_AFTER, main = "Gamma1 band: Modality")
plot(Summary_Bands$Gamma1$Plots$MotorRegion_AFTER, main = "Gamma1 band: Motor region")

plot(QQ_Bands$Gamma1)

grid.arrange(nrow=1,top="Gamma1: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Gamma1))

plot(Density_Bands$Gamma1)
grid.arrange(nrow=1,top="Gamma1: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Gamma1))

dev.off()

pdf("Gamma2_Summary_PTE.pdf",width=10,height=7)

library(grid)
library(gridExtra)

options(digits=3)

grid.arrange(nrow=1,top="Gamma2: 'Musicianship/Hemisphere/Direction' summary", tableGrob(Summary_Bands$Gamma2$Stats$Musicianship))
grid.arrange(nrow=1,top="Gamma2: 'Motor_Region/Modality/Direction' summary", tableGrob(Summary_Bands$Gamma2$Stats$Modality))

plot(Summary_Bands$Gamma2$Plots$Musicianship_BEFORE, main = "Gamma2 band: Musicianship")
plot(Summary_Bands$Gamma2$Plots$Direction_BEFORE, main = "Gamma2 band: Modality")
plot(Summary_Bands$Gamma2$Plots$MotorRegion_BEFORE, main = "Gamma2 band: Motor region")

grid.arrange(nrow=1,top="Gamma2: Number of outliers removed out of 2160 PTEs", tableGrob(summary(Outliers_Bands$Gamma2$is.outlier)))

plot(Summary_Bands$Gamma2$Plots$Musicianship_AFTER, main = "Gamma2 band: Musicianship")
plot(Summary_Bands$Gamma2$Plots$Direction_AFTER, main = "Gamma2 band: Modality")
plot(Summary_Bands$Gamma2$Plots$MotorRegion_AFTER, main = "Gamma2 band: Motor region")

plot(QQ_Bands$Gamma2)

grid.arrange(nrow=1,top="Gamma2: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Gamma2))

plot(Density_Bands$Gamma2)
grid.arrange(nrow=1,top="Gamma2: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Gamma2))

dev.off()

# WITH STATS

pdf("Delta_MIXED_stats_PTE.pdf",width=10,height=7)

library(grid)
library(gridExtra)

options(digits=3)

grid.arrange(nrow=1,top="Delta: 'Musicianship' summary", tableGrob(Summary_Bands$Delta$Stats$Musicianship))
grid.arrange(nrow=1,top="Delta: 'Hemisphere/Modality/Direction' summary", tableGrob(Summary_Bands$Delta$Stats$Modality))

plot(Summary_Bands$Delta$Plots$Musicianship_BEFORE, main = "Delta band: Musicianship")
plot(Summary_Bands$Delta$Plots$Direction_BEFORE, main = "Delta band: Motor Regions")

grid.arrange(nrow=1,top="Delta: Number of outliers removed out of 2160 PTEs", tableGrob(summary(Outliers_Bands$Delta$is.outlier)))

plot(Summary_Bands$Delta$Plots$Musicianship_AFTER, main = "Delta band: Musicianship")
plot(Summary_Bands$Delta$Plots$Direction_AFTER, main = "Delta band: Motor Regions")

plot(QQ_Bands$Delta)

grid.arrange(nrow=1,top="Delta: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Delta))

plot(Density_Bands$Delta)

GLMM1_Delta$Omnibus$p.value <- round(GLMM1_Delta$Omnibus$p.value,3)
GLMM1_Delta$Hem_by_Mod$p.value <- round(GLMM1_Delta$Hem_by_Mod$p.value,3)
GLMM1_Delta$Hem_by_Mod$bonferroni <- round(GLMM1_Delta$Hem_by_Mod$bonferroni,3)
GLMM1_Delta$Mod_by_Dir$p.value <- round(GLMM1_Delta$Mod_by_Dir$p.value,3)
GLMM1_Delta$Mod_by_Dir$bonferroni <- round(GLMM1_Delta$Mod_by_Dir$bonferroni,3)
GLMM1_Delta$Hem_by_Mod_by_Dir$p.value <- round(GLMM1_Delta$Hem_by_Mod_by_Dir$p.value,3)
GLMM1_Delta$Hem_by_Mod_by_Dir$bonferroni <- round(GLMM1_Delta$Hem_by_Mod_by_Dir$bonferroni,3)


grid.arrange(nrow=1,top="Delta: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Delta))
grid.arrange(nrow=1,top="Delta: GLM main effects and interactions", tableGrob(GLMM1_Delta$Omnibus))
grid.arrange(nrow=1,top="Delta: GLM post-hoc test: 'Hemisphere*Modality'", tableGrob(GLMM1_Delta$Hem_by_Mod))
grid.arrange(nrow=1,top="Delta: GLM post-hoc test: 'Modality*Direction'", tableGrob(GLMM1_Delta$Mod_by_Dir))
grid.arrange(nrow=1,top="Delta: GLM post-hoc test: 'Hemisphere*Modality*Direction'", tableGrob(GLMM1_Delta$Hem_by_Mod_by_Dir))

plot(Delta_Boxplot_Interaction1)
plot(Delta_Boxplot_Interaction2)

dev.off()

pdf("Theta_Mixed_stats_PTE.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Theta: 'Musicianship' summary", tableGrob(Summary_Bands$Theta$Stats$Musicianship))
grid.arrange(nrow=1,top="Theta: 'Hemisphere/Modality/Direction' summary", tableGrob(Summary_Bands$Theta$Stats$Modality))

plot(Summary_Bands$Theta$Plots$Musicianship_BEFORE, main = "Theta band: Musicianship")
plot(Summary_Bands$Theta$Plots$Direction_BEFORE, main = "Theta band: Motor Regions")

grid.arrange(nrow=1,top="Theta: Number of outliers removed out of 2160 PTEs", tableGrob(summary(Outliers_Bands$Theta$is.outlier)))

plot(Summary_Bands$Theta$Plots$Musicianship_AFTER, main = "Theta band: Musicianship")
plot(Summary_Bands$Theta$Plots$Direction_AFTER, main = "Theta band: Motor Regions")

plot(QQ_Bands$Theta, main = "Theta band: QQ plot BEFORE outlier removal")

grid.arrange(nrow=1,top="Theta: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Theta))

plot(Density_Bands$Theta, main = "Density plot BEFORE outlier removal")

GLMM1_Theta$Omnibus$p.value <- round(GLMM1_Theta$Omnibus$p.value,3)
GLMM1_Theta$Hem_by_Dir$p.value <- round(GLMM1_Theta$Hem_by_Dir$p.value,3)
GLMM1_Theta$Hem_by_Dir$bonferroni <- round(GLMM1_Theta$Hem_by_Dir$bonferroni,3)
GLMM1_Theta$Mod_by_Dir$p.value <- round(GLMM1_Theta$Mod_by_Dir$p.value,3)
GLMM1_Theta$Mod_by_Dir$bonferroni <- round(GLMM1_Theta$Mod_by_Dir$bonferroni,3)
GLMM1_Theta$Hem_by_Mod_by_Dir$p.value <- round(GLMM1_Theta$Hem_by_Mod_by_Dir$p.value,3)
GLMM1_Theta$Hem_by_Mod_by_Dir$bonferroni <- round(GLMM1_Theta$Hem_by_Mod_by_Dir$bonferroni,3)

grid.arrange(nrow=1,top="Theta: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Theta))
grid.arrange(nrow=1,top="Theta: GLM main effects and interactions", tableGrob(GLMM1_Theta$Omnibus))
grid.arrange(nrow=1,top="Theta: GLM post-hoc test: 'Hemisphere*Direction'", tableGrob(GLMM1_Theta$Hem_by_Dir))
grid.arrange(nrow=1,top="Theta: GLM post-hoc test: 'Modality*Direction'", tableGrob(GLMM1_Theta$Mod_by_Dir))
grid.arrange(nrow=1,top="Theta: GLM post-hoc test: 'Hemisphere*Modality*Direction'", tableGrob(GLMM1_Theta$Hem_by_Mod_by_Dir))

plot(Theta_Boxplot_Interaction1)
plot(Theta_Boxplot_Interaction2)

dev.off()

pdf("Alpha_MIXED_stats_PTE.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Alpha: 'Musicianship' summary", tableGrob(Summary_Bands$Alpha$Stats$Musicianship))
grid.arrange(nrow=1,top="Alpha: 'Hemisphere/Modality/Direction' summary", tableGrob(Summary_Bands$Alpha$Stats$Modality))

plot(Summary_Bands$Alpha$Plots$Musicianship_BEFORE, main = "Alpha band: Musicianship")
plot(Summary_Bands$Alpha$Plots$Direction_BEFORE, main = "Alpha band: Motor Regions")

grid.arrange(nrow=1,top="Alpha: Number of outliers removed out of 2160 PTEs", tableGrob(summary(Outliers_Bands$Alpha$is.outlier)))

plot(Summary_Bands$Alpha$Plots$Musicianship_AFTER, main = "Alpha band: Musicianship")
plot(Summary_Bands$Alpha$Plots$Direction_AFTER, main = "Alpha band: Motor Regions")

plot(QQ_Bands$Alpha, main = "Alpha band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Alpha: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Alpha))

plot(Density_Bands$Alpha, main = "Density plot after outlier removal")

GLMM1_Alpha$Omnibus$p.value <- round(GLMM1_Alpha$Omnibus$p.value,3)
GLMM1_Alpha$Mod_by_Dir$p.value <- round(GLMM1_Alpha$Mod_by_Dir$p.value,3)
GLMM1_Alpha$Mod_by_Dir$bonferroni <- round(GLMM1_Alpha$Mod_by_Dir$bonferroni,3)
GLMM1_Alpha$Hem_by_Mod_by_Dir$p.value <- round(GLMM1_Alpha$Hem_by_Mod_by_Dir$p.value,3)
GLMM1_Alpha$Hem_by_Mod_by_Dir$bonferroni <- round(GLMM1_Alpha$Hem_by_Mod_by_Dir$bonferroni,3)

grid.arrange(nrow=1,top="Alpha: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Alpha))
grid.arrange(nrow=1,top="Alpha: GLM main effects and interactions", tableGrob(GLMM1_Alpha$Omnibus))
grid.arrange(nrow=1,top="Alpha: GLM post-hoc test: 'Modality*Direction'", tableGrob(GLMM1_Alpha$Mod_by_Dir))
grid.arrange(nrow=1,top="Alpha: GLM post-hoc test: 'Hemisphere*Modality*Direction'", tableGrob(GLMM1_Alpha$Hem_by_Mod_by_Dir))

plot(Alpha_Boxplot_Interaction1)

dev.off()

pdf("Beta_MIXED_stats_PTE.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Beta: 'Musicianship' summary", tableGrob(Summary_Bands$Beta$Stats$Musicianship))
grid.arrange(nrow=1,top="Beta: 'Hemisphere/Modality/Direction' summary", tableGrob(Summary_Bands$Beta$Stats$Modality))

plot(Summary_Bands$Beta$Plots$Musicianship_BEFORE, main = "Beta band: Musicianship")
plot(Summary_Bands$Beta$Plots$Direction_BEFORE, main = "Beta band: Motor Regions")

grid.arrange(nrow=1,top="Beta: Number of outliers removed out of 2160 PTEs", tableGrob(summary(Outliers_Bands$Beta$is.outlier)))

plot(Summary_Bands$Beta$Plots$Musicianship_AFTER, main = "Beta band: Musicianship")
plot(Summary_Bands$Beta$Plots$Direction_AFTER, main = "Beta band: Motor Regions")

plot(QQ_Bands$Beta, main = "Beta band: QQ plot BEFORE outlier removal")

grid.arrange(nrow=1,top="Beta: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Beta))

plot(Density_Bands$Beta, main = "Density plot BEFORE outlier removal")

GLMM1_Beta$Omnibus$p.value <- round(GLMM1_Beta$Omnibus$p.value,3)
GLMM1_Beta$Mod_by_Dir$p.value <- round(GLMM1_Beta$Mod_by_Dir$p.value,3)
GLMM1_Beta$Mod_by_Dir$bonferroni <- round(GLMM1_Beta$Mod_by_Dir$bonferroni,3)


grid.arrange(nrow=1,top="Beta: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Beta))
grid.arrange(nrow=1,top="Beta: GLM main effects and interactions", tableGrob(GLMM1_Beta$Omnibus))
grid.arrange(nrow=1,top="Beta: GLM post-hoc test: 'Modality*Direction'", tableGrob(GLMM1_Beta$Mod_by_Dir))

plot(Beta_Boxplot2)
plot(Beta_Boxplot_Interaction)

dev.off()

options(digits=3)

pdf("Gamma2_MIXED_stats_PTE.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Gamma2: 'Musicianship' summary", tableGrob(Summary_Bands$Gamma2$Stats$Musicianship))
grid.arrange(nrow=1,top="Gamma2: 'Hemisphere/Modality/Direction' summary", tableGrob(Summary_Bands$Gamma2$Stats$Modality))

plot(Summary_Bands$Gamma2$Plots$Musicianship_BEFORE, main = "Gamma2 band: Musicianship")
plot(Summary_Bands$Gamma2$Plots$Direction_BEFORE, main = "Gamma2 band: Motor Regions")

grid.arrange(nrow=1,top="Gamma2: Number of outliers removed out of 2160 PTEs", tableGrob(summary(Outliers_Bands$Gamma2$is.outlier)))

plot(Summary_Bands$Gamma2$Plots$Musicianship_AFTER, main = "Gamma2 band: Musicianship")
plot(Summary_Bands$Gamma2$Plots$Direction_AFTER, main = "Gamma2 band: Motor Regions")

plot(QQ_Bands$Gamma2, main = "Gamma2 band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Gamma2: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Gamma2))

plot(Density_Bands$Gamma2, main = "Density plot after outlier removal")

GLMM1_Gamma2$Omnibus$p.value <- round(GLMM1_Gamma2$Omnibus$p.value,3)
GLMM1_Gamma2$Hem_by_Mod$p.value <- round(GLMM1_Gamma2$Hem_by_Mod$p.value,3)
GLMM1_Gamma2$Hem_by_Mod$bonferroni <- round(GLMM1_Gamma2$Hem_by_Mod$bonferroni,3)
GLMM1_Gamma2$Mod_by_Dir$p.value <- round(GLMM1_Gamma2$Mod_by_Dir$p.value,3)
GLMM1_Gamma2$Mod_by_Dir$bonferroni <- round(GLMM1_Gamma2$Mod_by_Dir$bonferroni,3)
GLMM1_Gamma2$Hem_by_Mod_by_Dir$p.value <- round(GLMM1_Gamma2$Hem_by_Mod_by_Dir$p.value,3)
GLMM1_Gamma2$Hem_by_Mod_by_Dir$bonferroni <- round(GLMM1_Gamma2$Hem_by_Mod_by_Dir$bonferroni,3)

grid.arrange(nrow=1,top="Gamma2: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Gamma2))
grid.arrange(nrow=1,top="Gamma2: GLM main effects and interactions", tableGrob(GLMM1_Gamma2$Omnibus))
grid.arrange(nrow=1,top="Gamma2: GLM post-hoc test: 'Hemisphere*Modality'", tableGrob(GLMM1_Gamma2$Hem_by_Mod))
grid.arrange(nrow=1,top="Gamma2: GLM post-hoc test: 'Modality*Direction'", tableGrob(GLMM1_Gamma2$Mod_by_Dir))
grid.arrange(nrow=1,top="Gamma2: GLM post-hoc test: 'Hemisphere*Modality*Direction'", tableGrob(GLMM1_Gamma2$Hem_by_Mod_by_Dir))

plot(Gamma2_Boxplot_Interaction1)
plot(Gamma2_Boxplot_Interaction3)

dev.off()

pdf("Gamma2_MIXED_stats_PTE.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Gamma2: 'Musicianship' summary", tableGrob(Summary_Bands$Gamma2$Stats$Musicianship))
grid.arrange(nrow=1,top="Gamma2: 'Hemisphere/Modality/Direction' summary", tableGrob(Summary_Bands$Gamma2$Stats$Modality))

plot(Summary_Bands$Gamma2$Plots$Musicianship_BEFORE, main = "Gamma2 band: Musicianship")
plot(Summary_Bands$Gamma2$Plots$Direction_BEFORE, main = "Gamma2 band: Motor Regions")

grid.arrange(nrow=1,top="Gamma2: Number of outliers removed out of 2160 PTEs", tableGrob(summary(Outliers_Bands$Gamma2$is.outlier)))

plot(Summary_Bands$Gamma2$Plots$Musicianship_AFTER, main = "Gamma2 band: Musicianship")
plot(Summary_Bands$Gamma2$Plots$Direction_AFTER, main = "Gamma2 band: Motor Regions")

plot(QQ_Bands$Gamma2, main = "Gamma2 band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Gamma2: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Gamma2))

plot(Density_Bands$Gamma2, main = "Density plot after outlier removal")

GLMM1_Gamma2$Omnibus$p.value <- round(GLMM1_Gamma2$Omnibus$p.value,3)
GLMM1_Gamma2$Hem_by_Dir_by_Dir$p.value <- round(GLMM1_Gamma2$Hem_by_Dir$p.value,3)
GLMM1_Gamma2$Hem_by_Dir$bonferroni <- round(GLMM1_Gamma2$Hem_by_Dir$bonferroni,3)
GLMM1_Gamma2$Mod_by_Dir$p.value <- round(GLMM1_Gamma2$Mod_by_Dir$p.value,3)
GLMM1_Gamma2$Mod_by_Dir$bonferroni <- round(GLMM1_Gamma2$Mod_by_Dir$bonferroni,3)
GLMM1_Gamma2$Hem_by_Mod_by_Dir$p.value <- round(GLMM1_Gamma2$Hem_by_Mod_by_Dir$p.value,3)
GLMM1_Gamma2$Hem_by_Mod_by_Dir$bonferroni <- round(GLMM1_Gamma2$Hem_by_Mod_by_Dir$bonferroni,3)

grid.arrange(nrow=1,top="Gamma2: Levene's homogeneity of variances test BEFORE outlier removal", tableGrob(Homogeneity_Bands$Gamma2))
grid.arrange(nrow=1,top="Gamma2: GLM main effects and interactions", tableGrob(GLMM1_Gamma2$Omnibus))
grid.arrange(nrow=1,top="Gamma2: GLM post-hoc test: 'Hemisphere*Direction'", tableGrob(GLMM1_Gamma2$Hem_by_Dir))
grid.arrange(nrow=1,top="Gamma2: GLM post-hoc test: 'Modality*Direction'", tableGrob(GLMM1_Gamma2$Mod_by_Dir))
grid.arrange(nrow=1,top="Gamma2: GLM post-hoc test: 'Hemisphere*Modality*Direction'", tableGrob(GLMM1_Gamma2$Hem_by_Mod_by_Dir))

plot(Gamma2_Boxplot_Interaction1)
plot(Gamma2_Boxplot_Interaction2)

dev.off()