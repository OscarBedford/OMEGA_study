

## BOTTOM-UP DIRECTIONALITY



######################################################
### STEP 1: Compute A1-M1 null test for LEFT and RIGHT
######################################################

# List of band names
band_names <- c("delta", "theta", "alpha", "beta", "gamma1", "gamma2")

# Convert the relevant columns to numeric
for (band in band_names) {
  value_column <- paste0(toupper(substr(band, 1, 1)), substr(band, 2, nchar(band)), "_Values")
  
  A1_M1_Real_Bands[[band]][[value_column]] <- as.numeric(A1_M1_Real_Bands[[band]][[value_column]])
  A1_M1_Flipped_Bands[[band]][[value_column]] <- as.numeric(A1_M1_Flipped_Bands[[band]][[value_column]])
}

# Placeholder for t-test results
t_test_results <- list()

# Loop through each band
for (band in band_names) {
  # Access the dataframes for the current band
  real_band_df <- A1_M1_Real_Bands[[band]]
  flipped_band_df <- A1_M1_Flipped_Bands[[band]]
  
  # Extract values from the XXXX_Values column where Hemisphere is 'L'
  real_values <- real_band_df[real_band_df$Hemisphere == 'L', ]
  flipped_values <- flipped_band_df[flipped_band_df$Hemisphere == 'L', ]
  
  # Construct the column name for values dynamically
  value_column <- paste0(toupper(substr(band, 1, 1)), substr(band, 2, nchar(band)), "_Values")
  
  # Perform the one-tailed t-test (left mean < right mean)
  t_test_result <- t.test(real_values[[value_column]], 
                          flipped_values[[value_column]], 
                          alternative = "less",
                          var.equal = TRUE)
  
  # Store the result in the list
  t_test_results[[band]] <- t_test_result
}


#########################################################
### STEP 2: Compute A1-vPMC null test for LEFT and RIGHT
#########################################################

# List of band names
band_names <- c("delta", "theta", "alpha", "beta", "gamma1", "gamma2")

# Convert the relevant columns to numeric
for (band in band_names) {
  value_column <- paste0(toupper(substr(band, 1, 1)), substr(band, 2, nchar(band)), "_Values")
  
  A1_vPMC_Real_Bands[[band]][[value_column]] <- as.numeric(A1_vPMC_Real_Bands[[band]][[value_column]])
  A1_vPMC_Flipped_Bands[[band]][[value_column]] <- as.numeric(A1_vPMC_Flipped_Bands[[band]][[value_column]])
}

# Placeholder for t-test results
t_test_results <- list()

# Loop through each band
for (band in band_names) {
  # Access the dataframes for the current band
  real_band_df <- A1_vPMC_Real_Bands[[band]]
  flipped_band_df <- A1_vPMC_Flipped_Bands[[band]]
  
  # Extract values from the XXXX_Values column where Hemisphere is 'L'
  real_values <- real_band_df[real_band_df$Hemisphere == 'L', ]
  flipped_values <- flipped_band_df[flipped_band_df$Hemisphere == 'L', ]
  
  # Construct the column name for values dynamically
  value_column <- paste0(toupper(substr(band, 1, 1)), substr(band, 2, nchar(band)), "_Values")
  
  # Perform the one-tailed t-test (left mean < right mean)
  t_test_result <- t.test(real_values[[value_column]], 
                          flipped_values[[value_column]], 
                          alternative = "less")
  
  # Store the result in the list
  t_test_results[[band]] <- t_test_result
}

rm(t_test_result)



#########################################################
### STEP 3: Compute A1-dPMC null test for LEFT and RIGHT
#########################################################

# List of band names
band_names <- c("delta", "theta", "alpha", "beta", "gamma1", "gamma2")

# Convert the relevant columns to numeric
for (band in band_names) {
  value_column <- paste0(toupper(substr(band, 1, 1)), substr(band, 2, nchar(band)), "_Values")
  
  A1_dPMC_Real_Bands[[band]][[value_column]] <- as.numeric(A1_dPMC_Real_Bands[[band]][[value_column]])
  A1_dPMC_Flipped_Bands[[band]][[value_column]] <- as.numeric(A1_dPMC_Flipped_Bands[[band]][[value_column]])
}

# Placeholder for t-test results
t_test_results <- list()

# Loop through each band
for (band in band_names) {
  # Access the dataframes for the current band
  real_band_df <- A1_dPMC_Real_Bands[[band]]
  flipped_band_df <- A1_dPMC_Flipped_Bands[[band]]
  
  # Extract values from the XXXX_Values column where Hemisphere is 'L'
  real_values <- real_band_df[real_band_df$Hemisphere == 'L', ]
  flipped_values <- flipped_band_df[flipped_band_df$Hemisphere == 'L', ]
  
  # Construct the column name for values dynamically
  value_column <- paste0(toupper(substr(band, 1, 1)), substr(band, 2, nchar(band)), "_Values")
  
  # Perform the one-tailed t-test (left mean < right mean)
  t_test_result <- t.test(real_values[[value_column]], 
                          flipped_values[[value_column]], 
                          alternative = "less")
  
  # Store the result in the list
  t_test_results[[band]] <- t_test_result
}

rm(t_test_result)





## TOP-DOWN DIRECTIONALITY



######################################################
### STEP 1: Compute A1-M1 null test for LEFT and RIGHT
######################################################

# List of band names
band_names <- c("delta", "theta", "alpha", "beta", "gamma1", "gamma2")

# Convert the relevant columns to numeric
for (band in band_names) {
  value_column <- paste0(toupper(substr(band, 1, 1)), substr(band, 2, nchar(band)), "_Values")
  
  M1_A1_Real_Bands[[band]][[value_column]] <- as.numeric(M1_A1_Real_Bands[[band]][[value_column]])
  M1_A1_Flipped_Bands[[band]][[value_column]] <- as.numeric(M1_A1_Flipped_Bands[[band]][[value_column]])
}

# Placeholder for t-test results
t_test_results <- list()

# Loop through each band
for (band in band_names) {
  # Access the dataframes for the current band
  real_band_df <- M1_A1_Real_Bands[[band]]
  flipped_band_df <- M1_A1_Flipped_Bands[[band]]
  
  # Extract values from the XXXX_Values column where Hemisphere is 'L'
  real_values <- real_band_df[real_band_df$Hemisphere == 'L', ]
  flipped_values <- flipped_band_df[flipped_band_df$Hemisphere == 'L', ]
  
  # Construct the column name for values dynamically
  value_column <- paste0(toupper(substr(band, 1, 1)), substr(band, 2, nchar(band)), "_Values")
  
  # Perform the one-tailed t-test (left mean < right mean)
  t_test_result <- t.test(real_values[[value_column]], 
                          flipped_values[[value_column]], 
                          alternative = "less")
  
  # Store the result in the list
  t_test_results[[band]] <- t_test_result
}
rm(t_test_result)


#########################################################
### STEP 2: Compute A1-vPMC null test for LEFT and RIGHT
#########################################################

# List of band names
band_names <- c("delta", "theta", "alpha", "beta", "gamma1", "gamma2")

# Convert the relevant columns to numeric
for (band in band_names) {
  value_column <- paste0(toupper(substr(band, 1, 1)), substr(band, 2, nchar(band)), "_Values")
  
  vPMC_A1_Real_Bands[[band]][[value_column]] <- as.numeric(vPMC_A1_Real_Bands[[band]][[value_column]])
  vPMC_A1_Flipped_Bands[[band]][[value_column]] <- as.numeric(vPMC_A1_Flipped_Bands[[band]][[value_column]])
}

# Placeholder for t-test results
t_test_results <- list()

# Loop through each band
for (band in band_names) {
  # Access the dataframes for the current band
  real_band_df <- vPMC_A1_Real_Bands[[band]]
  flipped_band_df <- vPMC_A1_Flipped_Bands[[band]]
  
  # Extract values from the XXXX_Values column where Hemisphere is 'L'
  real_values <- real_band_df[real_band_df$Hemisphere == 'L', ]
  flipped_values <- flipped_band_df[flipped_band_df$Hemisphere == 'L', ]
  
  # Construct the column name for values dynamically
  value_column <- paste0(toupper(substr(band, 1, 1)), substr(band, 2, nchar(band)), "_Values")
  
  # Perform the one-tailed t-test (left mean < right mean)
  t_test_result <- t.test(real_values[[value_column]], 
                          flipped_values[[value_column]], 
                          alternative = "less")
  
  # Store the result in the list
  t_test_results[[band]] <- t_test_result
}

rm(t_test_result)



#########################################################
### STEP 3: Compute A1-dPMC null test for LEFT and RIGHT
#########################################################

# List of band names
band_names <- c("delta", "theta", "alpha", "beta", "gamma1", "gamma2")

# Convert the relevant columns to numeric
for (band in band_names) {
  value_column <- paste0(toupper(substr(band, 1, 1)), substr(band, 2, nchar(band)), "_Values")
  
  dPMC_A1_Real_Bands[[band]][[value_column]] <- as.numeric(dPMC_A1_Real_Bands[[band]][[value_column]])
  dPMC_A1_Flipped_Bands[[band]][[value_column]] <- as.numeric(dPMC_A1_Flipped_Bands[[band]][[value_column]])
}

# Placeholder for t-test results
t_test_results <- list()

# Loop through each band
for (band in band_names) {
  # Access the dataframes for the current band
  real_band_df <- dPMC_A1_Real_Bands[[band]]
  flipped_band_df <- dPMC_A1_Flipped_Bands[[band]]
  
  # Extract values from the XXXX_Values column where Hemisphere is 'L'
  real_values <- real_band_df[real_band_df$Hemisphere == 'L', ]
  flipped_values <- flipped_band_df[flipped_band_df$Hemisphere == 'L', ]
  
  # Construct the column name for values dynamically
  value_column <- paste0(toupper(substr(band, 1, 1)), substr(band, 2, nchar(band)), "_Values")
  
  # Perform the one-tailed t-test (left mean < right mean)
  t_test_result <- t.test(real_values[[value_column]], 
                          flipped_values[[value_column]], 
                          alternative = "less")
  
  # Store the result in the list
  t_test_results[[band]] <- t_test_result
}

rm(t_test_result)




