
########################################################################################
## CALCULATE AND PLOT ANOVAs BASED on ANOVA_BANDS variable created with 'ExtractAM-VM.R'
########################################################################################

###############################################
## First we extract the dataframe for each Band
###############################################

Delta <- data.frame(ANOVA_BANDS$delta)
Theta <- data.frame(ANOVA_BANDS$theta)
Alpha <- data.frame(ANOVA_BANDS$alpha)
Beta <- data.frame(ANOVA_BANDS$beta)
Gamma1 <- data.frame(ANOVA_BANDS$gamma1)
Gamma2 <- data.frame(ANOVA_BANDS$gamma2)

##################################################################################
## It's important that we transform the AM PTE columns from class 'list' to 'numeric'
##################################################################################

Delta$A1.M1 <- as.numeric(as.character(Delta$A1.M1))
Delta$A1.vPMC <- as.numeric(as.character(Delta$A1.vPMC))
Delta$A1.dPMC <- as.numeric(as.character(Delta$A1.dPMC))

Theta$A1.M1 <- as.numeric(as.character(Theta$A1.M1))
Theta$A1.vPMC <- as.numeric(as.character(Theta$A1.vPMC))
Theta$A1.dPMC <- as.numeric(as.character(Theta$A1.dPMC))

Alpha$A1.M1 <- as.numeric(as.character(Alpha$A1.M1))
Alpha$A1.vPMC <- as.numeric(as.character(Alpha$A1.vPMC))
Alpha$A1.dPMC <- as.numeric(as.character(Alpha$A1.dPMC))

Beta$A1.M1 <- as.numeric(as.character(Beta$A1.M1))
Beta$A1.vPMC <- as.numeric(as.character(Beta$A1.vPMC))
Beta$A1.dPMC <- as.numeric(as.character(Beta$A1.dPMC))

Gamma1$A1.M1 <- as.numeric(as.character(Gamma1$A1.M1))
Gamma1$A1.vPMC <- as.numeric(as.character(Gamma1$A1.vPMC))
Gamma1$A1.dPMC <- as.numeric(as.character(Gamma1$A1.dPMC))

Gamma2$A1.M1 <- as.numeric(as.character(Gamma2$A1.M1))
Gamma2$A1.vPMC <- as.numeric(as.character(Gamma2$A1.vPMC))
Gamma2$A1.dPMC <- as.numeric(as.character(Gamma2$A1.dPMC))

#########################################
## Same for Motor to Auditory connections
#########################################

Delta$M1.A1 <- as.numeric(as.character(Delta$M1.A1))
Delta$vPMC.A1 <- as.numeric(as.character(Delta$vPMC.A1))
Delta$dPMC.A1 <- as.numeric(as.character(Delta$dPMC.A1))

Theta$M1.A1 <- as.numeric(as.character(Theta$M1.A1))
Theta$vPMC.A1 <- as.numeric(as.character(Theta$vPMC.A1))
Theta$dPMC.A1 <- as.numeric(as.character(Theta$dPMC.A1))

Alpha$M1.A1 <- as.numeric(as.character(Alpha$M1.A1))
Alpha$vPMC.A1 <- as.numeric(as.character(Alpha$vPMC.A1))
Alpha$dPMC.A1 <- as.numeric(as.character(Alpha$dPMC.A1))

Beta$M1.A1 <- as.numeric(as.character(Beta$M1.A1))
Beta$vPMC.A1 <- as.numeric(as.character(Beta$vPMC.A1))
Beta$dPMC.A1 <- as.numeric(as.character(Beta$dPMC.A1))

Gamma1$M1.A1 <- as.numeric(as.character(Gamma1$M1.A1))
Gamma1$vPMC.A1 <- as.numeric(as.character(Gamma1$vPMC.A1))
Gamma1$dPMC.A1 <- as.numeric(as.character(Gamma1$dPMC.A1))

Gamma2$M1.A1 <- as.numeric(as.character(Gamma2$M1.A1))
Gamma2$vPMC.A1 <- as.numeric(as.character(Gamma2$vPMC.A1))
Gamma2$dPMC.A1 <- as.numeric(as.character(Gamma2$dPMC.A1))

##################################################
## Same for the visual variables (Visual to Motor)
##################################################

Delta$V1.M1 <- as.numeric(as.character(Delta$V1.M1))
Delta$V1.vPMC <- as.numeric(as.character(Delta$V1.vPMC))
Delta$V1.dPMC <- as.numeric(as.character(Delta$V1.dPMC))

Theta$V1.M1 <- as.numeric(as.character(Theta$V1.M1))
Theta$V1.vPMC <- as.numeric(as.character(Theta$V1.vPMC))
Theta$V1.dPMC <- as.numeric(as.character(Theta$V1.dPMC))

Alpha$V1.M1 <- as.numeric(as.character(Alpha$V1.M1))
Alpha$V1.vPMC <- as.numeric(as.character(Alpha$V1.vPMC))
Alpha$V1.dPMC <- as.numeric(as.character(Alpha$V1.dPMC))

Beta$V1.M1 <- as.numeric(as.character(Beta$V1.M1))
Beta$V1.vPMC <- as.numeric(as.character(Beta$V1.vPMC))
Beta$V1.dPMC <- as.numeric(as.character(Beta$V1.dPMC))

Gamma1$V1.M1 <- as.numeric(as.character(Gamma1$V1.M1))
Gamma1$V1.vPMC <- as.numeric(as.character(Gamma1$V1.vPMC))
Gamma1$V1.dPMC <- as.numeric(as.character(Gamma1$V1.dPMC))

Gamma2$V1.M1 <- as.numeric(as.character(Gamma2$V1.M1))
Gamma2$V1.vPMC <- as.numeric(as.character(Gamma2$V1.vPMC))
Gamma2$V1.dPMC <- as.numeric(as.character(Gamma2$V1.dPMC))

##################################################
## Same for the visual variables (Motor to Visual)
##################################################

Delta$M1.V1 <- as.numeric(as.character(Delta$M1.V1))
Delta$vPMC.V1 <- as.numeric(as.character(Delta$vPMC.V1))
Delta$dPMC.V1 <- as.numeric(as.character(Delta$dPMC.V1))

Theta$M1.V1 <- as.numeric(as.character(Theta$M1.V1))
Theta$vPMC.V1 <- as.numeric(as.character(Theta$vPMC.V1))
Theta$dPMC.V1 <- as.numeric(as.character(Theta$dPMC.V1))

Alpha$M1.V1 <- as.numeric(as.character(Alpha$M1.V1))
Alpha$vPMC.V1 <- as.numeric(as.character(Alpha$vPMC.V1))
Alpha$dPMC.V1 <- as.numeric(as.character(Alpha$dPMC.V1))

Beta$M1.V1 <- as.numeric(as.character(Beta$M1.V1))
Beta$vPMC.V1 <- as.numeric(as.character(Beta$vPMC.V1))
Beta$dPMC.V1 <- as.numeric(as.character(Beta$dPMC.V1))

Gamma1$M1.V1 <- as.numeric(as.character(Gamma1$M1.V1))
Gamma1$vPMC.V1 <- as.numeric(as.character(Gamma1$vPMC.V1))
Gamma1$dPMC.V1 <- as.numeric(as.character(Gamma1$dPMC.V1))

Gamma2$M1.V1 <- as.numeric(as.character(Gamma2$M1.V1))
Gamma2$vPMC.V1 <- as.numeric(as.character(Gamma2$vPMC.V1))
Gamma2$dPMC.V1 <- as.numeric(as.character(Gamma2$dPMC.V1))

##################################################################################
## It's important that we transform the Anova factors from class 'list' to 'factor'
##################################################################################

Delta$ID <- as.factor(as.character(Delta$ID))
Delta$Hemisphere <- as.factor(as.character(Delta$Hemisphere))
Delta$Musicianship <- as.factor(as.character(Delta$Musicianship))

Theta$ID <- as.factor(as.character(Theta$ID))
Theta$Hemisphere <- as.factor(as.character(Theta$Hemisphere))
Theta$Musicianship <- as.factor(as.character(Theta$Musicianship))

Alpha$ID <- as.factor(as.character(Alpha$ID))
Alpha$Hemisphere <- as.factor(as.character(Alpha$Hemisphere))
Alpha$Musicianship <- as.factor(as.character(Alpha$Musicianship))

Beta$ID <- as.factor(as.character(Beta$ID))
Beta$Hemisphere <- as.factor(as.character(Beta$Hemisphere))
Beta$Musicianship <- as.factor(as.character(Beta$Musicianship))

Gamma1$ID <- as.factor(as.character(Gamma1$ID))
Gamma1$Hemisphere <- as.factor(as.character(Gamma1$Hemisphere))
Gamma1$Musicianship <- as.factor(as.character(Gamma1$Musicianship))

Gamma2$ID <- as.factor(as.character(Gamma2$ID))
Gamma2$Hemisphere <- as.factor(as.character(Gamma2$Hemisphere))
Gamma2$Musicianship <- as.factor(as.character(Gamma2$Musicianship))

###################################################
## We need to re-structure our tables using 'tidyr'
###################################################

# Uncomment this if you haven't installed 'tidyr' yet:
# install.packages("tidyr")

# First, we will stack all PTE rows into one column:

library(tidyr)

Delta <- pivot_longer(Delta, cols=3:14, names_to = "Connection", values_to = "PTE")
Theta <- pivot_longer(Theta, cols=3:14, names_to = "Connection", values_to = "PTE")
Alpha <- pivot_longer(Alpha, cols=3:14, names_to = "Connection", values_to = "PTE")
Beta <- pivot_longer(Beta, cols=3:14, names_to = "Connection", values_to = "PTE")
Gamma1 <- pivot_longer(Gamma1, cols=3:14, names_to = "Connection", values_to = "PTE")
Gamma2 <- pivot_longer(Gamma2, cols=3:14, names_to = "Connection", values_to = "PTE")

# Then we will create a new column called Modality and add it to our tables

Modality <- list("Auditory",
                 "Auditory",
                 "Auditory",
                 "Auditory",
                 "Auditory",
                 "Auditory",
                 "Visual",
                 "Visual",
                 "Visual",
                 "Visual",
                 "Visual",
                 "Visual")

Modality <- (rep(Modality, 180))

Delta$Modality <- Modality
Theta$Modality <- Modality
Alpha$Modality <- Modality
Beta$Modality <- Modality
Gamma1$Modality <- Modality
Gamma2$Modality <- Modality

Delta$Modality <- as.factor(as.character(Delta$Modality))
Theta$Modality <- as.factor(as.character(Theta$Modality))
Alpha$Modality <- as.factor(as.character(Alpha$Modality))
Beta$Modality <- as.factor(as.character(Beta$Modality))
Gamma1$Modality <- as.factor(as.character(Gamma1$Modality))
Gamma2$Modality <- as.factor(as.character(Gamma2$Modality))

rm(Modality)

# Now we will create a variable called direction 

Direction <- list("S2M",
                 "M2S",
                 "S2M",
                 "M2S",
                 "S2M",
                 "M2S",
                 "S2M",
                 "M2S",
                 "S2M",
                 "M2S",
                 "S2M",
                 "M2S")

Direction <- (rep(Direction, 180))

Delta$Direction <- Direction
Theta$Direction <- Direction
Alpha$Direction <- Direction
Beta$Direction <- Direction
Gamma1$Direction <- Direction
Gamma2$Direction <- Direction

Delta$Direction <- as.factor(as.character(Delta$Direction))
Theta$Direction <- as.factor(as.character(Theta$Direction))
Alpha$Direction <- as.factor(as.character(Alpha$Direction))
Beta$Direction <- as.factor(as.character(Beta$Direction))
Gamma1$Direction <- as.factor(as.character(Gamma1$Direction))
Gamma2$Direction <- as.factor(as.character(Gamma2$Direction))

rm(Direction)

#Finally, we will create a variable called "Motor_Region" 

Motor_Region <- list("M1",
                 "M1",
                 "vPMC",
                 "vPMC",
                 "dPMC",
                 "dPMC",
                 "M1",
                 "M1",
                 "vPMC",
                 "vPMC",
                 "dPMC",
                 "dPMC")

Motor_Region <- (rep(Motor_Region, 180))

Delta$Motor_Region <- Motor_Region
Theta$Motor_Region <- Motor_Region
Alpha$Motor_Region <- Motor_Region
Beta$Motor_Region <- Motor_Region
Gamma1$Motor_Region <- Motor_Region
Gamma2$Motor_Region <- Motor_Region

Delta$Motor_Region <- as.factor(as.character(Delta$Motor_Region))
Theta$Motor_Region <- as.factor(as.character(Theta$Motor_Region))
Alpha$Motor_Region <- as.factor(as.character(Alpha$Motor_Region))
Beta$Motor_Region <- as.factor(as.character(Beta$Motor_Region))
Gamma1$Motor_Region <- as.factor(as.character(Gamma1$Motor_Region))
Gamma2$Motor_Region <- as.factor(as.character(Gamma2$Motor_Region))

# We will re-order the columns:

Delta <- Delta[, c(1, 2, 3, 4, 7, 8, 6, 5)]
Theta <- Theta[, c(1, 2, 3, 4, 7, 8, 6, 5)]
Alpha <- Alpha[, c(1, 2, 3, 4, 7, 8, 6, 5)]
Beta <- Beta [, c(1, 2, 3, 4, 7, 8, 6, 5)]
Gamma1 <- Gamma1 [, c(1, 2, 3, 4, 7, 8, 6, 5)]
Gamma2 <- Gamma2 [, c(1, 2, 3, 4, 7, 8, 6, 5)]

# Convert Motor_Region into factor

Delta$Connection <- as.factor(as.character(Delta$Connection))
Theta$Connection <- as.factor(as.character(Theta$Connection))
Alpha$Connection <- as.factor(as.character(Alpha$Connection))
Beta$Connection <- as.factor(as.character(Beta$Connection))
Gamma1$Connection <- as.factor(as.character(Gamma1$Connection))
Gamma2$Connection <- as.factor(as.character(Gamma2$Connection))

###################################################################
## We're ready to create the aov variables, as an intermediate step
###################################################################

## NOTE: the formula is not correct yet

aov_Delta <- aov(PTE~Musicianship*Hemisphere*Modality*Motor_Region + Error(ID/(Hemisphere*Modality*Motor_Region)) + Musicianship,data=Delta)
aov_Theta <- aov(PTE~Musicianship*Hemisphere*Modality*Motor_Region,data=Theta)
aov_Alpha <- aov(PTE~Musicianship*Hemisphere*Modality*Motor_Region,data=Alpha)
aov_Beta <- aov(PTE~Musicianship*Hemisphere*Modality*Motor_Region,data=Beta)
aov_Gamma1 <- aov(PTE~Musicianship*Hemisphere*Modality*Motor_Region,data=Gamma1)
aov_Gamma2 <- aov(PTE~Musicianship*Hemisphere*Modality*Motor_Region,data=Gamma2)

Summary_Delta <- summary.aov(aov_Delta)
Summary_Theta <- summary.aov(aov_Theta)
Summary_Alpha <- summary.aov(aov_Delta)
Summary_Beta <- summary.aov(aov_Beta)
Summary_Gamma1 <- summary.aov(aov_Gamma1)
Summary_Gamma2 <- summary.aov(aov_Gamma2)

########################################################################
## Now we use the aov variables to create the definitive ANOVA variables
########################################################################

ANOVA_Delta <- anova(aov_Delta)
ANOVA_Theta <- anova(aov_Theta)
ANOVA_Alpha <- anova(aov_Alpha)
ANOVA_Beta <- anova(aov_Beta)
ANOVA_Gamma1 <- anova(aov_Gamma1)
ANOVA_Gamma2 <- anova(aov_Gamma2)

###############################
## We're finally ready to plot!
###############################

# But first we will create the pdf filename where we will save the plot:

pdf("ANOVA_6freqbands_PTE_MainEffects.pdf")

# Now we make the 18 plots (6bands*3connections) 

par(mar=c(6, 6, 6, 6))
plot(PTE~Musicianship,data=Delta, main = "Delta band: Musicianship", sub = sprintf ("p-value = %s",round(ANOVA_Delta$`Pr(>F)`[1],digits=4)))
plot(PTE~Hemisphere,data=Delta, main = "Delta band: Hemisphere", sub = sprintf ("p-value = %s",round(ANOVA_Delta$`Pr(>F)`[2],digits=4)))
plot(PTE~Modality,data=Delta, main = "Delta band: Modality", sub = sprintf ("p-value = %s",round(ANOVA_Delta$`Pr(>F)`[3],digits=4)))
plot(PTE~Motor_Region,data=Delta, main = "Delta band: Motor Region", sub = sprintf ("p-value = %s",round(ANOVA_Delta$`Pr(>F)`[4],digits=4)))

par(mar=c(6, 6, 6, 6))
plot(PTE~Musicianship,data=Theta, main = "Theta band: Musicianship", sub = sprintf ("p-value = %s",round(ANOVA_Theta$`Pr(>F)`[1],digits=4)))
plot(PTE~Hemisphere,data=Theta, main = "Theta band: Hemisphere", sub = sprintf ("p-value = %s",round(ANOVA_Theta$`Pr(>F)`[2],digits=4)))
plot(PTE~Modality,data=Theta, main = "Theta band: Modality", sub = sprintf ("p-value = %s",round(ANOVA_Theta$`Pr(>F)`[3],digits=4)))
plot(PTE~Motor_Region,data=Theta, main = "Theta band: Motor Region", sub = sprintf ("p-value = %s",round(ANOVA_Theta$`Pr(>F)`[4],digits=4)))

par(mar=c(6, 6, 6, 6))
plot(PTE~Musicianship,data=Alpha, main = "Alpha band: Musicianship", sub = sprintf ("p-value = %s",round(ANOVA_Alpha$`Pr(>F)`[1],digits=4)))
plot(PTE~Hemisphere,data=Alpha, main = "Alpha band: Hemisphere", sub = sprintf ("p-value = %s",round(ANOVA_Alpha$`Pr(>F)`[2],digits=4)))
plot(PTE~Modality,data=Alpha, main = "Alpha band: Modality", sub = sprintf ("p-value = %s",round(ANOVA_Alpha$`Pr(>F)`[3],digits=4)))
plot(PTE~Motor_Region,data=Alpha, main = "Alpha band: Motor Region", sub = sprintf ("p-value = %s",round(ANOVA_Alpha$`Pr(>F)`[4],digits=4)))

par(mar=c(6, 6, 6, 6))
plot(PTE~Musicianship,data=Beta, main = "Beta band: Musicianship", sub = sprintf ("p-value = %s",round(ANOVA_Beta$`Pr(>F)`[1],digits=4)))
plot(PTE~Hemisphere,data=Beta, main = "Beta band: Hemisphere", sub = sprintf ("p-value = %s",round(ANOVA_Beta$`Pr(>F)`[2],digits=4)))
plot(PTE~Modality,data=Beta, main = "Beta band: Modality", sub = sprintf ("p-value = %s",round(ANOVA_Beta$`Pr(>F)`[3],digits=4)))
plot(PTE~Motor_Region,data=Beta, main = "Beta band: Motor Region", sub = sprintf ("p-value = %s",round(ANOVA_Beta$`Pr(>F)`[4],digits=4)))

par(mar=c(6, 6, 6, 6))
plot(PTE~Musicianship,data=Gamma1, main = "Gamma1 band: Musicianship", sub = sprintf ("p-value = %s",round(ANOVA_Gamma1$`Pr(>F)`[1],digits=4)))
plot(PTE~Hemisphere,data=Gamma1, main = "Gamma1 band: Hemisphere", sub = sprintf ("p-value = %s",round(ANOVA_Gamma1$`Pr(>F)`[2],digits=4)))
plot(PTE~Modality,data=Gamma1, main = "Gamma1 band: Modality", sub = sprintf ("p-value = %s",round(ANOVA_Gamma1$`Pr(>F)`[3],digits=4)))
plot(PTE~Motor_Region,data=Gamma1, main = "Gamma1 band: Motor Region", sub = sprintf ("p-value = %s",round(ANOVA_Gamma1$`Pr(>F)`[4],digits=4)))

par(mar=c(6, 6, 6, 6))
plot(PTE~Musicianship,data=Gamma2, main = "Gamma2 band: Musicianship", sub = sprintf ("p-value = %s",round(ANOVA_Gamma2$`Pr(>F)`[1],digits=4)))
plot(PTE~Hemisphere,data=Gamma2, main = "Gamma2 band: Hemisphere", sub = sprintf ("p-value = %s",round(ANOVA_Gamma2$`Pr(>F)`[2],digits=4)))
plot(PTE~Modality,data=Gamma2, main = "Gamma2 band: Modality", sub = sprintf ("p-value = %s",round(ANOVA_Gamma2$`Pr(>F)`[3],digits=4)))
plot(PTE~Motor_Region,data=Gamma2, main = "Gamma2 band: Motor Region", sub = sprintf ("p-value = %s",round(ANOVA_Gamma2$`Pr(>F)`[4],digits=4)))


# To finish, we tell RStudio to save all plots in the pdf file we created earlier:

dev.off()