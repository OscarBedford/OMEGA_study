# Export WITHIN MODEL into PDF

options(digits=3)

pdf("Delta_Within_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Delta: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Delta$Stats$Modality))

plot(Summary_Bands$Delta$Plots$MotorRegions_BEFORE, main = "Delta band: Motor Regions")

grid.arrange(nrow=1,top="Delta: Number of outliers removed out of 1080 PLVs", tableGrob(summary(Outliers_Bands$Delta$is.outlier)))

plot(Summary_Bands$Delta$Plots$MotorRegions_AFTER, main = "Delta band: Motor Regions")
plot(QQ_Bands$Delta, main = "Delta band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Delta: Shapiro-Wilk's normality test", tableGrob(Normality_Bands$Delta))

plot(Density_Bands$Delta, main = "Density plot after outlier removal")

GLMM2_Delta$Omnibus$p.value <- round(GLMM2_Delta$Omnibus$p.value,3)
GLMM2_Delta$Hem_by_Mod$p.value <- round(GLMM2_Delta$Hem_by_Mod$p.value,3)
GLMM2_Delta$Hem_by_Mod$bonferroni <- round(GLMM2_Delta$Hem_by_Mod$bonferroni,3)
GLMM2_Delta$Mod_by_MR$p.value <- round(GLMM2_Delta$Mod_by_MR$p.value,3)
GLMM2_Delta$Mod_by_MR$bonferroni <- round(GLMM2_Delta$Mod_by_MR$bonferroni,3)

grid.arrange(nrow=1,top="Delta: Levene's homogeneity of variances test", tableGrob(Homogeneity_Bands$Delta))
grid.arrange(nrow=1,top="Delta: GLM main effects and interactions", tableGrob(GLMM2_Delta$Omnibus))
grid.arrange(nrow=1,top="Delta: GLM post-hoc test: 'Hemisphere*Modality'", tableGrob(GLMM2_Delta$Hem_by_Mod))
grid.arrange(nrow=1,top="Delta: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM2_Delta$Mod_by_MR))

plot(Delta_Clean_Boxplot_Interaction1)
plot(Delta_Clean_Boxplot_Interaction2)

dev.off()

options(digits=3)

pdf("Theta_Within_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Theta: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Theta$Stats$Modality))

plot(Summary_Bands$Theta$Plots$MotorRegions_BEFORE, main = "Theta band: Motor Regions")

grid.arrange(nrow=1,top="Theta: Number of outliers removed out of 1080 PLVs", tableGrob(summary(Outliers_Bands$Theta$is.outlier)))

plot(Summary_Bands$Theta$Plots$MotorRegions_AFTER, main = "Theta band: Motor Regions")

plot(QQ_Bands$Theta, main = "Theta band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Theta: Shapiro-Wilk's normality test", tableGrob(Normality_Bands$Theta))

plot(Density_Bands$Theta, main = "Density plot after outlier removal")

GLMM2_Theta$Omnibus$p.value <- round(GLMM2_Theta$Omnibus$p.value,3)
GLMM2_Theta$Hem_by_MR$p.value <- round(GLMM2_Theta$Hem_by_MR$p.value,3)
GLMM2_Theta$Hem_by_MR$bonferroni <- round(GLMM2_Theta$Hem_by_MR$bonferroni,3)
GLMM2_Theta$Mod_by_MR$p.value <- round(GLMM2_Theta$Mod_by_MR$p.value,3)
GLMM2_Theta$Mod_by_MR$bonferroni <- round(GLMM2_Theta$Mod_by_MR$bonferroni,3)

grid.arrange(nrow=1,top="Theta: Levene's homogeneity of variances test", tableGrob(Homogeneity_Bands$Theta))
grid.arrange(nrow=1,top="Theta: GLM main effects and interactions", tableGrob(GLMM2_Theta$Omnibus))
grid.arrange(nrow=1,top="Theta: GLM post-hoc test: 'Hemisphere*Motor_Region'", tableGrob(GLMM2_Theta$Hem_by_MR))
grid.arrange(nrow=1,top="Theta: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM2_Theta$Mod_by_MR))

plot(Theta_Clean_Boxplot_Interaction1)
plot(Theta_Clean_Boxplot_Interaction2)

dev.off()

options(digits=3)

pdf("Alpha_Within_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Alpha: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Alpha$Stats$Modality))

plot(Summary_Bands$Alpha$Plots$MotorRegions_BEFORE, main = "Alpha band: Motor Regions")

grid.arrange(nrow=1,top="Alpha: Number of outliers removed out of 1080 PLVs", tableGrob(summary(Outliers_Bands$Alpha$is.outlier)))

plot(Summary_Bands$Alpha$Plots$MotorRegions_AFTER, main = "Alpha band: Motor Regions")

plot(QQ_Bands$Alpha, main = "Alpha band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Alpha: Shapiro-Wilk's normality test", tableGrob(Normality_Bands$Alpha))

plot(Density_Bands$Alpha, main = "Density plot after outlier removal")

GLMM2_Alpha$Omnibus$p.value <- round(GLMM2_Alpha$Omnibus$p.value,3)
GLMM2_Alpha$Mod_by_MR$p.value <- round(GLMM2_Alpha$Mod_by_MR$p.value,3)
GLMM2_Alpha$Mod_by_MR$bonferroni <- round(GLMM2_Alpha$Mod_by_MR$bonferroni,3)
GLMM2_Alpha$Hem_by_Mod_by_MR$p.value <- round(GLMM2_Alpha$Hem_by_Mod_by_MR$p.value,3)
GLMM2_Alpha$Hem_by_Mod_by_MR$bonferroni <- round(GLMM2_Alpha$Hem_by_Mod_by_MR$bonferroni,3)

grid.arrange(nrow=1,top="Alpha: Levene's homogeneity of variances test", tableGrob(Homogeneity_Bands$Alpha))
grid.arrange(nrow=1,top="Alpha: GLM main effects and interactions", tableGrob(GLMM2_Alpha$Omnibus))
grid.arrange(nrow=1,top="Alpha: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM2_Alpha$Mod_by_MR))
grid.arrange(nrow=1,top="Alpha: GLM post-hoc test: 'Hemisphere*Modality*Motor_Region'", tableGrob(GLMM2_Alpha$Hem_by_Mod_by_MR))

plot(Alpha_Clean_Boxplot_Interaction1)

dev.off()

options(digits=3)

pdf("Beta_Within_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Beta: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Beta$Stats$Modality))

plot(Summary_Bands$Beta$Plots$MotorRegions_BEFORE, main = "Beta band: Motor Regions")

grid.arrange(nrow=1,top="Beta: Number of outliers removed out of 1080 PLVs", tableGrob(summary(Outliers_Bands$Beta$is.outlier)))

plot(Summary_Bands$Beta$Plots$MotorRegions_AFTER, main = "Beta band: Motor Regions")

plot(QQ_Bands$Beta, main = "Beta band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Beta: Shapiro-Wilk's normality test", tableGrob(Normality_Bands$Beta))

plot(Density_Bands$Beta, main = "Density plot after outlier removal")

GLMM2_Beta$Omnibus$p.value <- round(GLMM2_Beta$Omnibus$p.value,3)
GLMM2_Beta$Mod_by_MR$p.value <- round(GLMM2_Beta$Mod_by_MR$p.value,3)
GLMM2_Beta$Mod_by_MR$bonferroni <- round(GLMM2_Beta$Mod_by_MR$bonferroni,3)


grid.arrange(nrow=1,top="Beta: Levene's homogeneity of variances test", tableGrob(Homogeneity_Bands$Beta))
grid.arrange(nrow=1,top="Beta: GLM main effects and interactions", tableGrob(GLMM2_Beta$Omnibus))
grid.arrange(nrow=1,top="Beta: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM2_Beta$Mod_by_MR))

plot(Beta_Clean_Boxplot_Hemisphere)
plot(Beta_Clean_Boxplot_Interaction)

dev.off()

options(digits=3)

pdf("Gamma1_Within_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Gamma1: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Gamma1$Stats$Modality))

plot(Summary_Bands$Gamma1$Plots$MotorRegions_BEFORE, main = "Gamma1 band: Motor Regions")

grid.arrange(nrow=1,top="Gamma1: Number of outliers removed out of 1080 PLVs", tableGrob(summary(Outliers_Bands$Gamma1$is.outlier)))

plot(Summary_Bands$Gamma1$Plots$MotorRegions_AFTER, main = "Gamma1 band: Motor Regions")

plot(QQ_Bands$Gamma1, main = "Gamma1 band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Gamma1: Shapiro-Wilk's normality test", tableGrob(Normality_Bands$Gamma1))

plot(Density_Bands$Gamma1, main = "Density plot after outlier removal")

GLMM2_Gamma1$Omnibus$p.value <- round(GLMM2_Gamma1$Omnibus$p.value,3)
GLMM2_Gamma1$Hem_by_Mod$p.value <- round(GLMM2_Gamma1$Hem_by_Mod$p.value,3)
GLMM2_Gamma1$Hem_by_Mod$bonferroni <- round(GLMM2_Gamma1$Hem_by_Mod$bonferroni,3)
GLMM2_Gamma1$Hem_by_MR_by_MR$p.value <- round(GLMM2_Gamma1$Hem_by_MR$p.value,3)
GLMM2_Gamma1$Hem_by_MR$bonferroni <- round(GLMM2_Gamma1$Hem_by_MR$bonferroni,3)
GLMM2_Gamma1$Mod_by_MR$p.value <- round(GLMM2_Gamma1$Mod_by_MR$p.value,3)
GLMM2_Gamma1$Mod_by_MR$bonferroni <- round(GLMM2_Gamma1$Mod_by_MR$bonferroni,3)
GLMM2_Gamma1$Hem_by_MR_by_MR$p.value <- round(GLMM2_Gamma1$Hem_by_MR$p.value,3)
GLMM2_Gamma1$Hem_by_MR$bonferroni <- round(GLMM2_Gamma1$Hem_by_MR$bonferroni,3)
GLMM2_Gamma1$Hem_by_Mod_by_MR$p.value <- round(GLMM2_Gamma1$Hem_by_Mod_by_MR$p.value,3)
GLMM2_Gamma1$Hem_by_Mod_by_MR$bonferroni <- round(GLMM2_Gamma1$Hem_by_Mod_by_MR$bonferroni,3)

grid.arrange(nrow=1,top="Gamma1: Levene's homogeneity of variances test", tableGrob(Homogeneity_Bands$Gamma1))
grid.arrange(nrow=1,top="Gamma1: GLM main effects and interactions", tableGrob(GLMM2_Gamma1$Omnibus))
grid.arrange(nrow=1,top="Gamma1: GLM post-hoc test: 'Hemisphere*Modality'", tableGrob(GLMM2_Gamma1$Hem_by_Mod))
grid.arrange(nrow=1,top="Gamma1: GLM post-hoc test: 'Hemisphere*Motor_Region'", tableGrob(GLMM2_Gamma1$Hem_by_MR))
grid.arrange(nrow=1,top="Gamma1: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM2_Gamma1$Mod_by_MR))
grid.arrange(nrow=1,top="Gamma1: GLM post-hoc test: 'Hemisphere*Modality*Motor_Region'", tableGrob(GLMM2_Gamma1$Hem_by_Mod_by_MR))

plot(Gamma1_Clean_Boxplot_Interaction1)
plot(Gamma1_Clean_Boxplot_Interaction2)
plot(Gamma1_Clean_Boxplot_Interaction3)

dev.off()

pdf("Gamma2_Within_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Gamma2: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Gamma2$Stats$Modality))

plot(Summary_Bands$Gamma2$Plots$MotorRegions_BEFORE, main = "Gamma2 band: Motor Regions")

grid.arrange(nrow=1,top="Gamma2: Number of outliers removed out of 1080 PLVs", tableGrob(summary(Outliers_Bands$Gamma2$is.outlier)))

plot(Summary_Bands$Gamma2$Plots$MotorRegions_AFTER, main = "Gamma2 band: Motor Regions")

plot(QQ_Bands$Gamma2, main = "Gamma2 band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Gamma2: Shapiro-Wilk's normality test", tableGrob(Normality_Bands$Gamma2))

plot(Density_Bands$Gamma2, main = "Density plot after outlier removal")

GLMM2_Gamma2$Omnibus$p.value <- round(GLMM2_Gamma2$Omnibus$p.value,3)
GLMM2_Gamma2$Hem_by_MR_by_MR$p.value <- round(GLMM2_Gamma2$Hem_by_MR$p.value,3)
GLMM2_Gamma2$Hem_by_MR$bonferroni <- round(GLMM2_Gamma2$Hem_by_MR$bonferroni,3)
GLMM2_Gamma2$Mod_by_MR$p.value <- round(GLMM2_Gamma2$Mod_by_MR$p.value,3)
GLMM2_Gamma2$Mod_by_MR$bonferroni <- round(GLMM2_Gamma2$Mod_by_MR$bonferroni,3)
GLMM2_Gamma2$Hem_by_Mod_by_MR$p.value <- round(GLMM2_Gamma2$Hem_by_Mod_by_MR$p.value,3)
GLMM2_Gamma2$Hem_by_Mod_by_MR$bonferroni <- round(GLMM2_Gamma2$Hem_by_Mod_by_MR$bonferroni,3)

grid.arrange(nrow=1,top="Gamma2: Levene's homogeneity of variances test", tableGrob(Homogeneity_Bands$Gamma2))
grid.arrange(nrow=1,top="Gamma2: GLM main effects and interactions", tableGrob(GLMM2_Gamma2$Omnibus))
grid.arrange(nrow=1,top="Gamma2: GLM post-hoc test: 'Hemisphere*Motor_Region'", tableGrob(GLMM2_Gamma2$Hem_by_MR))
grid.arrange(nrow=1,top="Gamma2: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM2_Gamma2$Mod_by_MR))
grid.arrange(nrow=1,top="Gamma2: GLM post-hoc test: 'Hemisphere*Modality*Motor_Region'", tableGrob(GLMM2_Gamma2$Hem_by_Mod_by_MR))

plot(Gamma2_Clean_Boxplot_Interaction1)
plot(Gamma2_Clean_Boxplot_Interaction2)

dev.off()
