library(emmeans)
library(glmmTMB)
library(rstatix)
library(optimx)

Delta_PTE <-subset(Delta, Modality!="Visual")
Delta_PTE_Right <-subset(Delta_PTE, Hemisphere!="L")
Delta_PTE_Left <-subset(Delta_PTE, Hemisphere!="R")
Delta_PTE_Right = subset(Delta_PTE_Right, select = -c(Musicianship,Connection, Modality,Hemisphere))
Delta_PTE_Left = subset(Delta_PTE_Left, select = -c(Musicianship,Connection, Modality,Hemisphere))

Theta_PTE <-subset(Theta, Modality!="Visual")
Theta_PTE_Right <-subset(Theta_PTE, Hemisphere!="L")
Theta_PTE_Left <-subset(Theta_PTE, Hemisphere!="R")
Theta_PTE_Right = subset(Theta_PTE_Right, select = -c(Musicianship,Connection, Modality,Hemisphere))
Theta_PTE_Left = subset(Theta_PTE_Left, select = -c(Musicianship,Connection, Modality,Hemisphere))

Alpha_PTE <-subset(Alpha, Modality!="Visual")
Alpha_PTE_Right <-subset(Alpha_PTE, Hemisphere!="L")
Alpha_PTE_Left <-subset(Alpha_PTE, Hemisphere!="R")
Alpha_PTE_Right = subset(Alpha_PTE_Right, select = -c(Musicianship,Connection, Modality,Hemisphere))
Alpha_PTE_Left = subset(Alpha_PTE_Left, select = -c(Musicianship,Connection, Modality,Hemisphere))

Beta_PTE <-subset(Beta, Modality!="Visual")
Beta_PTE_Right <-subset(Beta_PTE, Hemisphere!="L")
Beta_PTE_Left <-subset(Beta_PTE, Hemisphere!="R")
Beta_PTE_Right = subset(Beta_PTE_Right, select = -c(Musicianship,Connection, Modality,Hemisphere))
Beta_PTE_Left = subset(Beta_PTE_Left, select = -c(Musicianship,Connection, Modality,Hemisphere))

Gamma1_PTE <-subset(Gamma1, Modality!="Visual")
Gamma1_PTE_Right <-subset(Gamma1_PTE, Hemisphere!="L")
Gamma1_PTE_Left <-subset(Gamma1_PTE, Hemisphere!="R")
Gamma1_PTE_Right = subset(Gamma1_PTE_Right, select = -c(Musicianship,Connection, Modality,Hemisphere))
Gamma1_PTE_Left = subset(Gamma1_PTE_Left, select = -c(Musicianship,Connection, Modality,Hemisphere))

Gamma2_PTE <-subset(Gamma2, Modality!="Visual")
Gamma2_PTE_Right <-subset(Gamma2_PTE, Hemisphere!="L")
Gamma2_PTE_Left <-subset(Gamma2_PTE, Hemisphere!="R")
Gamma2_PTE_Right = subset(Gamma2_PTE_Right, select = -c(Musicianship,Connection, Modality,Hemisphere))
Gamma2_PTE_Left = subset(Gamma2_PTE_Left, select = -c(Musicianship,Connection, Modality,Hemisphere))

###############
# STEP 1: DELTA
###############

# Full model

Model_Delta_Left = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                           data = Delta_PTE_Left,
                           family = Gamma(link = "inverse"),
                           control = glmmTMBControl(optimizer=optimr,
                                                    optArgs=list(method="L-BFGS-B"),
                                                    profile = TRUE,
                                                    collect = TRUE)
)

Model_Delta_Right = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                            data = Delta_PTE_Right,
                            family = Gamma(link = "inverse"),
                            control = glmmTMBControl(optimizer=optimr,
                                                     optArgs=list(method="L-BFGS-B"),
                                                     profile = TRUE,
                                                     collect = TRUE)
)

# We compute omnibus tests (main effects and interactions) and round the values

Omnibus_Delta_Left = joint_tests(Model_Delta_Left, df=df.residual(Model_Delta_Left))
Omnibus_Delta_Left$p.value = round(Omnibus_Delta_Left$p.value,digits=5)

Omnibus_Delta_Right = joint_tests(Model_Delta_Right, df=df.residual(Model_Delta_Right))
Omnibus_Delta_Right$p.value = round(Omnibus_Delta_Right$p.value,digits=5)

# Compute the posthocs

Delta_main_Left           =   pairs(emmeans(Model_Delta_Left,~ Motor_Region,  
                                            regrid = "response", df=df.residual(Model_Delta_Left)))
summary_Delta_Left_main   =   summary(Delta_main_Left, regrid = "response", df=df.residual(Model_Delta_Left))
Delta_main_Right          =   pairs(emmeans(Model_Delta_Right,~ Motor_Region, 
                                            regrid = "response", df=df.residual(Model_Delta_Right)))
summary_Delta_Right_main  =   summary(Delta_main_Right, regrid = "response", df=df.residual(Model_Delta_Right))


# Correcting p values

Delta_Main_Left            =  adjust_pvalue(summary_Delta_Left_main, "p.value", "bonferroni", method = "bonferroni") 
Delta_Main_Left$p.value    =  round(Delta_Main_Left$p.value,digits=3)
Delta_Main_Left$bonferroni =  round(Delta_Main_Left$bonferroni,digits=3)

Delta_Main_Right            =   adjust_pvalue(summary_Delta_Right_main, "p.value", "bonferroni", method = "bonferroni") 
Delta_Main_Right$p.value    =   round(Delta_Main_Right$p.value,digits=3)
Delta_Main_Right$bonferroni =   round(Delta_Main_Right$bonferroni,digits=3)

Omnibus_Delta_Left
Delta_Main_Left
Omnibus_Delta_Right
Delta_Main_Right

###############
# STEP 2: THETA
###############

# We define the model

Model_Theta_Left = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                            data = Theta_PTE_Left,
                            family = Gamma(link = "inverse"),
                            control = glmmTMBControl(optimizer=optimr,
                                                     optArgs=list(method="L-BFGS-B"),
                                                     profile = TRUE,
                                                     collect = TRUE)
)

Model_Theta_Right = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                            data = Theta_PTE_Right,
                            family = Gamma(link = "inverse"),
                            control = glmmTMBControl(optimizer=optimr,
                                                     optArgs=list(method="L-BFGS-B"),
                                                     profile = TRUE,
                                                     collect = TRUE)
)

# We compute omnibus tests (main effects and interactions) and round the values

Omnibus_Theta_Left = joint_tests(Model_Theta_Left, df=df.residual(Model_Theta_Left))
Omnibus_Theta_Left$p.value = round(Omnibus_Theta_Left$p.value,digits=5)

Omnibus_Theta_Right = joint_tests(Model_Theta_Right, , df=df.residual(Model_Theta_Right))
Omnibus_Theta_Right$p.value = round(Omnibus_Theta_Right$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

Theta_Left_main         =   pairs(emmeans(Model_Theta_Left,~ Direction, regrid = "response", df=df.residual(Model_Theta_Left)))
summary_Theta_Left_main =   summary(Theta_Left_main, regrid = "response", df=df.residual(Model_Theta_Left))

Theta_Right_Int         =   pairs(emmeans(Model_Theta_Right,~ Direction|Motor_Region, regrid = "response", , df=df.residual(Model_Theta_Right)))
summary_Theta_Right_Int =   summary(Theta_Right_Int, regrid = "response", df=df.residual(Model_Theta_Right))

# Correcting p values

Theta_Left_Main             =  adjust_pvalue(summary_Theta_Left_main, "p.value", "bonferroni", method = "bonferroni") 
Theta_Left_Main$p.value     = round(Theta_Left_Main$p.value,digits=3)
Theta_Left_Main$bonferroni  = round(Theta_Left_Main$bonferroni,digits=3)

Theta_Right_Interaction            =  adjust_pvalue(summary_Theta_Right_Int, "p.value", "bonferroni", method = "bonferroni") 
Theta_Right_Interaction$p.value    = round(Theta_Right_Interaction$p.value,digits=3)
Theta_Right_Interaction$bonferroni = round(Theta_Right_Interaction$bonferroni,digits=3)

Omnibus_Theta_Left
Theta_Left_Main
Omnibus_Theta_Right
Theta_Right_Interaction

###############
# STEP 3: ALPHA
###############

# Full model

Model_Alpha_Left = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                           data = Alpha_PTE_Left,
                           family = Gamma(link = "inverse"),
                           control = glmmTMBControl(optimizer=optimr,
                                                    optArgs=list(method="L-BFGS-B"),
                                                    profile = TRUE,
                                                    collect = TRUE)
)

Model_Alpha_Right = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                            data = Alpha_PTE_Right,
                            family = Gamma(link = "inverse"),
                            control = glmmTMBControl(optimizer=optimr,
                                                     optArgs=list(method="L-BFGS-B"),
                                                     profile = TRUE,
                                                     collect = TRUE)
)

# We compute omnibus tests (main effects and interactions) and round the values

Omnibus_Alpha_Left = joint_tests(Model_Alpha_Left, df=df.residual(Model_Alpha_Left))
Omnibus_Alpha_Left$p.value = round(Omnibus_Alpha_Left$p.value,digits=5)

Omnibus_Alpha_Right = joint_tests(Model_Alpha_Right, df=df.residual(Model_Alpha_Right))
Omnibus_Alpha_Right$p.value = round(Omnibus_Alpha_Right$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

Alpha_Left_main         =   pairs(emmeans(Model_Alpha_Left,~ Direction|Motor_Region, df=df.residual(Model_Alpha_Left), regrid="response"))
summary_Alpha_Left_main =   summary(Alpha_Left_main, df=df.residual(Model_Alpha_Left), regrid="response")

Alpha_Right_main         =  pairs(emmeans(Model_Alpha_Right,~ Direction|Motor_Region, df=df.residual(Model_Alpha_Right), regrid="response"))
summary_Alpha_Right_main =  summary(Alpha_Right_main, df=df.residual(Model_Alpha_Right), regrid="response")

# Correcting p values

Alpha_Left_Interaction            =  adjust_pvalue(summary_Alpha_Left_main, "p.value", "bonferroni", method = "bonferroni") 
Alpha_Left_Interaction$p.value    = round(Alpha_Left_Interaction$p.value,digits=3)
Alpha_Left_Interaction$bonferroni = round(Alpha_Left_Interaction$bonferroni,digits=3)

Alpha_Right_Interaction            =  adjust_pvalue(summary_Alpha_Right_main, "p.value", "bonferroni", method = "bonferroni") 
Alpha_Right_Interaction$p.value    = round(Alpha_Right_Interaction$p.value,digits=3)
Alpha_Right_Interaction$bonferroni = round(Alpha_Right_Interaction$bonferroni,digits=3)

# Print to check

Omnibus_Alpha_Left
Alpha_Left_Interaction
Omnibus_Alpha_Right
Alpha_Right_Interaction

##############
# STEP 4: Beta
##############

# Full model

Model_Beta_Left = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                          data = Beta_PTE_Left,
                          family = Gamma(link = "inverse"),
                          control = glmmTMBControl(optimizer=optimr,
                                                   optArgs=list(method="L-BFGS-B"),
                                                   profile = TRUE,
                                                   collect = TRUE)
)

Model_Beta_Right = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                            data = Beta_PTE_Right,
                            family = Gamma(link = "inverse"),
                            control = glmmTMBControl(optimizer=optimr,
                                                     optArgs=list(method="L-BFGS-B"),
                                                     profile = TRUE,
                                                     collect = TRUE)
)

# We compute omnibus tests (main effects and interactions) and round the values

Omnibus_Beta_Left = joint_tests(Model_Beta_Left, df=df.residual(Model_Beta_Left))
Omnibus_Beta_Left$p.value = round(Omnibus_Beta_Left$p.value,digits=5)

Omnibus_Beta_Right = joint_tests(Model_Beta_Right, df=df.residual(Model_Beta_Right))
Omnibus_Beta_Right$p.value = round(Omnibus_Beta_Right$p.value,digits=5)

# Compute pairwise comparisons for significant interactions 

Beta_Left_main            =  pairs(emmeans(Model_Beta_Left,~ Direction|Motor_Region,
                                   df=df.residual(Model_Beta_Left),
                                   regrid = "response"))
summary_Beta_Left_main    =  summary(Beta_Left_main, df=df.residual(Model_Beta_Left), regrid = "response")

Beta_Right_main           =  pairs(emmeans(Model_Beta_Right,~ Direction|Motor_Region,
                                   df=df.residual(Model_Beta_Right),
                                   regrid = "response"))
summary_Beta_Right_main   =  summary(Beta_Right_main, df=df.residual(Model_Beta_Right), regrid = "response")

# Correcting p values

Beta_Left_Interaction   =  adjust_pvalue(summary_Beta_Left_main, "p.value", "bonferroni", method = "bonferroni") 
Beta_Left_Interaction$p.value    = round(Beta_Left_Interaction$p.value,digits=3)
Beta_Left_Interaction$bonferroni = round(Beta_Left_Interaction$bonferroni,digits=3)

Beta_Right_Interaction   =  adjust_pvalue(summary_Beta_Right_main, "p.value", "bonferroni", method = "bonferroni") 
Beta_Right_Interaction$p.value    = round(Beta_Right_Interaction$p.value,digits=3)
Beta_Right_Interaction$bonferroni = round(Beta_Right_Interaction$bonferroni,digits=3)

Omnibus_Beta_Left
Beta_Left_Interaction
Omnibus_Beta_Right
Beta_Right_Interaction

# Back-transforming the logit values

# (pairs(emmeans(m, ~x))) # t and p values from transformed scale
# summary(pairs(emmeans(m, ~x, transform='response'))) # d from original scale

################
# STEP 5: Gamma1
################

# Full model

Model_Gamma1_Left = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                           data = Gamma1_PTE_Left,
                           family = Gamma(link = "inverse"),
                           control = glmmTMBControl(optimizer=optimr,
                                                    optArgs=list(method="L-BFGS-B"),
                                                    profile = TRUE,
                                                    collect = TRUE)
)

Model_Gamma1_Right = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                             data = Gamma1_PTE_Right,
                             family = Gamma(link = "inverse"),
                             control = glmmTMBControl(optimizer=optimr,
                                                      optArgs=list(method="L-BFGS-B"),
                                                      profile = TRUE,
                                                      collect = TRUE)
)

# We compute omnibus tests (main effects and interactions) and round the values

Omnibus_Gamma1_Left = joint_tests(Model_Gamma1_Left, df=df.residual(Model_Gamma1_Left))
Omnibus_Gamma1_Left$p.value = round(Omnibus_Gamma1_Left$p.value,digits=5)

Omnibus_Gamma1_Right = joint_tests(Model_Gamma1_Right, df=df.residual(Model_Gamma1_Right))
Omnibus_Gamma1_Right$p.value = round(Omnibus_Gamma1_Right$p.value,digits=5)

# Interactions

Gamma1_Left_main   =  pairs(emmeans(Model_Gamma1_Left,~ Direction|Motor_Region, df=df.residual(Model_Gamma1_Left), regrid="response"))
summary_Gamma1_Left_main =   summary(Gamma1_Left_main,df=df.residual(Model_Gamma1_Left), regrid="response")

Gamma1_Right_main   =  pairs(emmeans(Model_Gamma1_Right,~ Direction|Motor_Region, df=df.residual(Model_Gamma1_Right), regrid="response"))
summary_Gamma1_Right_main =   summary(Gamma1_Right_main,df=df.residual(Model_Gamma1_Right), regrid="response")

# Correct values

Gamma1_Left_Interaction   =  adjust_pvalue(summary_Gamma1_Left_main, "p.value", "bonferroni", method = "bonferroni") 
Gamma1_Left_Interaction$p.value    = round(Gamma1_Left_Interaction$p.value,digits=3)
Gamma1_Left_Interaction$bonferroni = round(Gamma1_Left_Interaction$bonferroni,digits=3)

Gamma1_Right_Interaction   =  adjust_pvalue(summary_Gamma1_Right_main, "p.value", "bonferroni", method = "bonferroni") 
Gamma1_Right_Interaction$p.value    = round(Gamma1_Right_Interaction$p.value,digits=3)
Gamma1_Right_Interaction$bonferroni = round(Gamma1_Right_Interaction$bonferroni,digits=3)

################
# STEP 6: GAMMA2
################

# Full model

Model_Gamma2_Left = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                            data = Gamma2_PTE_Left,
                            family = Gamma(link = "inverse"),
                            control = glmmTMBControl(optimizer=optimr,
                                                     optArgs=list(method="L-BFGS-B"),
                                                     profile = TRUE,
                                                     collect = TRUE)
)

Model_Gamma2_Right = glmmTMB(PTE~Direction*Motor_Region+(1+Direction*Motor_Region||ID),
                             data = Gamma2_PTE_Right,
                             family = Gamma(link = "inverse"),
                             control = glmmTMBControl(optimizer=optimr,
                                                      optArgs=list(method="L-BFGS-B"),
                                                      profile = TRUE,
                                                      collect = TRUE)
)

# We compute omnibus tests (main effects and interactions) and round the values

Omnibus_Gamma2_Left = joint_tests(Model_Gamma2_Left, df=df.residual(Model_Gamma2_Left))
Omnibus_Gamma2_Left$p.value = round(Omnibus_Gamma2_Left$p.value,digits=5)

Omnibus_Gamma2_Right = joint_tests(Model_Gamma2_Right, df=df.residual(Model_Gamma2_Right))
Omnibus_Gamma2_Right$p.value = round(Omnibus_Gamma2_Right$p.value,digits=5)

# Compute the main effect 

Gamma2_Main_Left2   =  pairs(emmeans(Model_Gamma2_Left,~ Direction, 
                                     df=df.residual(Model_Gamma2_Left), regrid = "response"))
summary_Gamma2_Main_Left2 =   summary(Gamma2_Main_Left2, 
                                      df=df.residual(Model_Gamma2_Left), regrid = "response")

Gamma2_Main_Right2   =  pairs(emmeans(Model_Gamma2_Right,~ Direction,
                                      df=df.residual(Model_Gamma2_Right), regrid = "response"))
summary_Gamma2_Main_Right2 =   summary(Gamma2_Main_Right2,
                                       df=df.residual(Model_Gamma2_Right), regrid = "response")

# Correct p-values

Gamma2_Main_Left2            =  adjust_pvalue(summary_Gamma2_Main_Left2, "p.value", "bonferroni", method = "bonferroni") 
Gamma2_Main_Left2$p.value    = round(Gamma2_Main_Left2$p.value,digits=3)
Gamma2_Main_Left2$bonferroni = round(Gamma2_Main_Left2$bonferroni,digits=3)

Gamma2_Main_Right2            =  adjust_pvalue(summary_Gamma2_Main_Right2, "p.value", "bonferroni", method = "bonferroni") 
Gamma2_Main_Right2$p.value    = round(Gamma2_Main_Right2$p.value,digits=3)
Gamma2_Main_Right2$bonferroni = round(Gamma2_Main_Right2$bonferroni,digits=3)

###############
# GENERATE PDFS
###############

Delta_Summary1 <- Delta %>%
  group_by(Hemisphere,Modality) %>%
  get_summary_stats(PTE, type = "mean_sd")

Delta_Boxplot_Interaction1 <- ggbarplot(
  Delta_Summary1, x = "Modality", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Delta: Barplot of 'Hemisphere*Modality' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

Delta_Summary2 <- Delta %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Delta_Boxplot_Interaction2 <- ggbarplot(
  Delta_Summary2, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Delta: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

# Theta

Theta_Summary1 <- Theta %>%
  group_by(Hemisphere,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Theta_Boxplot_Interaction1 <- ggbarplot(
  Theta_Summary1, x = "Direction", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Theta: Barplot of 'Hemisphere*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

Theta_Summary2 <- Theta %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Theta_Boxplot_Interaction2 <- ggbarplot(
  Theta_Summary2, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Theta: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)
# Alpha

Alpha_Summary1 <- Alpha %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Alpha_Boxplot_Interaction1 <- ggbarplot(
  Alpha_Summary1, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Alpha: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Beta

Beta_Summary1 <- Beta %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Beta_Summary2 <- Beta %>%
  group_by(Hemisphere) %>%
  get_summary_stats(PTE, type = "mean_sd")

Beta_Boxplot2 <- ggbarplot(
  Beta_Summary2, x = "Hemisphere", y = "mean",
  title= "Beta: Barplot of 'Hemisphere' (main effect)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  color = "black",
  fill = "white",
  label = TRUE, lab.vjust = -0.4
)

Beta_Boxplot_Interaction <- ggbarplot(
  Beta_Summary1, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Beta: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Gamma2 

Gamma2_Summary1 <- Gamma2 %>%
  group_by(Hemisphere,Modality) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Boxplot_Interaction1 <- ggbarplot(
  Gamma2_Summary1, x = "Modality", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Hemisphere*Modality' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

Gamma2_Summary2 <- Gamma2 %>%
  group_by(Hemisphere,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Boxplot_Interaction2 <- ggbarplot(
  Gamma2_Summary2, x = "Direction", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Hemisphere*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

Gamma2_Summary3 <- Gamma2 %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Boxplot_Interaction3 <- ggbarplot(
  Gamma2_Summary3, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Gamma2

Gamma2_Summary1 <- Gamma2 %>%
  group_by(Hemisphere,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Boxplot_Interaction1 <- ggbarplot(
  Gamma2_Summary1, x = "Direction", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Hemisphere*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

Gamma2_Summary2 <- Gamma2 %>%
  group_by(Modality,Direction) %>%
  get_summary_stats(PTE, type = "mean_sd")

Gamma2_Boxplot_Interaction2 <- ggbarplot(
  Gamma2_Summary2, x = "Direction", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Modality*Direction' (Interaction)",
  ylab = "mean PTE",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)
