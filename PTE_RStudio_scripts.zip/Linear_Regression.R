###########################
# PART 1: Create the sample
###########################

# STEP 1: We eliminate non-musicians from the tables 

Delta_Mus <- subset(Delta, Musicianship != "non-musician")
Theta_Mus <- subset(Theta, Musicianship != "non-musician")
Alpha_Mus <- subset(Alpha, Musicianship != "non-musician")
Beta_Mus <- subset(Beta, Musicianship != "non-musician")
Gamma1_Mus <- subset(Gamma1, Musicianship != "non-musician")
Gamma2_Mus <- subset(Gamma2, Musicianship != "non-musician")

# We also need to eliminate the hidden levels (subjects) from variable "ID"

Delta_Mus$ID <- factor(Delta_Mus$ID)
Theta_Mus$ID <- factor(Theta_Mus$ID)
Alpha_Mus$ID <- factor(Alpha_Mus$ID)
Beta_Mus$ID <- factor(Beta_Mus$ID)
Gamma1_Mus$ID <- factor(Gamma1_Mus$ID)
Gamma2_Mus$ID <- factor(Gamma2_Mus$ID)

# STEP 2: We eliminate the 'Musicianship' column

Delta_Mus$Musicianship <- NULL 
Theta_Mus$Musicianship <- NULL 
Alpha_Mus$Musicianship <- NULL 
Beta_Mus$Musicianship <- NULL 
Gamma1_Mus$Musicianship <- NULL 
Gamma2_Mus$Musicianship <- NULL 

# STEP 3: We create the "Years of training" column

Years_training      <- list (9,
                             12,
                             7,
                             5,
                             7,
                             15,
                             10,
                             25,
                             7,
                             8,
                             18,
                             10,
                             19,
                             10,
                             24,
                             15,
                             10,
                             12,
                             20,
                             12,
                             10,
                             7,
                             18,
                             8,
                             12,
                             15,
                             17,
                             34,
                             10)

Years_training_plot <- list (9,
                        12,
                        7,
                        5,
                        7,
                        15,
                        10,
                        25,
                        7,
                        8,
                        18,
                        10,
                        19,
                        10,
                        24,
                        15,
                        10,
                        12,
                        20,
                        12,
                        10,
                        7,
                        18,
                        8,
                        12,
                        15,
                        17,
                        34,
                        10)

Years_training <- as.numeric(as.character(Years_training))
Years_training <- scale(Years_training)
Years_training <- as.list(Years_training)

Years_x12 = list()

for (i in 1:29){
  Years_x12[[i]] <- (rep(Years_training[i], 12))
}

Years_x12 <- lapply(rapply(Years_x12, enquote, how="unlist"), eval)

Years_x12_plot = list()

for (i in 1:29){
  Years_x12_plot[[i]] <- (rep(Years_training_plot[i], 12))
}

Years_x12_plot <- lapply(rapply(Years_x12_plot, enquote, how="unlist"), eval)

# STEP 4: We add the years of training variable as a new column

Delta_Mus$Years_training  <- Years_x12
Theta_Mus$Years_training  <- Years_x12
Alpha_Mus$Years_training  <- Years_x12
Beta_Mus$Years_training   <- Years_x12
Gamma1_Mus$Years_training <- Years_x12
Gamma2_Mus$Years_training <- Years_x12

Delta_Mus$Years_training_plot  <- Years_x12_plot
Theta_Mus$Years_training_plot  <- Years_x12_plot
Alpha_Mus$Years_training_plot  <- Years_x12_plot
Beta_Mus$Years_training_plot   <- Years_x12_plot
Gamma1_Mus$Years_training_plot <- Years_x12_plot
Gamma2_Mus$Years_training_plot <- Years_x12_plot

# STEP 5: We re-order the column order

Delta_Mus <- Delta_Mus[, c(1, 6, 7, 2, 3, 4, 5)]
Theta_Mus <- Theta_Mus[, c(1, 6, 7, 2, 3, 4, 5)]
Alpha_Mus <- Alpha_Mus[, c(1, 3, 7, 4, 5, 6, 2)]
Beta_Mus <- Beta_Mus [, c(1, 6, 7, 2, 3, 4, 5)]
Gamma1_Mus <- Gamma1_Mus [, c(1, 6, 7, 2, 3, 4, 5)]
Gamma2_Mus <- Gamma2_Mus [, c(1, 6, 7, 2, 3, 4, 5)]

rm(Years_training,Years_x12)

# STEP 6: We change the class of "Years_training" to numeric

Delta_Mus$Years_training <- as.numeric(as.character(Delta_Mus$Years_training))
Theta_Mus$Years_training <- as.numeric(as.character(Theta_Mus$Years_training))
Alpha_Mus$Years_training <- as.numeric(as.character(Alpha_Mus$Years_training))
Beta_Mus$Years_training <- as.numeric(as.character(Beta_Mus$Years_training))
Gamma1_Mus$Years_training <- as.numeric(as.character(Gamma1_Mus$Years_training))
Gamma2_Mus$Years_training <- as.numeric(as.character(Gamma2_Mus$Years_training))

Delta_Mus$Years_training_plot <- as.numeric(as.character(Delta_Mus$Years_training_plot))
Theta_Mus$Years_training_plot <- as.numeric(as.character(Theta_Mus$Years_training_plot))
Alpha_Mus$Years_training_plot <- as.numeric(as.character(Alpha_Mus$Years_training_plot))
Beta_Mus$Years_training_plot <- as.numeric(as.character(Beta_Mus$Years_training_plot))
Gamma1_Mus$Years_training_plot <- as.numeric(as.character(Gamma1_Mus$Years_training_plot))
Gamma2_Mus$Years_training_plot <- as.numeric(as.character(Gamma2_Mus$Years_training_plot))

###########################
# PART 2: Compute the model
###########################

# STEP 1: DELTA

library(emmeans)
library(glmmTMB)
library(rstatix)

# Linear regression model

GLMM3_Delta= glmmTMB(PLV~Years_training*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                    data = Delta_Mus,
                    family = beta_family(link = "logit"))

# Compute omnibus test (main effects and interactions)

Omnibus_GLMM3_Delta    = joint_tests(GLMM3_Delta)

# Compute pairwise comparisons for significant interactions 

GLMM3_Delta_Mus_pairs_HM   =   pairs(emmeans(GLMM3_Delta,~ Hemisphere|Modality), adjust="bonferroni")
summary_Delta_Mus_GLMM3_HM =   summary(GLMM3_Delta_Mus_pairs_HM)

GLMM3_Delta_Mus_pairs_MMr   =  pairs(emmeans(GLMM3_Delta,~ Modality|Motor_Region), adjust="bonferroni")
summary_Delta_Mus_GLMM3_MMr =  summary(GLMM3_Delta_Mus_pairs_MMr)

# Correcting p values

GLMM3_HM_Result   =  adjust_pvalue(summary_Delta_Mus_GLMM3_HM, "p.value", "bonferroni", method = "bonferroni") 
GLMM3_MMr_Result  =  adjust_pvalue(summary_Delta_Mus_GLMM3_MMr, "p.value", "bonferroni", method = "bonferroni") 

GLMM3_HM_Result$p.value    = round(GLMM3_HM_Result$p.value,digits=3)
GLMM3_HM_Result$bonferroni = round(GLMM3_HM_Result$bonferroni,digits=3)

GLMM3_MMr_Result$p.value    = round(GLMM3_MMr_Result$p.value,digits=3)
GLMM3_MMr_Result$bonferroni = round(GLMM3_MMr_Result$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM3_Delta_Mus = list(Omnibus = Omnibus_GLMM3_Delta,
                   Hem_by_Mod = GLMM3_HM_Result,
                   Mod_by_MR = GLMM3_MMr_Result)

rm(GLMM3_Delta,Omnibus_GLMM3_Delta,GLMM3_Delta_Mus_pairs_HM,
   summary_Delta_Mus_GLMM3_HM,GLMM3_Delta_Mus_pairs_MMr,summary_Delta_Mus_GLMM3_MMr,
   GLMM3_HM_Result,GLMM3_MMr_Result)

# STEP 2: THETA

# Linear regression model

GLMM3_Theta= glmmTMB(PLV~Years_training*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                     data = Theta_Mus,
                     family = beta_family(link = "logit"))

# Compute omnibus test (main effects and interactions)

Omnibus_GLMM3_Theta    = joint_tests(GLMM3_Theta)

# Compute pairwise comparisons for significant interactions 

GLMM3_Mus_Theta_pairs_MMr   =  pairs(emmeans(GLMM3_Theta,~ Modality|Motor_Region), adjust="bonferroni")
summary_GLMM3_Mus_Theta_MMr =  summary(GLMM3_Mus_Theta_pairs_MMr)

# Correcting p values

GLMM3_MMr_Result   =  adjust_pvalue(summary_GLMM3_Mus_Theta_MMr, "p.value", "bonferroni", method = "bonferroni") 

GLMM3_MMr_Result$p.value    = round(GLMM3_MMr_Result$p.value,digits=3)
GLMM3_MMr_Result$bonferroni = round(GLMM3_MMr_Result$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM3_Theta_Mus = list(Omnibus = Omnibus_GLMM3_Theta,
                   Mod_by_MR = GLMM3_MMr_Result)

rm(GLMM3_Theta,Omnibus_GLMM3_Theta,GLMM3_Mus_Theta_pairs_MMr,
   summary_GLMM3_Mus_Theta_MMr,GLMM3_MMr_Result)

# STEP 3: Alpha

# Linear regression model

GLMM3_Alpha= glmmTMB(PLV~Years_training*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                     data = Alpha_Mus,
                     family = beta_family(link = "logit"))

# Compute omnibus test (main effects and interactions)

Omnibus_GLMM3_Alpha    = joint_tests(GLMM3_Alpha)

# Compute pairwise comparisons for significant interactions 

GLMM3_Alpha_pairs_MMr          =  pairs(emmeans(GLMM3_Alpha,~ Modality|Motor_Region), adjust="bonferroni")
summary_Alpha_Mus_GLMM3_MMr    =  summary(GLMM3_Alpha_pairs_MMr)

# Correcting p values

GLMM3_MMr_Result   =  adjust_pvalue(summary_Alpha_Mus_GLMM3_MMr, "p.value", "bonferroni", method = "bonferroni") 

GLMM3_MMr_Result$p.value    = round(GLMM3_MMr_Result$p.value,digits=3)
GLMM3_MMr_Result$bonferroni = round(GLMM3_MMr_Result$bonferroni,digits=3)

# Add everything into one MMrg list and remove extraneous variables

GLMM3_Alpha_Mus = list(Omnibus = Omnibus_GLMM3_Alpha,
                   Mod_by_MR = GLMM3_MMr_Result)

rm(GLMM3_Alpha,Omnibus_GLMM3_Alpha,GLMM3_Alpha_pairs_MMr,
   summary_Alpha_Mus_GLMM3_MMr,GLMM3_MMr_Result)

# STEP 4: Beta

# Linear regression model

GLMM3_Beta= glmmTMB(PLV~Years_training*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                     data = Beta_Mus,
                     family = beta_family(link = "logit"))

# Compute omnibus test (main effects and interactions)

Omnibus_GLMM3_Beta    = joint_tests(GLMM3_Beta)

# Compute pairwise comparisons for significant interactions 

GLMM3_Beta_Mus_pairs_MMr     =   pairs(emmeans(GLMM3_Beta,~ Modality|Motor_Region), adjust="bonferroni")
summary_GLMM3_Beta_Mus_MMr   =   summary(GLMM3_Beta_Mus_pairs_MMr)

# Correcting p values

GLMM3_MMr_Result   =  adjust_pvalue(summary_GLMM3_Beta_Mus_MMr, "p.value", "bonferroni", method = "bonferroni") 

GLMM3_MMr_Result$p.value    = round(GLMM3_MMr_Result$p.value,digits=3)
GLMM3_MMr_Result$bonferroni = round(GLMM3_MMr_Result$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM3_Beta_Mus = list(Omnibus = Omnibus_GLMM3_Beta,
                  Mod_by_MR = GLMM3_MMr_Result)

rm(GLMM3_Beta,Omnibus_GLMM3_Beta,GLMM3_Beta_Mus_pairs_MMr,
   summary_GLMM3_Beta_Mus_MMr,GLMM3_MMr_Result)

# STEP 5: Gamma1

# Linear regression model

GLMM3_Gamma1= glmmTMB(PLV~Years_training*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                    data = Gamma1_Mus,
                    family = beta_family(link = "logit"))

# Compute omnibus test (main effects and interactions)

Omnibus_GLMM3_Gamma1    = joint_tests(GLMM3_Gamma1)

# Compute pairwise comparisons for significant interactions 

GLMM3_Gamma1_Mus_pairs_MMr   =  pairs(emmeans(GLMM3_Gamma1,~ Modality|Motor_Region), adjust="bonferroni")
summary_Gamma1_GLMM3_MMr =  summary(GLMM3_Gamma1_Mus_pairs_MMr)

# Correcting p values

GLMM3_MMr_Result  =  adjust_pvalue(summary_Gamma1_GLMM3_MMr, "p.value", "bonferroni", method = "bonferroni") 

GLMM3_MMr_Result$p.value    = round(GLMM3_MMr_Result$p.value,digits=3)
GLMM3_MMr_Result$bonferroni = round(GLMM3_MMr_Result$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM3_Gamma1_Mus = list(Omnibus       = Omnibus_GLMM3_Gamma1,
                    Mod_by_MR         = GLMM3_MMr_Result)

rm(GLMM3_Gamma1,Omnibus_GLMM3_Gamma1,GLMM3_Gamma1_Mus_pairs_MMr,
   summary_Gamma1_GLMM3_MMr,GLMM3_MMr_Result)


# STEP 6: GAMMA2


# Linear regression model

GLMM3_Gamma2= glmmTMB(PLV~Years_training*Hemisphere*Modality*Motor_Region+(1+Hemisphere*Modality*Motor_Region||ID),
                      data = Gamma2_Mus,
                      family = beta_family(link = "logit"))

# Compute omnibus test (main effects and interactions)

Omnibus_GLMM3_Gamma2    = joint_tests(GLMM3_Gamma2)

# Compute pairwise comparisons for significant interactions 

GLMM3_Gamma2_Mus_pairs_MMr   =  pairs(emmeans(GLMM3_Gamma2,~ Modality|Motor_Region), adjust="bonferroni")
summary_Gamma2_GLMM3_MMr =  summary(GLMM3_Gamma2_Mus_pairs_MMr)

# Correcting p values

GLMM3_MMr_Result  =  adjust_pvalue(summary_Gamma2_GLMM3_MMr, "p.value", "bonferroni", method = "bonferroni") 

GLMM3_MMr_Result$p.value    = round(GLMM3_MMr_Result$p.value,digits=3)
GLMM3_MMr_Result$bonferroni = round(GLMM3_MMr_Result$bonferroni,digits=3)

# Add everything into one big list and remove extraneous variables

GLMM3_Gamma2_Mus = list(Omnibus       = Omnibus_GLMM3_Gamma2,
                        Mod_by_MR         = GLMM3_MMr_Result)

rm(GLMM3_Gamma2,Omnibus_GLMM3_Gamma2,GLMM3_Gamma2_Mus_pairs_MMr,
   summary_Gamma2_GLMM3_MMr,GLMM3_MMr_Result)

############################
# PART 3: Generate the plots
############################

# STEP 1.1: We Identify the outliers

library(tidyverse)
library(rstatix)

Delta_Mus_outliers <- Delta_Mus %>%
  identify_outliers(PLV)

Theta_Mus_outliers <- Theta_Mus %>%
  identify_outliers(PLV)

Alpha_Mus_outliers <- Alpha_Mus %>%
  identify_outliers(PLV)

Beta_Mus_outliers <- Beta_Mus %>%
  identify_outliers(PLV)

Gamma1_Mus_outliers <- Gamma1_Mus %>%
  identify_outliers(PLV)

Gamma2_Mus_outliers <- Gamma2_Mus %>%
  identify_outliers(PLV)

Outliers_Bands = list(Delta_Mus = Delta_Mus_outliers,
                      Theta_Mus = Theta_Mus_outliers,
                      Alpha_Mus = Alpha_Mus_outliers,
                      Beta_Mus = Beta_Mus_outliers,
                      Gamma1_Mus = Gamma1_Mus_outliers,
                      Gamma2_Mus = Gamma2_Mus_outliers)

rm(Delta_Mus_outliers, Theta_Mus_outliers, Alpha_Mus_outliers, Beta_Mus_outliers, Gamma1_Mus_outliers, Gamma2_Mus_outliers)

# Step 1.2: Removing outliers from the data

Q1 <- quantile(Delta_Mus$PLV, .25)
Q3 <- quantile(Delta_Mus$PLV, .75)
IQR <- IQR(Delta_Mus$PLV)
Delta_Mus_no_outliers = subset(Delta_Mus, Delta_Mus$PLV > (Q1 - 1.5*IQR) & Delta_Mus$PLV < (Q3 + 1.5*IQR))

Q1 <- quantile(Theta_Mus$PLV, .25)
Q3 <- quantile(Theta_Mus$PLV, .75)
IQR <- IQR(Theta_Mus$PLV)
Theta_Mus_no_outliers = subset(Theta_Mus, Theta_Mus$PLV > (Q1 - 1.5*IQR) & Theta_Mus$PLV < (Q3 + 1.5*IQR))

Q1 <- quantile(Alpha_Mus$PLV, .25)
Q3 <- quantile(Alpha_Mus$PLV, .75)
IQR <- IQR(Alpha_Mus$PLV)
Alpha_Mus_no_outliers = subset(Alpha_Mus, Alpha_Mus$PLV > (Q1 - 1.5*IQR) & Alpha_Mus$PLV < (Q3 + 1.5*IQR))

Q1 <- quantile(Beta_Mus$PLV, .25)
Q3 <- quantile(Beta_Mus$PLV, .75)
IQR <- IQR(Beta_Mus$PLV)
Beta_Mus_no_outliers = subset(Beta_Mus, Beta_Mus$PLV > (Q1 - 1.5*IQR) & Beta_Mus$PLV < (Q3 + 1.5*IQR))

Q1 <- quantile(Gamma1_Mus$PLV, .25)
Q3 <- quantile(Gamma1_Mus$PLV, .75)
IQR <- IQR(Gamma1_Mus$PLV)
Gamma1_Mus_no_outliers = subset(Gamma1_Mus, Gamma1_Mus$PLV > (Q1 - 1.5*IQR) & Gamma1_Mus$PLV < (Q3 + 1.5*IQR))

Q1 <- quantile(Gamma2_Mus$PLV, .25)
Q3 <- quantile(Gamma2_Mus$PLV, .75)
IQR <- IQR(Gamma2_Mus$PLV)
Gamma2_Mus_no_outliers = subset(Gamma2_Mus, Gamma2_Mus$PLV > (Q1 - 1.5*IQR) & Gamma2_Mus$PLV < (Q3 + 1.5*IQR))

# STEP 2: Summary statistics

Delta_Mus_Summary_Years_training <- Delta_Mus %>%
  group_by(Years_training_plot) %>%
  get_summary_stats(PLV, type = "mean_sd")

Delta_Mus_Summary_Years_training$n <- as.numeric(as.character(Delta_Mus_Summary_Years_training$n)) / 12
colnames(Delta_Mus_Summary_Years_training) <- c("Years_of_training", "variable", "n", "mean", "sd")

Delta_Mus_Summary_Hem.Mod.MR <- Delta_Mus %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Delta_Mus_Summary = list(Years_training = Delta_Mus_Summary_Years_training, Modality = Delta_Mus_Summary_Hem.Mod.MR)

rm(Delta_Mus_Summary_Hem.Mod.MR,Delta_Mus_Summary_Years_training)

Theta_Mus_Summary_Years_training <- Theta_Mus %>%
  group_by(Years_training_plot) %>%
  get_summary_stats(PLV, type = "mean_sd")

Theta_Mus_Summary_Years_training$n <- as.numeric(as.character(Theta_Mus_Summary_Years_training$n)) / 12
colnames(Theta_Mus_Summary_Years_training) <- c("Years_of_training", "variable", "n", "mean", "sd")

Theta_Mus_Summary_Hem.Mod.MR <- Theta_Mus %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Theta_Mus_Summary = list(Years_training = Theta_Mus_Summary_Years_training, Modality = Theta_Mus_Summary_Hem.Mod.MR)

rm(Theta_Mus_Summary_Hem.Mod.MR,Theta_Mus_Summary_Years_training)

Alpha_Mus_Summary_Years_training <- Alpha_Mus %>%
  group_by(Years_training_plot) %>%
  get_summary_stats(PLV, type = "mean_sd")

Alpha_Mus_Summary_Years_training$n <- as.numeric(as.character(Alpha_Mus_Summary_Years_training$n)) / 12
colnames(Alpha_Mus_Summary_Years_training) <- c("Years_of_training", "variable", "n", "mean", "sd")

Alpha_Mus_Summary_Hem.Mod.MR <- Alpha_Mus %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Alpha_Mus_Summary = list(Years_training = Alpha_Mus_Summary_Years_training, Modality = Alpha_Mus_Summary_Hem.Mod.MR)

rm(Alpha_Mus_Summary_Hem.Mod.MR,Alpha_Mus_Summary_Years_training)

Beta_Mus_Summary_Years_training <- Beta_Mus %>%
  group_by(Years_training_plot) %>%
  get_summary_stats(PLV, type = "mean_sd")

Beta_Mus_Summary_Years_training$n <- as.numeric(as.character(Beta_Mus_Summary_Years_training$n)) / 12
colnames(Beta_Mus_Summary_Years_training) <- c("Years_of_training", "variable", "n", "mean", "sd")

Beta_Mus_Summary_Hem.Mod.MR <- Beta_Mus %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Beta_Mus_Summary = list(Years_training = Beta_Mus_Summary_Years_training, Modality = Beta_Mus_Summary_Hem.Mod.MR)

rm(Beta_Mus_Summary_Hem.Mod.MR,Beta_Mus_Summary_Years_training)

Gamma1_Mus_Summary_Years_training <- Gamma1_Mus %>%
  group_by(Years_training_plot) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma1_Mus_Summary_Years_training$n <- as.numeric(as.character(Gamma1_Mus_Summary_Years_training$n)) / 12
colnames(Gamma1_Mus_Summary_Years_training) <- c("Years_of_training", "variable", "n", "mean", "sd")

Gamma1_Mus_Summary_Hem.Mod.MR <- Gamma1_Mus %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma1_Mus_Summary = list(Years_training = Gamma1_Mus_Summary_Years_training, Modality = Gamma1_Mus_Summary_Hem.Mod.MR)

rm(Gamma1_Mus_Summary_Hem.Mod.MR,Gamma1_Mus_Summary_Years_training)

Gamma2_Mus_Summary_Years_training <- Gamma2_Mus %>%
  group_by(Years_training_plot) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma2_Mus_Summary_Years_training$n <- as.numeric(as.character(Gamma2_Mus_Summary_Years_training$n)) / 12
colnames(Gamma2_Mus_Summary_Years_training) <- c("Years_of_training", "variable", "n", "mean", "sd")

Gamma2_Mus_Summary_Hem.Mod.MR <- Gamma2_Mus %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma2_Mus_Summary = list(Years_training = Gamma2_Mus_Summary_Years_training, Modality = Gamma2_Mus_Summary_Hem.Mod.MR)

rm(Gamma2_Mus_Summary_Hem.Mod.MR,Gamma2_Mus_Summary_Years_training)

# STEP 3: Boxplots

library(ggplot2)
library(ggpubr)

Delta_Mus_Boxplot_Years_training_Mod <- ggplot(
  Delta_Mus, 
  aes(Years_training_plot, PLV, color = Modality)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                        y = "PLV",
                                        title = "Delta MODALITY scatterplot BEFORE outlier removal")

Delta_Mus_Boxplot_Years_training_MMr <- ggplot(
  Delta_Mus, 
  aes(Years_training_plot, PLV, color = Motor_Region)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                        y = "PLV",
                                        title = "Delta MOTOR_REGION scatterplot BEFORE outlier removal")

Delta_Mus_Boxplot_Years_training_Hem <- ggplot(
  Delta_Mus, 
  aes(Years_training_plot, PLV, color = Hemisphere)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                        y = "PLV",
                                        title = "Delta HEMISPHERE scatterplot BEFORE outlier removal")

Delta_Mus_Boxplot_MotorRegions <- ggboxplot(
  Delta_Mus, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Delta_Mus: Boxplot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal",
)

Delta_Mus_Clean_Boxplot_Years_training_Mod <- ggplot(
  Delta_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Modality)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
        y = "PLV",
        title = "Delta MODALITY scatterplot AFTER outlier removal")

Delta_Mus_Clean_Boxplot_Years_training_MMr <- ggplot(
  Delta_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Motor_Region)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
        y = "PLV",
        title = "Delta MOTOR_REGION scatterplot AFTER outlier removal")

Delta_Mus_Clean_Boxplot_Years_training_Hem <- ggplot(
  Delta_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Hemisphere)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
        y = "PLV",
        title = "Delta HEMISPHERE scatterplot AFTER outlier removal")

Delta_Mus_Clean_Boxplot_MotorRegions <- ggboxplot(
  Delta_Mus_no_outliers, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Delta_Mus: Boxplot of 'Hemisphere/Modality/Motor_Region' AFTER outlier removal",
)

Delta_Mus_Boxplots = list(Years_training_Mod_BEFORE = Delta_Mus_Boxplot_Years_training_Mod,
                          Years_training_MR_BEFORE = Delta_Mus_Boxplot_Years_training_MMr,
                          Years_training_Hem_BEFORE = Delta_Mus_Boxplot_Years_training_Hem,
                      Years_training_Mod_AFTER = Delta_Mus_Clean_Boxplot_Years_training_Mod,
                      Years_training_MR_AFTER = Delta_Mus_Clean_Boxplot_Years_training_MMr,
                      Years_training_Hem_AFTER = Delta_Mus_Clean_Boxplot_Years_training_Hem,
                      MotorRegions_BEFORE = Delta_Mus_Boxplot_MotorRegions,
                      MotorRegions_AFTER = Delta_Mus_Clean_Boxplot_MotorRegions)

rm (Delta_Mus_Boxplot_Years_training_Mod,
    Delta_Mus_Boxplot_Years_training_MMr,
    Delta_Mus_Boxplot_Years_training_Hem,
    Delta_Mus_Clean_Boxplot_Years_training_Mod,
    Delta_Mus_Clean_Boxplot_Years_training_MMr,
    Delta_Mus_Clean_Boxplot_Years_training_Hem,
    Delta_Mus_Boxplot_MotorRegions,
   Delta_Mus_Clean_Boxplot_MotorRegions)

Theta_Mus_Boxplot_Years_training_Mod <- ggplot(
  Theta_Mus, 
  aes(Years_training_plot, PLV, color = Modality)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                       y = "PLV",
                                                                                                                       title = "Theta MODALITY scatterplot BEFORE outlier removal")

Theta_Mus_Boxplot_Years_training_MMr <- ggplot(
  Theta_Mus, 
  aes(Years_training_plot, PLV, color = Motor_Region)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                           y = "PLV",
                                                                                                                           title = "Theta MOTOR_REGION scatterplot BEFORE outlier removal")

Theta_Mus_Boxplot_Years_training_Hem <- ggplot(
  Theta_Mus, 
  aes(Years_training_plot, PLV, color = Hemisphere)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                         y = "PLV",
                                                                                                                         title = "Theta HEMISPHERE scatterplot BEFORE outlier removal")

Theta_Mus_Boxplot_MotorRegions <- ggboxplot(
  Theta_Mus, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Theta_Mus: Boxplot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal",
)

Theta_Mus_Clean_Boxplot_Years_training_Mod <- ggplot(
  Theta_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Modality)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                       y = "PLV",
                                                                                                                       title = "Theta MODALITY scatterplot AFTER outlier removal")

Theta_Mus_Clean_Boxplot_Years_training_MMr <- ggplot(
  Theta_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Motor_Region)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                           y = "PLV",
                                                                                                                           title = "Theta MOTOR_REGION scatterplot AFTER outlier removal")

Theta_Mus_Clean_Boxplot_Years_training_Hem <- ggplot(
  Theta_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Hemisphere)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                         y = "PLV",
                                                                                                                         title = "Theta HEMISPHERE scatterplot AFTER outlier removal")

Theta_Mus_Clean_Boxplot_MotorRegions <- ggboxplot(
  Theta_Mus_no_outliers, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Theta_Mus: Boxplot of 'Hemisphere/Modality/Motor_Region' AFTER outlier removal",
)

Theta_Mus_Boxplots = list(Years_training_Mod_BEFORE = Theta_Mus_Boxplot_Years_training_Mod,
                          Years_training_MR_BEFORE = Theta_Mus_Boxplot_Years_training_MMr,
                          Years_training_Hem_BEFORE = Theta_Mus_Boxplot_Years_training_Hem,
                          Years_training_Mod_AFTER = Theta_Mus_Clean_Boxplot_Years_training_Mod,
                          Years_training_MR_AFTER = Theta_Mus_Clean_Boxplot_Years_training_MMr,
                          Years_training_Hem_AFTER = Theta_Mus_Clean_Boxplot_Years_training_Hem,
                          MotorRegions_BEFORE = Theta_Mus_Boxplot_MotorRegions,
                          MotorRegions_AFTER = Theta_Mus_Clean_Boxplot_MotorRegions)

rm (Theta_Mus_Boxplot_Years_training_Mod,
    Theta_Mus_Boxplot_Years_training_MMr,
    Theta_Mus_Boxplot_Years_training_Hem,
    Theta_Mus_Clean_Boxplot_Years_training_Mod,
    Theta_Mus_Clean_Boxplot_Years_training_MMr,
    Theta_Mus_Clean_Boxplot_Years_training_Hem,
    Theta_Mus_Boxplot_MotorRegions,
    Theta_Mus_Clean_Boxplot_MotorRegions)

Alpha_Mus_Boxplot_Years_training_Mod <- ggplot(
  Alpha_Mus, 
  aes(Years_training_plot, PLV, color = Modality)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                       y = "PLV",
                                                                                                                       title = "Alpha MODALITY scatterplot BEFORE outlier removal")

Alpha_Mus_Boxplot_Years_training_MMr <- ggplot(
  Alpha_Mus, 
  aes(Years_training_plot, PLV, color = Motor_Region)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                           y = "PLV",
                                                                                                                           title = "Alpha MOTOR_REGION scatterplot BEFORE outlier removal")

Alpha_Mus_Boxplot_Years_training_Hem <- ggplot(
  Alpha_Mus, 
  aes(Years_training_plot, PLV, color = Hemisphere)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                         y = "PLV",
                                                                                                                         title = "Alpha HEMISPHERE scatterplot BEFORE outlier removal")

Alpha_Mus_Boxplot_MotorRegions <- ggboxplot(
  Alpha_Mus, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Alpha_Mus: Boxplot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal",
)

Alpha_Mus_Clean_Boxplot_Years_training_Mod <- ggplot(
  Alpha_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Modality)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                       y = "PLV",
                                                                                                                       title = "Alpha MODALITY scatterplot AFTER outlier removal")

Alpha_Mus_Clean_Boxplot_Years_training_MMr <- ggplot(
  Alpha_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Motor_Region)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                           y = "PLV",
                                                                                                                           title = "Alpha MOTOR_REGION scatterplot AFTER outlier removal")

Alpha_Mus_Clean_Boxplot_Years_training_Hem <- ggplot(
  Alpha_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Hemisphere)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                         y = "PLV",
                                                                                                                         title = "Alpha HEMISPHERE scatterplot AFTER outlier removal")

Alpha_Mus_Clean_Boxplot_MotorRegions <- ggboxplot(
  Alpha_Mus_no_outliers, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Alpha_Mus: Boxplot of 'Hemisphere/Modality/Motor_Region' AFTER outlier removal",
)

Alpha_Mus_Boxplots = list(Years_training_Mod_BEFORE = Alpha_Mus_Boxplot_Years_training_Mod,
                          Years_training_MR_BEFORE = Alpha_Mus_Boxplot_Years_training_MMr,
                          Years_training_Hem_BEFORE = Alpha_Mus_Boxplot_Years_training_Hem,
                          Years_training_Mod_AFTER = Alpha_Mus_Clean_Boxplot_Years_training_Mod,
                          Years_training_MR_AFTER = Alpha_Mus_Clean_Boxplot_Years_training_MMr,
                          Years_training_Hem_AFTER = Alpha_Mus_Clean_Boxplot_Years_training_Hem,
                          MotorRegions_BEFORE = Alpha_Mus_Boxplot_MotorRegions,
                          MotorRegions_AFTER = Alpha_Mus_Clean_Boxplot_MotorRegions)

rm (Alpha_Mus_Boxplot_Years_training_Mod,
    Alpha_Mus_Boxplot_Years_training_MMr,
    Alpha_Mus_Boxplot_Years_training_Hem,
    Alpha_Mus_Clean_Boxplot_Years_training_Mod,
    Alpha_Mus_Clean_Boxplot_Years_training_MMr,
    Alpha_Mus_Clean_Boxplot_Years_training_Hem,
    Alpha_Mus_Boxplot_MotorRegions,
    Alpha_Mus_Clean_Boxplot_MotorRegions)

Beta_Mus_Boxplot_Years_training_Mod <- ggplot(
  Beta_Mus, 
  aes(Years_training_plot, PLV, color = Modality)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                       y = "PLV",
                                                                                                                       title = "Beta MODALITY scatterplot BEFORE outlier removal")

Beta_Mus_Boxplot_Years_training_MMr <- ggplot(
  Beta_Mus, 
  aes(Years_training_plot, PLV, color = Motor_Region)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                           y = "PLV",
                                                                                                                           title = "Beta MOTOR_REGION scatterplot BEFORE outlier removal")

Beta_Mus_Boxplot_Years_training_Hem <- ggplot(
  Beta_Mus, 
  aes(Years_training_plot, PLV, color = Hemisphere)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                         y = "PLV",
                                                                                                                         title = "Beta HEMISPHERE scatterplot BEFORE outlier removal")

Beta_Mus_Boxplot_MotorRegions <- ggboxplot(
  Beta_Mus, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Beta_Mus: Boxplot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal",
)

Beta_Mus_Clean_Boxplot_Years_training_Mod <- ggplot(
  Beta_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Modality)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                       y = "PLV",
                                                                                                                       title = "Beta MODALITY scatterplot AFTER outlier removal")

Beta_Mus_Clean_Boxplot_Years_training_MMr <- ggplot(
  Beta_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Motor_Region)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                           y = "PLV",
                                                                                                                           title = "Beta MOTOR_REGION scatterplot AFTER outlier removal")

Beta_Mus_Clean_Boxplot_Years_training_Hem <- ggplot(
  Beta_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Hemisphere)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                         y = "PLV",
                                                                                                                         title = "Beta HEMISPHERE scatterplot AFTER outlier removal")

Beta_Mus_Clean_Boxplot_MotorRegions <- ggboxplot(
  Beta_Mus_no_outliers, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Beta_Mus: Boxplot of 'Hemisphere/Modality/Motor_Region' AFTER outlier removal",
)

Beta_Mus_Boxplots = list(Years_training_Mod_BEFORE = Beta_Mus_Boxplot_Years_training_Mod,
                          Years_training_MR_BEFORE = Beta_Mus_Boxplot_Years_training_MMr,
                          Years_training_Hem_BEFORE = Beta_Mus_Boxplot_Years_training_Hem,
                          Years_training_Mod_AFTER = Beta_Mus_Clean_Boxplot_Years_training_Mod,
                          Years_training_MR_AFTER = Beta_Mus_Clean_Boxplot_Years_training_MMr,
                          Years_training_Hem_AFTER = Beta_Mus_Clean_Boxplot_Years_training_Hem,
                          MotorRegions_BEFORE = Beta_Mus_Boxplot_MotorRegions,
                          MotorRegions_AFTER = Beta_Mus_Clean_Boxplot_MotorRegions)

rm (Beta_Mus_Boxplot_Years_training_Mod,
    Beta_Mus_Boxplot_Years_training_MMr,
    Beta_Mus_Boxplot_Years_training_Hem,
    Beta_Mus_Clean_Boxplot_Years_training_Mod,
    Beta_Mus_Clean_Boxplot_Years_training_MMr,
    Beta_Mus_Clean_Boxplot_Years_training_Hem,
    Beta_Mus_Boxplot_MotorRegions,
    Beta_Mus_Clean_Boxplot_MotorRegions)

Gamma1_Mus_Boxplot_Years_training_Mod <- ggplot(
  Gamma1_Mus, 
  aes(Years_training_plot, PLV, color = Modality)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                       y = "PLV",
                                                                                                                       title = "Gamma1 MODALITY scatterplot BEFORE outlier removal")

Gamma1_Mus_Boxplot_Years_training_MMr <- ggplot(
  Gamma1_Mus, 
  aes(Years_training_plot, PLV, color = Motor_Region)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                           y = "PLV",
                                                                                                                           title = "Gamma1 MOTOR_REGION scatterplot BEFORE outlier removal")

Gamma1_Mus_Boxplot_Years_training_Hem <- ggplot(
  Gamma1_Mus, 
  aes(Years_training_plot, PLV, color = Hemisphere)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                         y = "PLV",
                                                                                                                         title = "Gamma1 HEMISPHERE scatterplot BEFORE outlier removal")

Gamma1_Mus_Boxplot_MotorRegions <- ggboxplot(
  Gamma1_Mus, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma1_Mus: Boxplot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal",
)

Gamma1_Mus_Clean_Boxplot_Years_training_Mod <- ggplot(
  Gamma1_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Modality)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                       y = "PLV",
                                                                                                                       title = "Gamma1 MODALITY scatterplot AFTER outlier removal")

Gamma1_Mus_Clean_Boxplot_Years_training_MMr <- ggplot(
  Gamma1_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Motor_Region)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                           y = "PLV",
                                                                                                                           title = "Gamma1 MOTOR_REGION scatterplot AFTER outlier removal")

Gamma1_Mus_Clean_Boxplot_Years_training_Hem <- ggplot(
  Gamma1_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Hemisphere)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                         y = "PLV",
                                                                                                                         title = "Gamma1 HEMISPHERE scatterplot AFTER outlier removal")

Gamma1_Mus_Clean_Boxplot_MotorRegions <- ggboxplot(
  Gamma1_Mus_no_outliers, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma1_Mus: Boxplot of 'Hemisphere/Modality/Motor_Region' AFTER outlier removal",
)

Gamma1_Mus_Boxplots = list(Years_training_Mod_BEFORE = Gamma1_Mus_Boxplot_Years_training_Mod,
                          Years_training_MR_BEFORE = Gamma1_Mus_Boxplot_Years_training_MMr,
                          Years_training_Hem_BEFORE = Gamma1_Mus_Boxplot_Years_training_Hem,
                          Years_training_Mod_AFTER = Gamma1_Mus_Clean_Boxplot_Years_training_Mod,
                          Years_training_MR_AFTER = Gamma1_Mus_Clean_Boxplot_Years_training_MMr,
                          Years_training_Hem_AFTER = Gamma1_Mus_Clean_Boxplot_Years_training_Hem,
                          MotorRegions_BEFORE = Gamma1_Mus_Boxplot_MotorRegions,
                          MotorRegions_AFTER = Gamma1_Mus_Clean_Boxplot_MotorRegions)

rm (Gamma1_Mus_Boxplot_Years_training_Mod,
    Gamma1_Mus_Boxplot_Years_training_MMr,
    Gamma1_Mus_Boxplot_Years_training_Hem,
    Gamma1_Mus_Clean_Boxplot_Years_training_Mod,
    Gamma1_Mus_Clean_Boxplot_Years_training_MMr,
    Gamma1_Mus_Clean_Boxplot_Years_training_Hem,
    Gamma1_Mus_Boxplot_MotorRegions,
    Gamma1_Mus_Clean_Boxplot_MotorRegions)

Gamma2_Mus_Boxplot_Years_training_Mod <- ggplot(
  Gamma2_Mus, 
  aes(Years_training_plot, PLV, color = Modality)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                       y = "PLV",
                                                                                                                       title = "Gamma2 MODALITY scatterplot BEFORE outlier removal")

Gamma2_Mus_Boxplot_Years_training_MMr <- ggplot(
  Gamma2_Mus, 
  aes(Years_training_plot, PLV, color = Motor_Region)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                           y = "PLV",
                                                                                                                           title = "Gamma2 MOTOR_REGION scatterplot BEFORE outlier removal")

Gamma2_Mus_Boxplot_Years_training_Hem <- ggplot(
  Gamma2_Mus, 
  aes(Years_training_plot, PLV, color = Hemisphere)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                         y = "PLV",
                                                                                                                         title = "Gamma2 HEMISPHERE scatterplot BEFORE outlier removal")

Gamma2_Mus_Boxplot_MotorRegions <- ggboxplot(
  Gamma2_Mus, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma2_Mus: Boxplot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal",
)

Gamma2_Mus_Clean_Boxplot_Years_training_Mod <- ggplot(
  Gamma2_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Modality)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                       y = "PLV",
                                                                                                                       title = "Gamma2 MODALITY scatterplot AFTER outlier removal")

Gamma2_Mus_Clean_Boxplot_Years_training_MMr <- ggplot(
  Gamma2_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Motor_Region)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                           y = "PLV",
                                                                                                                           title = "Gamma2 MOTOR_REGION scatterplot AFTER outlier removal")

Gamma2_Mus_Clean_Boxplot_Years_training_Hem <- ggplot(
  Gamma2_Mus_no_outliers, 
  aes(Years_training_plot, PLV, color = Hemisphere)) + geom_point() + geom_smooth(method = "lm", formula = y ~ x) + labs(x = "Years of training",
                                                                                                                         y = "PLV",
                                                                                                                         title = "Gamma2 HEMISPHERE scatterplot AFTER outlier removal")

Gamma2_Mus_Clean_Boxplot_MotorRegions <- ggboxplot(
  Gamma2_Mus_no_outliers, x = "Motor_Region", y = "PLV",
  color = "Hemisphere", palette = "jco",
  facet.by = "Modality", short.panel.labs = FALSE,
  title= "Gamma2_Mus: Boxplot of 'Hemisphere/Modality/Motor_Region' AFTER outlier removal",
)

Gamma2_Mus_Boxplots = list(Years_training_Mod_BEFORE = Gamma2_Mus_Boxplot_Years_training_Mod,
                          Years_training_MR_BEFORE = Gamma2_Mus_Boxplot_Years_training_MMr,
                          Years_training_Hem_BEFORE = Gamma2_Mus_Boxplot_Years_training_Hem,
                          Years_training_Mod_AFTER = Gamma2_Mus_Clean_Boxplot_Years_training_Mod,
                          Years_training_MR_AFTER = Gamma2_Mus_Clean_Boxplot_Years_training_MMr,
                          Years_training_Hem_AFTER = Gamma2_Mus_Clean_Boxplot_Years_training_Hem,
                          MotorRegions_BEFORE = Gamma2_Mus_Boxplot_MotorRegions,
                          MotorRegions_AFTER = Gamma2_Mus_Clean_Boxplot_MotorRegions)

rm (Gamma2_Mus_Boxplot_Years_training_Mod,
    Gamma2_Mus_Boxplot_Years_training_MMr,
    Gamma2_Mus_Boxplot_Years_training_Hem,
    Gamma2_Mus_Clean_Boxplot_Years_training_Mod,
    Gamma2_Mus_Clean_Boxplot_Years_training_MMr,
    Gamma2_Mus_Clean_Boxplot_Years_training_Hem,
    Gamma2_Mus_Boxplot_MotorRegions,
    Gamma2_Mus_Clean_Boxplot_MotorRegions)

# Step 4: We funnel everything into one mega-list

Delta_Mus_Info = list(Stats = Delta_Mus_Summary, Plots = Delta_Mus_Boxplots)
rm (Delta_Mus_Summary,Delta_Mus_Boxplots)

Theta_Mus_Info = list(Stats = Theta_Mus_Summary, Plots = Theta_Mus_Boxplots)
rm (Theta_Mus_Summary,Theta_Mus_Boxplots)

Alpha_Mus_Info = list(Stats = Alpha_Mus_Summary, Plots = Alpha_Mus_Boxplots)
rm (Alpha_Mus_Summary,Alpha_Mus_Boxplots)

Beta_Mus_Info = list(Stats = Beta_Mus_Summary, Plots = Beta_Mus_Boxplots)
rm (Beta_Mus_Summary,Beta_Mus_Boxplots)

Gamma1_Mus_Info = list(Stats = Gamma1_Mus_Summary, Plots = Gamma1_Mus_Boxplots)
rm (Gamma1_Mus_Summary,Gamma1_Mus_Boxplots)

Gamma2_Mus_Info = list(Stats = Gamma2_Mus_Summary, Plots = Gamma2_Mus_Boxplots)
rm (Gamma2_Mus_Summary,Gamma2_Mus_Boxplots)

Summary_Bands = list (Delta_Mus = Delta_Mus_Info,
                      Theta_Mus = Theta_Mus_Info,
                      Alpha_Mus = Alpha_Mus_Info,
                      Beta_Mus = Beta_Mus_Info,
                      Gamma1_Mus = Gamma1_Mus_Info,
                      Gamma2_Mus = Gamma2_Mus_Info)

rm (Delta_Mus_Info,Theta_Mus_Info,Alpha_Mus_Info,Beta_Mus_Info,Gamma1_Mus_Info,Gamma2_Mus_Info)

# Step 7: Normality assumptions: Shapiro-Wilk

Delta_Mus_normality <- Delta_Mus %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  shapiro_test(PLV)

Theta_Mus_normality <- Theta_Mus %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  shapiro_test(PLV)

Alpha_Mus_normality <- Alpha_Mus %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  shapiro_test(PLV)

Beta_Mus_normality <- Beta_Mus %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  shapiro_test(PLV)

Gamma1_Mus_normality <- Gamma1_Mus %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  shapiro_test(PLV)

Gamma2_Mus_normality <- Gamma2_Mus %>%
  group_by(Hemisphere,Modality,Motor_Region) %>%
  shapiro_test(PLV)

Normality_Bands = list(Delta_Mus = Delta_Mus_normality,
                       Theta_Mus = Theta_Mus_normality,
                       Alpha_Mus = Alpha_Mus_normality,
                       Beta_Mus = Beta_Mus_normality,
                       Gamma1_Mus = Gamma1_Mus_normality,
                       Gamma2_Mus = Gamma2_Mus_normality)

rm(Delta_Mus_normality,Theta_Mus_normality,Alpha_Mus_normality,Beta_Mus_normality,Gamma1_Mus_normality,Gamma2_Mus_normality)

# Step 8: QQ plots and Density plots

Delta_Mus_QQ <- ggqqplot(Delta_Mus, "PLV", ggtheme = theme_bw(), 
                     title= "Delta_Mus: QQ plot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal") +
  facet_grid(Hemisphere ~ Modality + Motor_Region, labeller = "label_both")

Theta_Mus_QQ <- ggqqplot(Theta_Mus, "PLV", ggtheme = theme_bw(), 
                     title= "Theta_Mus: QQ plot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal") +
  facet_grid(Hemisphere ~ Modality + Motor_Region, labeller = "label_both")

Alpha_Mus_QQ <- ggqqplot(Alpha_Mus, "PLV", ggtheme = theme_bw(), 
                     title= "Alpha_Mus: QQ plot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal") +
  facet_grid(Hemisphere ~ Modality + Motor_Region, labeller = "label_both")

Beta_Mus_QQ <-  ggqqplot(Beta_Mus, "PLV", ggtheme = theme_bw(), 
                     title= "Beta_Mus: QQ plot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal") +
  facet_grid(Hemisphere ~ Modality + Motor_Region, labeller = "label_both")

Gamma1_Mus_QQ <- ggqqplot(Gamma1_Mus, "PLV", ggtheme = theme_bw(), 
                      title= "Gamma1_Mus: QQ plot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal") +
  facet_grid(Hemisphere ~ Modality + Motor_Region, labeller = "label_both")

Gamma2_Mus_QQ <- ggqqplot(Gamma2_Mus, "PLV", ggtheme = theme_bw(), 
                      title= "Gamma2_Mus: QQ plot of 'Hemisphere/Modality/Motor_Region' BEFORE outlier removal") +
  facet_grid(Hemisphere ~ Modality + Motor_Region, labeller = "label_both")

QQ_Bands = list(Delta_Mus = Delta_Mus_QQ,
                Theta_Mus = Theta_Mus_QQ,
                Alpha_Mus = Alpha_Mus_QQ,
                Beta_Mus = Beta_Mus_QQ,
                Gamma1_Mus = Gamma1_Mus_QQ,
                Gamma2_Mus = Gamma2_Mus_QQ)

rm(Delta_Mus_QQ,Theta_Mus_QQ,Alpha_Mus_QQ,Beta_Mus_QQ,Gamma1_Mus_QQ,Gamma2_Mus_QQ)

Delta_Mus_density <- ggdensity(Delta_Mus$PLV, fill = "lightgray",title="Delta_Mus: density plot BEFORE outlier removal")
Theta_Mus_density <- ggdensity(Theta_Mus$PLV, fill = "lightgray",title="Theta_Mus: density plot BEFORE outlier removal")
Alpha_Mus_density <- ggdensity(Alpha_Mus$PLV, fill = "lightgray",title="Alpha_Mus: density plot BEFORE outlier removal")
Beta_Mus_density <- ggdensity(Beta_Mus$PLV, fill = "lightgray",title="Beta_Mus: density plot BEFORE outlier removal")
Gamma1_Mus_density <- ggdensity(Gamma1_Mus$PLV, fill = "lightgray",title="Gamam1:: density plot BEFORE outlier removal")
Gamma2_Mus_density <- ggdensity(Gamma2_Mus$PLV, fill = "lightgray",title="Gamma2_Mus: density plot BEFORE outlier removal")

Density_Bands = list(Delta_Mus = Delta_Mus_density,
                     Theta_Mus = Theta_Mus_density,
                     Alpha_Mus = Alpha_Mus_density,
                     Beta_Mus = Beta_Mus_density,
                     Gamma1_Mus = Gamma1_Mus_density,
                     Gamma2_Mus = Gamma2_Mus_density)

rm(Delta_Mus_density,Theta_Mus_density,Alpha_Mus_density,Beta_Mus_density,Gamma1_Mus_density,Gamma2_Mus_density)

###########################################
# PART 4: Generate the interaction barplots
###########################################

Delta_Mus_Summary1 <- Delta_Mus %>%
  group_by(Hemisphere,Modality) %>%
  get_summary_stats(PLV, type = "mean_sd")

Delta_Mus_Barplot_Interaction1 <- ggbarplot(
  Delta_Mus_Summary1, x = "Modality", y = "mean",
  fill = "Hemisphere", color = "Hemisphere",
  position = position_dodge(0.9),
  title= "Delta: Barplot of 'Hemisphere*Modality' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

Delta_Mus_Summary2 <- Delta_Mus %>%
  group_by(Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Delta_Mus_Barplot_Interaction2 <- ggbarplot(
  Delta_Mus_Summary2, x = "Motor_Region", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Delta: Barplot of 'Modality*Motor_Region' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4)

# Theta

Theta_Mus_Summary1 <- Theta_Mus %>%
  group_by(Hemisphere) %>%
  get_summary_stats(PLV, type = "mean_sd")

Theta_Mus_Barplot1 <- ggbarplot(
  Theta_Mus_Summary1, x = "Hemisphere", y = "mean",
  title= "Theta: Barplot of 'Hemisphere' (main effect)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  color = "black",
  fill = "white",
  label = TRUE, lab.vjust = -0.4
)

Theta_Mus_Summary2 <- Theta_Mus %>%
  group_by(Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Theta_Mus_Barplot_Interaction2 <- ggbarplot(
  Theta_Mus_Summary2, x = "Motor_Region", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Theta: Barplot of 'Modality*Motor_Region' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Alpha

Alpha_Mus_Summary1 <- Alpha_Mus %>%
  group_by(Hemisphere) %>%
  get_summary_stats(PLV, type = "mean_sd")

Alpha_Mus_Barplot1 <- ggbarplot(
  Alpha_Mus_Summary1, x = "Hemisphere", y = "mean",
  title= "Alpha: Barplot of 'Hemisphere' (main effect)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  color = "black",
  fill = "white",
  label = TRUE, lab.vjust = -0.4
)

Alpha_Mus_Summary2 <- Alpha_Mus %>%
  group_by(Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Alpha_Mus_Barplot_Interaction2 <- ggbarplot(
  Alpha_Mus_Summary2, x = "Motor_Region", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Alpha: Barplot of 'Modality*Motor_Region' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Beta

Beta_Mus_Summary1 <- Beta_Mus %>%
  group_by(Hemisphere) %>%
  get_summary_stats(PLV, type = "mean_sd")

Beta_Mus_Barplot1 <- ggbarplot(
  Beta_Mus_Summary1, x = "Hemisphere", y = "mean",
  title= "Beta: Barplot of 'Hemisphere' (main effect)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  color = "black",
  fill = "white",
  label = TRUE, lab.vjust = -0.4
)

Beta_Mus_Summary2 <- Beta_Mus %>%
  group_by(Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Beta_Mus_Barplot_Interaction2 <- ggbarplot(
  Beta_Mus_Summary2, x = "Motor_Region", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Beta: Barplot of 'Modality*Motor_Region' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Gamma1 

Gamma1_Mus_Summary1 <- Gamma1_Mus %>%
  group_by(Hemisphere) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma1_Mus_Barplot1 <- ggbarplot(
  Gamma1_Mus_Summary1, x = "Hemisphere", y = "mean",
  title= "Gamma1: Barplot of 'Hemisphere' (main effect)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  color = "black",
  fill = "white",
  label = TRUE, lab.vjust = -0.4
)

Gamma1_Mus_Summary2 <- Gamma1_Mus %>%
  group_by(Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma1_Mus_Barplot_Interaction2 <- ggbarplot(
  Gamma1_Mus_Summary2, x = "Motor_Region", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Gamma1: Barplot of 'Modality*Motor_Region' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

# Gamma2

Gamma2_Mus_Summary1 <- Gamma2_Mus %>%
  group_by(Hemisphere) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma2_Mus_Barplot1 <- ggbarplot(
  Gamma2_Mus_Summary1, x = "Hemisphere", y = "mean",
  title= "Gamma2: Barplot of 'Hemisphere' (main effect)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  color = "black",
  fill = "white",
  label = TRUE, lab.vjust = -0.4
)

Gamma2_Mus_Summary2 <- Gamma2_Mus %>%
  group_by(Modality,Motor_Region) %>%
  get_summary_stats(PLV, type = "mean_sd")

Gamma2_Mus_Barplot_Interaction2 <- ggbarplot(
  Gamma2_Mus_Summary2, x = "Motor_Region", y = "mean",
  fill = "Modality", color = "Modality",
  position = position_dodge(0.9),
  title= "Gamma2: Barplot of 'Modality*Motor_Region' (Interaction)",
  ylab = "mean PLV",
  combine = FALSE,
  merge = FALSE,
  label = TRUE, lab.vjust = -0.4
)

###########################
# PART 5: Generate the pdfs
###########################

pdf("Delta_MUS_LinearRegression_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

options(digits=5)

grid.arrange(nrow=1,top="Delta: 'Years of training' summary", tableGrob(Summary_Bands$Delta_Mus$Stats$Years_training))
grid.arrange(nrow=1,top="Delta: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Delta_Mus$Stats$Modality))

plot(Summary_Bands$Delta_Mus$Plots$Years_training_Mod_BEFORE)
plot(Summary_Bands$Delta_Mus$Plots$Years_training_MR_BEFORE)
plot(Summary_Bands$Delta_Mus$Plots$Years_training_Hem_BEFORE)
plot(Summary_Bands$Delta_Mus$Plots$MotorRegions_BEFORE)

grid.arrange(nrow=1,top="Delta: Number of outliers removed out of 348 PLVs", tableGrob(summary(Outliers_Bands$Delta_Mus$is.outlier)))

plot(Summary_Bands$Delta_Mus$Plots$Years_training_Mod_AFTER)
plot(Summary_Bands$Delta_Mus$Plots$Years_training_MR_AFTER)
plot(Summary_Bands$Delta_Mus$Plots$Years_training_Hem_AFTER)
plot(Summary_Bands$Delta_Mus$Plots$MotorRegions_AFTER)

plot(QQ_Bands$Delta_Mus)

grid.arrange(nrow=1,top="Delta: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Delta_Mus))

plot(Density_Bands$Delta_Mus)

GLMM3_Delta_Mus$Omnibus$p.value <- round(GLMM3_Delta_Mus$Omnibus$p.value,3)
GLMM3_Delta_Mus$Hem_by_Mod$p.value <- round(GLMM3_Delta_Mus$Hem_by_Mod$p.value,3)
GLMM3_Delta_Mus$Hem_by_Mod$bonferroni <- round(GLMM3_Delta_Mus$Hem_by_Mod$bonferroni,3)
GLMM3_Delta_Mus$Mod_by_MR$p.value <- round(GLMM3_Delta_Mus$Mod_by_MR$p.value,3)
GLMM3_Delta_Mus$Mod_by_MR$bonferroni <- round(GLMM3_Delta_Mus$Mod_by_MR$bonferroni,3)

grid.arrange(nrow=1,top="Delta: GLM main effects and interactions", tableGrob(GLMM3_Delta_Mus$Omnibus))
grid.arrange(nrow=1,top="Delta: GLM post-hoc test: 'Hemisphere*Modality'", tableGrob(GLMM3_Delta_Mus$Hem_by_Mod))
grid.arrange(nrow=1,top="Delta: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM3_Delta_Mus$Mod_by_MR))

plot(Delta_Mus_Barplot_Interaction1)
plot(Delta_Mus_Barplot_Interaction2)

dev.off()

pdf("Theta_MUS_LinearRegression_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Theta: 'Years of training' summary", tableGrob(Summary_Bands$Theta_Mus$Stats$Years_training))
grid.arrange(nrow=1,top="Theta: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Theta_Mus$Stats$Modality))

plot(Summary_Bands$Theta_Mus$Plots$Years_training_Mod_BEFORE)
plot(Summary_Bands$Theta_Mus$Plots$Years_training_MR_BEFORE)
plot(Summary_Bands$Theta_Mus$Plots$Years_training_Hem_BEFORE)
plot(Summary_Bands$Theta_Mus$Plots$MotorRegions_BEFORE)

grid.arrange(nrow=1,top="Theta: Number of outliers removed out of 348 PLVs", tableGrob(summary(Outliers_Bands$Theta_Mus$is.outlier)))

plot(Summary_Bands$Theta_Mus$Plots$Years_training_Mod_AFTER)
plot(Summary_Bands$Theta_Mus$Plots$Years_training_MR_AFTER)
plot(Summary_Bands$Theta_Mus$Plots$Years_training_Hem_AFTER)
plot(Summary_Bands$Theta_Mus$Plots$MotorRegions_AFTER)

plot(QQ_Bands$Theta, main = "Theta band: QQ plot BEFORE outlier removal")

grid.arrange(nrow=1,top="Theta: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Theta_Mus))

plot(Density_Bands$Theta, main = "Density plot BEFORE outlier removal")

GLMM3_Theta_Mus$Omnibus$p.value <- round(GLMM3_Theta_Mus$Omnibus$p.value,3)
GLMM3_Theta_Mus$Mod_by_MR$p.value <- round(GLMM3_Theta_Mus$Mod_by_MR$p.value,3)
GLMM3_Theta_Mus$Mod_by_MR$bonferroni <- round(GLMM3_Theta_Mus$Mod_by_MR$bonferroni,3)

grid.arrange(nrow=1,top="Theta: GLM main effects and interactions", tableGrob(GLMM3_Theta_Mus$Omnibus))
grid.arrange(nrow=1,top="Theta: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM3_Theta_Mus$Mod_by_MR))

plot(Theta_Mus_Barplot1)
plot(Theta_Mus_Barplot_Interaction2)

dev.off()

pdf("Alpha_MUS_LinearRegression_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Alpha: 'Years of training' summary", tableGrob(Summary_Bands$Alpha_Mus$Stats$Years_training))
grid.arrange(nrow=1,top="Alpha: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Alpha_Mus$Stats$Modality))

plot(Summary_Bands$Alpha_Mus$Plots$Years_training_Mod_BEFORE)
plot(Summary_Bands$Alpha_Mus$Plots$Years_training_MR_BEFORE)
plot(Summary_Bands$Alpha_Mus$Plots$Years_training_Hem_BEFORE)
plot(Summary_Bands$Alpha_Mus$Plots$MotorRegions_BEFORE)

grid.arrange(nrow=1,top="Alpha: Number of outliers removed out of 348 PLVs", tableGrob(summary(Outliers_Bands$Alpha_Mus$is.outlier)))

plot(Summary_Bands$Alpha_Mus$Plots$Years_training_Mod_AFTER)
plot(Summary_Bands$Alpha_Mus$Plots$Years_training_MR_AFTER)
plot(Summary_Bands$Alpha_Mus$Plots$Years_training_Hem_AFTER)
plot(Summary_Bands$Alpha_Mus$Plots$MotorRegions_AFTER)

plot(QQ_Bands$Alpha, main = "Alpha band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Alpha: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Alpha_Mus))

plot(Density_Bands$Alpha, main = "Density plot after outlier removal")

GLMM3_Alpha_Mus$Omnibus$p.value <- round(GLMM3_Alpha_Mus$Omnibus$p.value,3)
GLMM3_Alpha_Mus$Mod_by_MR$p.value <- round(GLMM3_Alpha_Mus$Mod_by_MR$p.value,3)
GLMM3_Alpha_Mus$Mod_by_MR$bonferroni <- round(GLMM3_Alpha_Mus$Mod_by_MR$bonferroni,3)

grid.arrange(nrow=1,top="Alpha: GLM main effects and interactions", tableGrob(GLMM3_Alpha_Mus$Omnibus))
grid.arrange(nrow=1,top="Alpha: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM3_Alpha_Mus$Mod_by_MR))

plot(Alpha_Mus_Barplot1)
plot(Alpha_Mus_Barplot_Interaction2)

dev.off()

pdf("Beta_MUS_LinearRegression_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Beta: 'Years of training' summary", tableGrob(Summary_Bands$Beta_Mus$Stats$Years_training))
grid.arrange(nrow=1,top="Beta: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Beta_Mus$Stats$Modality))

plot(Summary_Bands$Beta_Mus$Plots$Years_training_Mod_BEFORE)
plot(Summary_Bands$Beta_Mus$Plots$Years_training_MR_BEFORE)
plot(Summary_Bands$Beta_Mus$Plots$Years_training_Hem_BEFORE)
plot(Summary_Bands$Beta_Mus$Plots$MotorRegions_BEFORE)

grid.arrange(nrow=1,top="Beta: Number of outliers removed out of 348 PLVs", tableGrob(summary(Outliers_Bands$Beta_Mus$is.outlier)))

plot(Summary_Bands$Beta_Mus$Plots$Years_training_Mod_AFTER)
plot(Summary_Bands$Beta_Mus$Plots$Years_training_MR_AFTER)
plot(Summary_Bands$Beta_Mus$Plots$Years_training_Hem_AFTER)
plot(Summary_Bands$Beta_Mus$Plots$MotorRegions_AFTER)

plot(QQ_Bands$Beta, main = "Beta band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Beta: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Beta_Mus))

plot(Density_Bands$Beta, main = "Density plot after outlier removal")

GLMM3_Beta_Mus$Omnibus$p.value <- round(GLMM3_Beta_Mus$Omnibus$p.value,3)
GLMM3_Beta_Mus$Mod_by_MR$p.value <- round(GLMM3_Beta_Mus$Mod_by_MR$p.value,3)
GLMM3_Beta_Mus$Mod_by_MR$bonferroni <- round(GLMM3_Beta_Mus$Mod_by_MR$bonferroni,3)

grid.arrange(nrow=1,top="Beta: GLM main effects and interactions", tableGrob(GLMM3_Beta_Mus$Omnibus))
grid.arrange(nrow=1,top="Beta: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM3_Beta_Mus$Mod_by_MR))

plot(Beta_Mus_Barplot1)
plot(Beta_Mus_Barplot_Interaction2)

dev.off()

options(digits=3)

pdf("Gamma1_MUS_LinearRegression_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Gamma1: 'Years of training' summary", tableGrob(Summary_Bands$Gamma1_Mus$Stats$Years_training))
grid.arrange(nrow=1,top="Gamma1: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Gamma1_Mus$Stats$Modality))

plot(Summary_Bands$Gamma1_Mus$Plots$Years_training_Mod_BEFORE)
plot(Summary_Bands$Gamma1_Mus$Plots$Years_training_MR_BEFORE)
plot(Summary_Bands$Gamma1_Mus$Plots$Years_training_Hem_BEFORE)
plot(Summary_Bands$Gamma1_Mus$Plots$MotorRegions_BEFORE)

grid.arrange(nrow=1,top="Gamma1: Number of outliers removed out of 348 PLVs", tableGrob(summary(Outliers_Bands$Gamma1_Mus$is.outlier)))

plot(Summary_Bands$Gamma1_Mus$Plots$Years_training_Mod_AFTER)
plot(Summary_Bands$Gamma1_Mus$Plots$Years_training_MR_AFTER)
plot(Summary_Bands$Gamma1_Mus$Plots$Years_training_Hem_AFTER)
plot(Summary_Bands$Gamma1_Mus$Plots$MotorRegions_AFTER)

plot(QQ_Bands$Gamma1, main = "Gamma1 band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Gamma1: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Gamma1_Mus))

plot(Density_Bands$Gamma1, main = "Density plot after outlier removal")

GLMM3_Gamma1_Mus$Omnibus$p.value <- round(GLMM3_Gamma1_Mus$Omnibus$p.value,3)
GLMM3_Gamma1_Mus$Mod_by_MR$p.value <- round(GLMM3_Gamma1_Mus$Mod_by_MR$p.value,3)
GLMM3_Gamma1_Mus$Mod_by_MR$bonferroni <- round(GLMM3_Gamma1_Mus$Mod_by_MR$bonferroni,3)

grid.arrange(nrow=1,top="Gamma1: GLM main effects and interactions", tableGrob(GLMM3_Gamma1_Mus$Omnibus))
grid.arrange(nrow=1,top="Gamma1: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM3_Gamma1_Mus$Mod_by_MR))

plot(Gamma1_Mus_Barplot1)
plot(Gamma1_Mus_Barplot_Interaction2)

dev.off()

pdf("Gamma2_MUS_LinearRegression_PLV.pdf",width=10,height=7)

library(grid)
library(gridExtra)

grid.arrange(nrow=1,top="Gamma2: 'Years of training' summary", tableGrob(Summary_Bands$Gamma2_Mus$Stats$Years_training))
grid.arrange(nrow=1,top="Gamma2: 'Hemisphere/Modality/Motor_Region' summary", tableGrob(Summary_Bands$Gamma2_Mus$Stats$Modality))

plot(Summary_Bands$Gamma2_Mus$Plots$Years_training_Mod_BEFORE)
plot(Summary_Bands$Gamma2_Mus$Plots$Years_training_MR_BEFORE)
plot(Summary_Bands$Gamma2_Mus$Plots$Years_training_Hem_BEFORE)
plot(Summary_Bands$Gamma2_Mus$Plots$MotorRegions_BEFORE)

grid.arrange(nrow=1,top="Gamma2: Number of outliers removed out of 348 PLVs", tableGrob(summary(Outliers_Bands$Gamma2_Mus$is.outlier)))

plot(Summary_Bands$Gamma2_Mus$Plots$Years_training_Mod_AFTER)
plot(Summary_Bands$Gamma2_Mus$Plots$Years_training_MR_AFTER)
plot(Summary_Bands$Gamma2_Mus$Plots$Years_training_Hem_AFTER)
plot(Summary_Bands$Gamma2_Mus$Plots$MotorRegions_AFTER)

plot(QQ_Bands$Gamma2, main = "Gamma2 band: QQ plot AFTER outlier removal")

grid.arrange(nrow=1,top="Gamma2: Shapiro-Wilk's normality test BEFORE outlier removal", tableGrob(Normality_Bands$Gamma2_Mus))

plot(Density_Bands$Gamma2, main = "Density plot after outlier removal")

GLMM3_Gamma2_Mus$Omnibus$p.value <- round(GLMM3_Gamma2_Mus$Omnibus$p.value,3)
GLMM3_Gamma2_Mus$Mod_by_MR$p.value <- round(GLMM3_Gamma2_Mus$Mod_by_MR$p.value,3)
GLMM3_Gamma2_Mus$Mod_by_MR$bonferroni <- round(GLMM3_Gamma2_Mus$Mod_by_MR$bonferroni,3)

grid.arrange(nrow=1,top="Gamma2: GLM main effects and interactions", tableGrob(GLMM3_Gamma2_Mus$Omnibus))
grid.arrange(nrow=1,top="Gamma2: GLM post-hoc test: 'Modality*Motor_Region'", tableGrob(GLMM3_Gamma2_Mus$Mod_by_MR))

plot(Gamma2_Mus_Barplot1)
plot(Gamma2_Mus_Barplot_Interaction2)

dev.off()
