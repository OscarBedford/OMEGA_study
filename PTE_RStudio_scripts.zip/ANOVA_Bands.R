
########################################################################################
## CALCULATE AND PLOT ANOVAs BASED on ANOVA_BANDS variable created with 'ExtractAM-VM.R'
########################################################################################

###############################################
## First we extract the dataframe for each Band
###############################################

Delta <- data.frame(ANOVA_BANDS$delta)
Theta <- data.frame(ANOVA_BANDS$theta)
Alpha <- data.frame(ANOVA_BANDS$alpha)
Beta <- data.frame(ANOVA_BANDS$beta)
Gamma1 <- data.frame(ANOVA_BANDS$gamma1)
Gamma2 <- data.frame(ANOVA_BANDS$gamma2)

########################################################################################
## Then we delete sub-0006 from all matrices, because they're left-handed and a musician
########################################################################################

Delta <- Delta[c(1,2,3,4,5,6,9,10),]
Theta <- Theta[c(1,2,3,4,5,6,9,10),]
Alpha <- Alpha[c(1,2,3,4,5,6,9,10),]
Beta <- Beta[c(1,2,3,4,5,6,9,10),]
Gamma1 <- Gamma1[c(1,2,3,4,5,6,9,10),]
Gamma2 <- Gamma2[c(1,2,3,4,5,6,9,10),]

##################################################################################
## It's important that we transform the PLV columns from class 'list' to 'numeric'
##################################################################################

Delta$AM.VM <- as.numeric(as.character(Delta$AM.VM))
Delta$AM.vPMC <- as.numeric(as.character(Delta$AM.vPMC))
Delta$AM.dPMC <- as.numeric(as.character(Delta$AM.dPMC))

Theta$AM.VM <- as.numeric(as.character(Theta$AM.VM))
Theta$AM.vPMC <- as.numeric(as.character(Theta$AM.vPMC))
Theta$AM.dPMC <- as.numeric(as.character(Theta$AM.dPMC))

Alpha$AM.VM <- as.numeric(as.character(Alpha$AM.VM))
Alpha$AM.vPMC <- as.numeric(as.character(Alpha$AM.vPMC))
Alpha$AM.dPMC <- as.numeric(as.character(Alpha$AM.dPMC))

Beta$AM.VM <- as.numeric(as.character(Beta$AM.VM))
Beta$AM.vPMC <- as.numeric(as.character(Beta$AM.vPMC))
Beta$AM.dPMC <- as.numeric(as.character(Beta$AM.dPMC))

Gamma1$AM.VM <- as.numeric(as.character(Gamma1$AM.VM))
Gamma1$AM.vPMC <- as.numeric(as.character(Gamma1$AM.vPMC))
Gamma1$AM.dPMC <- as.numeric(as.character(Gamma1$AM.dPMC))

Gamma2$AM.VM <- as.numeric(as.character(Gamma2$AM.VM))
Gamma2$AM.vPMC <- as.numeric(as.character(Gamma2$AM.vPMC))
Gamma2$AM.dPMC <- as.numeric(as.character(Gamma2$AM.dPMC))

##################################################################################
## It's important that we transform the Anova factors from class 'list' to 'factor'
##################################################################################

Delta$ID <- as.factor(as.character(Delta$ID))
Delta$Hemisphere <- as.factor(as.character(Delta$Hemisphere))
Delta$Musicianship <- as.factor(as.character(Delta$Musicianship))

Theta$ID <- as.factor(as.character(Theta$ID))
Theta$Hemisphere <- as.factor(as.character(Theta$Hemisphere))
Theta$Musicianship <- as.factor(as.character(Theta$Musicianship))

Alpha$ID <- as.factor(as.character(Alpha$ID))
Alpha$Hemisphere <- as.factor(as.character(Alpha$Hemisphere))
Alpha$Musicianship <- as.factor(as.character(Alpha$Musicianship))

Beta$ID <- as.factor(as.character(Beta$ID))
Beta$Hemisphere <- as.factor(as.character(Beta$Hemisphere))
Beta$Musicianship <- as.factor(as.character(Beta$Musicianship))

Gamma1$ID <- as.factor(as.character(Gamma1$ID))
Gamma1$Hemisphere <- as.factor(as.character(Gamma1$Hemisphere))
Gamma1$Musicianship <- as.factor(as.character(Gamma1$Musicianship))

Gamma2$ID <- as.factor(as.character(Gamma2$ID))
Gamma2$Hemisphere <- as.factor(as.character(Gamma2$Hemisphere))
Gamma2$Musicianship <- as.factor(as.character(Gamma2$Musicianship))

###################################################################
## We're ready to create the aov variables, as an intermediate step
###################################################################

ANOVA_Delta_AM.VM <- aov(AM.VM~Hemisphere,data=Delta)
ANOVA_Delta_AM.vPMC <- aov(AM.vPMC~Hemisphere,data=Delta)
ANOVA_Delta_AM.dPMC <- aov(AM.dPMC~Hemisphere,data=Delta)

ANOVA_Theta_AM.VM <- aov(AM.VM~Hemisphere,data=Theta)
ANOVA_Theta_AM.vPMC <- aov(AM.vPMC~Hemisphere,data=Theta)
ANOVA_Theta_AM.dPMC <- aov(AM.dPMC~Hemisphere,data=Theta)

ANOVA_Alpha_AM.VM <- aov(AM.VM~Hemisphere,data=Alpha)
ANOVA_Alpha_AM.vPMC <- aov(AM.vPMC~Hemisphere,data=Alpha)
ANOVA_Alpha_AM.dPMC <- aov(AM.dPMC~Hemisphere,data=Alpha)

ANOVA_Beta_AM.VM <- aov(AM.VM~Hemisphere,data=Beta)
ANOVA_Beta_AM.vPMC <- aov(AM.vPMC~Hemisphere,data=Beta)
ANOVA_Beta_AM.dPMC <- aov(AM.dPMC~Hemisphere,data=Beta)

ANOVA_Gamma1_AM.VM <- aov(AM.VM~Hemisphere,data=Gamma1)
ANOVA_Gamma1_AM.vPMC <- aov(AM.vPMC~Hemisphere,data=Gamma1)
ANOVA_Gamma1_AM.dPMC <- aov(AM.dPMC~Hemisphere,data=Gamma1)

ANOVA_Gamma2_AM.VM <- aov(AM.VM~Hemisphere,data=Gamma2)
ANOVA_Gamma2_AM.vPMC <- aov(AM.vPMC~Hemisphere,data=Gamma2)
ANOVA_Gamma2_AM.dPMC <- aov(AM.dPMC~Hemisphere,data=Gamma2)

########################################################################
## Now we use the aov variables to create the definitive ANOVA variables
########################################################################

ANOVA_Delta_AM.VM <- anova(ANOVA_Delta_AM.VM)
ANOVA_Delta_AM.vPMC <- anova(ANOVA_Delta_AM.vPMC)
ANOVA_Delta_AM.dPMC <- anova(ANOVA_Delta_AM.dPMC)

ANOVA_Theta_AM.VM <- anova(ANOVA_Theta_AM.VM)
ANOVA_Theta_AM.vPMC <- anova(ANOVA_Theta_AM.vPMC)
ANOVA_Theta_AM.dPMC <- anova(ANOVA_Theta_AM.dPMC)

ANOVA_Alpha_AM.VM <- anova(ANOVA_Alpha_AM.VM)
ANOVA_Alpha_AM.vPMC <- anova(ANOVA_Alpha_AM.vPMC)
ANOVA_Alpha_AM.dPMC <- anova(ANOVA_Alpha_AM.dPMC)

ANOVA_Beta_AM.VM <- anova(ANOVA_Beta_AM.VM)
ANOVA_Beta_AM.vPMC <- anova(ANOVA_Beta_AM.vPMC)
ANOVA_Beta_AM.dPMC <- anova(ANOVA_Beta_AM.dPMC)

ANOVA_Gamma1_AM.VM <- anova(ANOVA_Gamma1_AM.VM)
ANOVA_Gamma1_AM.vPMC <- anova(ANOVA_Gamma1_AM.vPMC)
ANOVA_Gamma1_AM.dPMC <- anova(ANOVA_Gamma1_AM.dPMC)

ANOVA_Gamma2_AM.VM <- anova(ANOVA_Gamma2_AM.VM)
ANOVA_Gamma2_AM.vPMC <- anova(ANOVA_Gamma2_AM.vPMC)
ANOVA_Gamma2_AM.dPMC <- anova(ANOVA_Gamma2_AM.dPMC)

###############################
## We're finally ready to plot!
###############################

# But first we will create the pdf filename where we will save the plot:

pdf("ANOVA_6freqbands_PLV_FirstTEST.pdf")

# Now we make the 18 plots (6bands*3connections) 

plot(AM.VM~Hemisphere,data=Delta, main = "Delta band: Auditory-Motor PLV values minus Visuo-Motor PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Delta_AM.VM$`Pr(>F)`[1],digits=4)))
plot(AM.vPMC~Hemisphere,data=Delta, main = "Delta band: Auditory-vPMC PLV values minus Visuo-vPMC PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Delta_AM.vPMC$`Pr(>F)`[1],digits=4)))
plot(AM.dPMC~Hemisphere,data=Delta, main = "Delta band: Auditory-dPMC PLV values minus Visuo-dPMC PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Delta_AM.dPMC$`Pr(>F)`[1],digits=4)))

plot(AM.VM~Hemisphere,data=Theta, main = "Theta band: Auditory-Motor PLV values minus Visuo-Motor PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Theta_AM.VM$`Pr(>F)`[1],digits=4)))
plot(AM.vPMC~Hemisphere,data=Theta, main = "Theta band: Auditory-vPMC PLV values minus Visuo-vPMC PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Theta_AM.vPMC$`Pr(>F)`[1],digits=4)))
plot(AM.dPMC~Hemisphere,data=Theta, main = "Theta band: Auditory-dPMC PLV values minus Visuo-dPMC PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Theta_AM.dPMC$`Pr(>F)`[1],digits=4)))

plot(AM.VM~Hemisphere,data=Alpha, main = "Alpha band: Auditory-Motor PLV values minus Visuo-Motor PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Alpha_AM.VM$`Pr(>F)`[1],digits=4)))
plot(AM.vPMC~Hemisphere,data=Alpha, main = "Alpha band: Auditory-vPMC PLV values minus Visuo-vPMC PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Alpha_AM.vPMC$`Pr(>F)`[1],digits=4)))
plot(AM.dPMC~Hemisphere,data=Alpha, main = "Alpha band: Auditory-dPMC PLV values minus Visuo-dPMC PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Alpha_AM.dPMC$`Pr(>F)`[1],digits=4)))

plot(AM.VM~Hemisphere,data=Beta, main = "Beta band: Auditory-Motor PLV values minus Visuo-Motor PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Beta_AM.VM$`Pr(>F)`[1],digits=4)))
plot(AM.vPMC~Hemisphere,data=Beta, main = "Beta band: Auditory-vPMC PLV values minus Visuo-vPMC PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Beta_AM.vPMC$`Pr(>F)`[1],digits=4)))
plot(AM.dPMC~Hemisphere,data=Beta, main = "Beta band: Auditory-dPMC PLV values minus Visuo-dPMC PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Beta_AM.dPMC$`Pr(>F)`[1],digits=4)))

plot(AM.VM~Hemisphere,data=Gamma1, main = "Gamma1 band: Auditory-Motor PLV values minus Visuo-Motor PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Gamma1_AM.VM$`Pr(>F)`[1],digits=4)))
plot(AM.vPMC~Hemisphere,data=Gamma1, main = "Gamma1 band: Auditory-vPMC PLV values minus Visuo-vPMC PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Gamma1_AM.vPMC$`Pr(>F)`[1],digits=4)))
plot(AM.dPMC~Hemisphere,data=Gamma1, main = "Gamma1 band: Auditory-dPMC PLV values minus Visuo-dPMC PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Gamma1_AM.dPMC$`Pr(>F)`[1],digits=4)))

plot(AM.VM~Hemisphere,data=Gamma2, main = "Gamma2 band: Auditory-Motor PLV values minus Visuo-Motor PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Gamma2_AM.VM$`Pr(>F)`[1],digits=4)))
plot(AM.vPMC~Hemisphere,data=Gamma2, main = "Gamma2 band: Auditory-vPMC PLV values minus Visuo-vPMC PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Gamma2_AM.vPMC$`Pr(>F)`[1],digits=4)))
plot(AM.dPMC~Hemisphere,data=Gamma2, main = "Gamma2 band: Auditory-dPMC PLV values minus Visuo-dPMC PLV values", sub = sprintf ("p-value = %s",round(ANOVA_Gamma2_AM.dPMC$`Pr(>F)`[1],digits=4)))

# To finish, we tell RStudio to save all plots in the pdf file we created earlier:

dev.off()